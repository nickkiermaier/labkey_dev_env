/*
 * Copyright (c) 2018-2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0: http://www.apache.org/licenses/LICENSE-2.0
 */
SELECT
  a.project,
  a.id.demographics.species.common_name as species,
  count(*) AS activeAssignments

FROM study.Assignment a
WHERE a.isActive = true
GROUP BY a.project, a.id.demographics.species.common_name
PIVOT activeAssignments by species IN (select distinct a.id.demographics.species.common_name from study.assignment a)
