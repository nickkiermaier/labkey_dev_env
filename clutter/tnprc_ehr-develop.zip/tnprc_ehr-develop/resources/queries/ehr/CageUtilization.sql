/*
 * Copyright (c) 2018-2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0: http://www.apache.org/licenses/LICENSE-2.0
 */
SELECT
  c.location,
  c.room,
  c.cage,
  sum(CASE WHEN h.id.age.ageInMonths < 6 THEN 1 ELSE 0 END) AS LessSixMonthAnimals,
  count(DISTINCT h.id) as TotalAnimals,
  group_concat(DISTINCT h.id, chr(10)) as animals
FROM ehr_lookups.cages c
LEFT JOIN study.housing h
  ON c.room = h.room AND ((c.cage IS NULL AND h.cage IS NULL) OR (c.cage = h.cage))
WHERE h.isActive = TRUE
GROUP BY c.location, c.room, c.cage

