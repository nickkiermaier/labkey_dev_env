/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
  b.requestid,
  b.id,
  b.date,
  b.project,
  b.requestpriority,
  b.description,
  b.id.curLocation.room.area AS building,
  rp.personnel,
  NULL AS checks,
  NULL AS needs_tb_test,
  NULL AS needs_ivermectin,
  NULL AS needs_microchip,
  NULL AS needs_measles,
  NULL AS needs_tetanus,
  NULL AS needs_ultrasound,
  NULL AS needs_skin_biopsy,
  NULL AS needs_dye_marks,
  NULL AS showAnimalDetails,
  b.qcstate
FROM study.blood b
LEFT JOIN ehr.request_personnel rp ON rp.requestid = b.requestid
WHERE b.requestid IS NOT NULL

UNION SELECT
  p.requestid,
  p.id,
  cal1.TargetDate AS date,
  p.project,
  p.requestpriority,
  p.description,
  p.id.curLocation.room.area AS building,
  rp.personnel,
  NULL AS checks,
  NULL AS needs_tb_test,
  NULL AS needs_ivermectin,
  NULL AS needs_microchip,
  NULL AS needs_measles,
  NULL AS needs_tetanus,
  NULL AS needs_ultrasound,
  NULL AS needs_skin_biopsy,
  NULL AS needs_dye_marks,
  NULL AS showAnimalDetails,
  p.qcstate
FROM study.prc p
  -- using two inner joins to get all dates within the given date / enddate range based on the interval
  INNER JOIN ehr_lookups.calendar AS cal1 ON p.date <= cal1.TargetDate AND MOD(TIMESTAMPDIFF('SQL_TSI_DAY', p.date, cal1.TargetDate), CAST(COALESCE(interval, 1) AS INTEGER)) = 0
  INNER JOIN ehr_lookups.calendar AS cal2 ON COALESCE(p.enddate, p.date) >= cal1.TargetDate AND cal1.TargetDate = cal2.TargetDate
  LEFT JOIN ehr.request_personnel rp ON rp.requestid = p.requestid
WHERE p.requestid IS NOT NULL

UNION SELECT
  t.requestid,
  t.id,
  cal1.TargetDate AS date,
  t.project,
  t.requestpriority,
  t.description,
  id.curLocation.room.area AS building,
  rp.personnel,
  NULL AS checks,
  NULL AS needs_tb_test,
  NULL AS needs_ivermectin,
  NULL AS needs_microchip,
  NULL AS needs_measles,
  NULL AS needs_tetanus,
  NULL AS needs_ultrasound,
  NULL AS needs_skin_biopsy,
  NULL AS needs_dye_marks,
  NULL AS showAnimalDetails,
  qcstate
FROM study.treatment_order t
  -- using two inner joins to get all dates within the given date / enddate range based on the interval
  INNER JOIN ehr_lookups.calendar AS cal1 ON t.date <= cal1.TargetDate AND MOD(TIMESTAMPDIFF('SQL_TSI_DAY', t.date, cal1.TargetDate), CAST(COALESCE(interval, 1) AS INTEGER)) = 0
  INNER JOIN ehr_lookups.calendar AS cal2 ON COALESCE(t.enddate, date) >= cal1.TargetDate AND cal1.TargetDate = cal2.TargetDate
  LEFT JOIN ehr.request_personnel rp ON rp.requestid = t.requestid
WHERE t.requestid IS NOT NULL

UNION SELECT
  h.requestid,
  h.id,
  h.date,
  h.project,
  h.requestpriority,
  h.description,
  h.id.curLocation.room.area AS building,
  rp.personnel,
  NULL AS checks,
  NULL AS needs_tb_test,
  NULL AS needs_ivermectin,
  NULL AS needs_microchip,
  NULL AS needs_measles,
  NULL AS needs_tetanus,
  NULL AS needs_ultrasound,
  NULL AS needs_skin_biopsy,
  NULL AS needs_dye_marks,
  NULL AS showAnimalDetails,
  h.qcstate
FROM study.housing h
LEFT JOIN ehr.request_personnel rp ON rp.requestid = h.requestid
WHERE h.requestid IS NOT NULL

UNION SELECT
  s.requestid,
  s.id,
  s.date,
  s.project,
  s.requestpriority,
  s.description,
  s.id.curLocation.room.area AS building,
  rp.personnel,
  CASE WHEN s.check_sex = true THEN 'Sex, ' ELSE '' END ||
    CASE WHEN s.check_weight = true THEN 'Wt, ' ELSE '' END ||
    CASE WHEN s.check_microchip = true THEN 'Mc' ELSE '' END AS checks,
  s.needs_tb_test,
  s.needs_ivermectin,
  s.needs_microchip,
  s.needs_measles,
  s.needs_tetanus,
  s.needs_ultrasound,
  s.needs_skin_biopsy,
  s.needs_dye_marks,
  NULL AS showAnimalDetails,
  s.qcstate
FROM study.saha s
LEFT JOIN ehr.request_personnel rp ON rp.requestid = s.requestid
WHERE s.requestid IS NOT NULL

UNION SELECT
  md.requestid,
  NULL AS id,
  cal1.TargetDate AS date,
  NULL AS project,
  NULL AS requestPriority,
  md.instructions AS description,
  CASE WHEN md.room IS NOT NULL AND cage IS NOT NULL THEN (room || '-' || cage)
    WHEN md.room IS NOT NULL THEN room
    WHEN md.cage IS NOT NULL THEN cage
    ELSE NULL END AS building,
  rp.personnel,
  NULL AS checks,
  NULL AS needs_tb_test,
  NULL AS needs_ivermectin,
  NULL AS needs_microchip,
  NULL AS needs_measles,
  NULL AS needs_tetanus,
  NULL AS needs_ultrasound,
  NULL AS needs_skin_biopsy,
  NULL AS needs_dye_marks,
  md.showAnimalDetails,
  md.qcstate
FROM tnprc_ehr.maintenance_details md
  -- using two inner joins to get all dates within the given date / enddate range based on the interval
  INNER JOIN ehr_lookups.calendar AS cal1 ON date <= cal1.TargetDate AND MOD(TIMESTAMPDIFF('SQL_TSI_DAY', md.date, cal1.TargetDate), CAST(COALESCE(interval, 1) AS INTEGER)) = 0
  INNER JOIN ehr_lookups.calendar AS cal2 ON COALESCE(md.enddate, date) >= cal1.TargetDate AND cal1.TargetDate = cal2.TargetDate
  LEFT JOIN ehr.request_personnel rp ON rp.requestid = md.requestid