/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
  requestid,
  MIN(date) AS startDate,
  GROUP_CONCAT(DISTINCT project, ', ') AS project,
  GROUP_CONCAT(DISTINCT description, chr(10)) AS narrative,
  GROUP_CONCAT(DISTINCT personnel, ', ') AS personnel,
  CASE WHEN requestid IN (SELECT requestid FROM study.prc WHERE maj_prc_code = 'SRG') THEN TRUE ELSE FALSE END AS hasSurgery,
  CASE WHEN requestid IN (SELECT requestid FROM ehr.request_piggyback) THEN TRUE ELSE FALSE END AS hasPiggyback,
  CASE
    WHEN week(MIN(date)) - week(MIN(requestid.created)) > 1 THEN FALSE --not a late request if week difference bw created and request date is more than one
    WHEN ((week(MIN(date)) - week(MIN(requestid.created))) = 1 OR (week(MIN(date)) - week(MIN(requestid.created))) = -51) AND dayofweek(MIN(requestid.created)) BETWEEN 1 AND 3 THEN FALSE --late request when requests created for a week are created after Tuesday of the previous week
    WHEN (week(MIN(date)) - week(MIN(requestid.created))) < 0 AND (week(MIN(date)) - week(MIN(requestid.created))) > -51 THEN FALSE --also need to account for the last week of the year when the request date week # starts back at 1 and the created date is 51 or 52
  ELSE TRUE
  END as lateRequest,
  '[print]' AS printlink
FROM request_narrative_details
GROUP BY requestid