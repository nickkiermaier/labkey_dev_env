/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
SELECT
  MAX('[Details]') AS details,
  sd.Id,
  sd.Id.demographics.species,
  sd.Id.demographics.birth,
  sd.id.demographics.gender AS sex,
  sd.id.demographics.calculated_status,
  sd.id.age.ageInYears,
  sd.Id.MostRecentWeight.MostRecentWeight,
  sd.id.curLocation.room,
  sd.id.curLocation.cage,
  sd.parentId,
  codes.title || ' (' || CAST(sd.allele_code AS VARCHAR) || ')' AS allele_code,
  GROUP_CONCAT(result) AS result,
  snp.date,
  snp.lab_sent_code,
  snp.vet_pers_key,
  snp.project
FROM snp_dtl sd
  JOIN ehr_lookups.allele_codes codes ON codes.value = sd.allele_code
  JOIN study.snp snp on snp.objectId = sd.parentid
GROUP BY sd.Id, sd.parentId, snp.date, codes.title || ' (' || CAST(sd.allele_code AS VARCHAR) || ')',
  snp.lab_sent_code, snp.vet_pers_key, snp.project,
  sd.Id.demographics.species, sd.Id.demographics.birth, sd.id.demographics.gender, sd.id.demographics.calculated_status,
  sd.id.age.ageInYears, sd.Id.MostRecentWeight.MostRecentWeight,
  sd.id.curLocation.room, sd.id.curLocation.cage
PIVOT result BY allele_code
