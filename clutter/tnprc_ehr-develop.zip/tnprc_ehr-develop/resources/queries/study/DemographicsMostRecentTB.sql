/*
 * Copyright (c) 2018-2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0: http://www.apache.org/licenses/LICENSE-2.0
 */
SELECT
  tb.id,
  tb.date AS MostRecentTBDate,
  timestampdiff('SQL_TSI_DAY', tb.date, now()) AS DaysSinceTB,
  tb.result,
  tb.rsp_code_24.description AS rsp_code_24,
  tb.rsp_code_48.description AS rsp_code_48,
  tb.rsp_code_72.description AS rsp_code_72,
  tb.spm_code,
  tb.assay_code.title AS assay_code
FROM study.tb AS tb
INNER JOIN (
    SELECT
    tb.Id AS Id,
    max(tb.date) AS MostRecentTBDate
    FROM study.tb tb
    GROUP BY tb.id
  ) AS mostRecentTB
  ON tb.id = mostRecentTB.Id AND tb.date = mostRecentTB.MostRecentTBDate