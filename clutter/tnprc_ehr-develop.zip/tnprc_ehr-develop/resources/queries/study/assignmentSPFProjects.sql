/*
 * Copyright (c) 2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT id,
date,
enddate,
a.project,
CASE WHEN a.project IN (9002, 9004, 9100, 9200, 9400, 9911, 9991, 9998, 9999) THEN 'SPF Holding'
  WHEN a.project IN (9033, 9067, 9077, 9079) THEN 'SPF'
  ELSE NULL END AS is_spf_project,
pafc.am_fee_code AS fee_code,
afc.description AS fee_code_description,
afc.creditedaccount AS fee_code_credit_account
FROM assignment AS a

  LEFT JOIN (
  SELECT 9033 as project, 39 as am_fee_code
  UNION SELECT 9067 as project, 43 as am_fee_code
  UNION SELECT 9077 as project, 43 as am_fee_code
  UNION SELECT 9079 as project, 43 as am_fee_code
) AS pafc
  ON pafc.project = a.project

LEFT JOIN tnprc_ehr.am_fee_codes AS afc
  ON pafc.am_fee_code = afc.value