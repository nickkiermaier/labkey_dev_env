/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0q_urn.sql
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
'PAR__MTH_CD_KEY_A-' || CAST(mth.MVON_KEY AS VARCHAR(4000)) || '-' || CAST(mth.VALUE_INDEX AS VARCHAR(4000)) AS objectid,
par.MVON_KEY AS parentid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN PAR_TIME IS NULL
THEN CAST(PAR_DT AS TIMESTAMP)
ELSE CAST((PAR_DT || ' ' || PAR_TIME) AS TIMESTAMP)
END AS "date",
CAST(MTH_CD_KEY AS INTEGER) AS mth_code,
CAST(VALUE_INDEX AS INTEGER) AS "value_index",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
CAST(UPDATE_DATETIME AS TIMESTAMP) AS updated_at,
RECORD_DELETED 
FROM PAR__MTH_CD_KEY_A AS mth
  JOIN PAR AS par ON mth.MVON_KEY = par.PAR_KEY 
WHERE RECORD_DELETED = 'false' 
