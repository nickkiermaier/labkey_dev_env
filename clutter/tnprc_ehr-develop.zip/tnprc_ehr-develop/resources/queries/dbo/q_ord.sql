/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
CAST(ORD_KEY AS INTEGER) AS value,
CAST(ORD_DT AS TIMESTAMP) AS "dt",
ORD_ACCT_NUM AS acct_num,
ORD_MNF_NUMBER AS mnf_number,
ORD_PO_NUM AS po_num,
CASE WHEN ISNUMERIC(ORD_DU_CU_RATIO) = TRUE
    THEN CAST(ORD_DU_CU_RATIO AS DOUBLE)
    ELSE NULL END AS du_cu_ratio,
CASE WHEN ISNUMERIC(ORD_OU_DU_RATIO) = TRUE
    THEN CAST(ORD_OU_DU_RATIO AS DOUBLE)
    ELSE NULL END AS ou_du_ratio,
CAST(ORD_PRICE AS DOUBLE) AS price,
CASE WHEN ORD_QTY = '2,500' THEN CAST(2500.0 AS DOUBLE) ELSE CAST(ORD_QTY AS DOUBLE) END AS qty,
ORD_REQ_NUM AS req_num,
OU_UNIT_CD_KEY AS ou_unit_code,
SUP_HDR_KEY AS sup_hdr_key,
CAST(VENDOR_KEY AS INTEGER) AS vendor_key,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at
FROM ORD
WHERE RECORD_DELETED = FALSE