/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
  CAST(child.MVON_KEY AS INTEGER) AS "project",
  CO_INVEST_PERS_KEY AS "co_invest_pers_key",
  CO_LAB_SENT_CD_KEY AS "co_lab_send_code",
  VALUE_INDEX AS "Sort_Order",
  CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
  CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
  CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
  CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
  UPDATE_DATETIME AS updated_at
FROM PROJ__CO_INVEST_PERS_KEY_A AS child
JOIN PROJ AS parent ON parent.MVON_KEY = child.MVON_KEY
WHERE RECORD_DELETED = FALSE

UNION SELECT
  CAST(parent.PROJ_KEY AS INTEGER) AS "project",
  CO_INVEST_PERS_KEY AS "co_invest_pers_key",
  CO_LAB_SENT_CD_KEY AS "co_lab_send_code",
  VALUE_INDEX AS "Sort_Order",
  CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
  CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
  CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
  CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
  UPDATE_DATETIME AS updated_at
FROM PROJ_PND__CO_INVEST_PERS_KEY_A AS child
JOIN PROJ_PND AS parent ON parent.MVON_KEY = child.MVON_KEY
WHERE RECORD_DELETED = FALSE