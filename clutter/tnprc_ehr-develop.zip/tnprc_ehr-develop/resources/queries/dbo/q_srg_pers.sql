/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
'SRG__PERS_KEY_A-' || SRG_KEY || '-' || CAST(VALUE_INDEX AS VARCHAR(4000))  AS objectid,
srg.MVON_KEY AS parentid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN SRG_TIME IS NULL
        THEN CAST(SRG_DT AS TIMESTAMP)
     ELSE
        CAST((SRG_DT || ' ' || SRG_TIME) AS TIMESTAMP)
END AS "date",
CAST(VALUE_INDEX AS VARCHAR(4000)) AS value_index,
CAST(PERS_KEY AS INTEGER) AS pers_key,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
CAST(UPDATE_DATETIME AS TIMESTAMP) AS updated_at
FROM SRG__PERS_KEY_A AS prs
JOIN SRG AS srg ON prs.MVON_KEY = srg.MVON_KEY 
WHERE RECORD_DELETED = FALSE
