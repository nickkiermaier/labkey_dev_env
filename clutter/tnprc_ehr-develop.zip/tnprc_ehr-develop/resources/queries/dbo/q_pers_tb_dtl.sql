/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
PERS_TB_DTL_KEY AS value,
CAST(PERS_TB_DTL_DT AS TIMESTAMP) AS "dt",
PERS_KEY AS pers_key,
PERS_TB_1ST_HEPA_DT AS pers_tb_1st_hepa_dt,
PERS_TB_1ST_HEPB_DT AS pers_tb_1st_hepb_dt,
PERS_TB_2ND_HEPA_DT AS pers_tb_2nd_hepa_dt,
PERS_TB_2ND_HEPB_DT AS pers_tb_2nd_hepb_dt,
PERS_TB_3RD_HEPB_DT AS pers_tb_3rd_hepb_dt,
PERS_TB_DTL_ALLERGY AS allergy,
CASE WHEN PERS_TB_DTL_BCG_FL='Y' THEN TRUE
  WHEN PERS_TB_DTL_BCG_FL='N' THEN FALSE
  ELSE NULL END AS bcg_fl,
CASE WHEN PERS_TB_DTL_BLOOD_BANKED='Y' THEN TRUE
  WHEN PERS_TB_DTL_BLOOD_BANKED='N' THEN FALSE
  ELSE NULL END AS blood_banked,
PERS_TB_DTL_COM AS comment,
PERS_TB_DTL_HEP_COM AS hep_comment,
CASE WHEN PERS_TB_DTL_HEP_FL='Y' THEN TRUE
  WHEN PERS_TB_DTL_HEP_FL='N' THEN FALSE
  ELSE NULL END AS hep_fl,
PERS_TB_DTL_ORIENTATION AS orientation,
CASE WHEN PERS_TB_DTL_POS_FL='Y' THEN TRUE
  WHEN PERS_TB_DTL_POS_FL='N' THEN FALSE
  ELSE NULL END AS pos_fl,
PERS_TB_DTL_RESP_PE AS resp_pe,
CASE WHEN PERS_TB_DTL_XRAY_FL='Y' THEN TRUE
  WHEN PERS_TB_DTL_XRAY_FL='N' THEN FALSE
  ELSE NULL END AS xray_fl,
PERS_TB_MEASLES_DT AS pers_tb_measles_dt,
PERS_TB_MMR_DT AS pers_tb_mmr_dt,
PERS_TB_RABIES_DT AS pers_tb_rabies_dt,
PERS_TB_TETANUS_DT AS pers_tb_tetanus_dt,
PERS_TB_TET_BOOST_DT AS pers_tb_tet_boost_dt,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PERS_TB_DTL 