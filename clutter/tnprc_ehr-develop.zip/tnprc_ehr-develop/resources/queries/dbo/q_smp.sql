/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
SMP_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
SMP_PATH_DT AS "date",
CAST(INVEST_PERS_KEY AS VARCHAR(4000)) AS "invest_pers_key", -- integer
CAST(LOCAL_SPM_CD_KEY AS INTEGER) AS "local_spm_code",
CAST(OCT_CD_KEY AS VARCHAR(4000)) AS "oct_code", -- integer
CAST(SMP_ALCOHOL_DT AS VARCHAR(4000)) AS "alcohol_dt", -- timestamp
CAST(SMP_BOX AS VARCHAR(4000)) AS "box",
CAST(SMP_COM AS VARCHAR(4000)) AS "remark",
CAST(SMP_LOC_CD_KEY AS INTEGER) AS "loc_code",
CAST(SMP_NCR_PATH_NUM AS VARCHAR(4000)) AS "ncr_path_num",
CAST(SMP_NUM AS VARCHAR(4000)) AS "num",
CAST(SMP_NUM_VIALS AS INTEGER) AS "num_vials",
CAST(SMP_OCT_FL AS VARCHAR(4000)) AS "oct_fl",
CAST(SMP_PATH_DT AS TIMESTAMP) AS "path_dt",
CAST(SMP_PATH_PERS_KEY AS VARCHAR(4000)) AS "path_pers_key", -- integer
CAST(SMP_PATH_RCPT_PERS_KEY AS VARCHAR(4000)) AS "path_rcpt_pers_key", -- integer
CAST(SMP_POSITION AS VARCHAR(4000)) AS "position",
CAST(SMP_PROCESS_DT AS VARCHAR(4000)) AS "process_dt", -- timestamp
CAST(SMP_RACK AS VARCHAR(4000)) AS "rack",
CAST(SMP_USED_FL AS VARCHAR(4000)) AS "used_fl",
CAST(SPM_CD_KEY AS VARCHAR(4000)) AS "spm_code",
CAST(VRT_KEY AS VARCHAR(4000)) AS "vrt_key",
CASE WHEN UPDATE_TIME LIKE '%:%' THEN CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) ELSE CAST(UPDATE_DATE AS TIMESTAMP) END AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CASE WHEN UPDATE_TIME LIKE '%:%' THEN CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) ELSE CAST(UPDATE_DATE AS TIMESTAMP) END AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM SMP
-- Issue 32358
WHERE AM_KEY IS NOT NULL AND SMP_PATH_DT IS NOT NULL 
AND RECORD_DELETED = 'false' 
