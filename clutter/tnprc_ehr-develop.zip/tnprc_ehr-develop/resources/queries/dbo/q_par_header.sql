/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0q_urn.sql
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
PAR_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN PAR_TIME IS NULL
THEN CAST(PAR_DT AS TIMESTAMP)
ELSE CAST((PAR_DT || ' ' || PAR_TIME) AS TIMESTAMP)
END AS "date",
CAST(CANCEL_CD_KEY AS INTEGER) AS "cancel_code",
CAST(LAB_SENT_CD_KEY AS INTEGER) AS "lab_sent_code",
CAST(PAR_BILL_DT AS TIMESTAMP) AS "bill_dt",
CAST(PAR_BILL_PROJ_KEY AS INTEGER) AS "project",
CASE WHEN PAR_CHG_FL='Y' THEN 'true' WHEN PAR_CHG_FL='N' THEN 'false' ELSE NULL END AS "chg_fl",
CAST(PAR_COMMENT AS VARCHAR(4000)) AS "remark",
CAST(PAR_KATO_KATZ_CNT AS INTEGER) AS "kato_katz_cnt",
CAST(PRC_KEY AS VARCHAR(4000)) AS "parentid",
CAST(PUR_CD_KEY AS INTEGER) AS "pur_code",
CAST(SPM_CD_KEY AS VARCHAR(4000)) AS "spm_code",
CAST(VET_PERS_KEY AS INTEGER) AS "vet_pers_key",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PAR 
WHERE RECORD_DELETED = 'false' 
