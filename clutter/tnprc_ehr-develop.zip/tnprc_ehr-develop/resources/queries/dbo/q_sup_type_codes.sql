/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
SUP_TYPE_CD_KEY AS sort_order,
RATE_FIELD_LOC AS rate_field_loc,
RATE_FIELD_LOC_DESC AS rate_field_loc_desc,
RBL_RATE_FIELD_LOC AS rbl_rate_field_loc,
RBL_RATE_FIELD_LOC_DESC AS rbl_rate_field_loc_desc,
SRG_RATE_FIELD_LOC AS srg_rate_field_loc,
SRG_RATE_FIELD_LOC_DESC AS srg_rate_field_loc_desc,
SUP_OBJECT_CD AS sup_object_cd,
SUP_TYPE_CD_DESC AS title,
SUP_TYPE_CD_KEY AS "value",
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM SUP_TYPE_CD