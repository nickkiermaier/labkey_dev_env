/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
CAST(FND_KEY AS INTEGER) AS value,
DPT_CD_KEY AS dpt_code,
FND_AMND_DTL_KEY AS amnd_dtl_key,
FND_AWARD_DT AS award_dt,
FND_BDGT_DC AS bdgt_dc,
FND_BDGT_FA AS bdgt_fa,
FND_BDGT_FNA_PERCENT AS bdgt_fna_percent,
FND_BDGT_GRAND_TOTAL AS bdgt_grand_total,
FND_COM AS comment,
FND_FORMAL_TITLE AS formal_title,
FND_GRT_NUM AS grt_num,
FND_GRT_PREFIX AS grt_prefix,
FND_GRT_SUFFIX AS grt_suffix,
FND_PND_KEY AS pnd_key,
FND_PROJ_END_DT AS proj_end_dt,
FND_PROJ_START_DT AS proj_start_dt,
FND_SHORT_TITLE AS short_title,
FND_SRC_CD_KEY AS src_code,
FND_SRC_TYPE_CD_KEY AS src_type_code,
FND_TYPE_CD_KEY AS type_code,
INTME_FND_SRC_CD_KEY AS intme_fnd_src_code,
INVEST_PERS_KEY AS invest_pers_key,
LAB_SENT_CD_KEY AS lab_sent_code,
RATE_CD_KEY AS rate_code,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at
FROM FND
WHERE RECORD_DELETED = FALSE
