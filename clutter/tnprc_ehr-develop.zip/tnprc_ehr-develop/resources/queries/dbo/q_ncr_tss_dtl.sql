/*
* Copyright (c) 2018-2019 LabKey Corporation
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

SELECT
child.NCR_TSS_DTL_KEY AS objectid,
child.NCR_TSS_KEY AS parentid,
parent.id,
CASE WHEN (NCR_TSS_DTL_DT IS NULL) THEN parent.date
  ELSE CAST(child.NCR_TSS_DTL_DT AS TIMESTAMP) END AS "date",
CAST(child.NCR_TSS_DTL_IMPORT_DT AS TIMESTAMP) AS "import_dt",
CAST(child.NCR_TSS_DTL_QTY AS DOUBLE) AS "qty",
CAST(child.SPM_CD_KEY AS VARCHAR(4000)) AS "spm_code",
CAST(child.UPDATE_DATE || ' ' || child.UPDATE_TIME AS TIMESTAMP) AS created,
CAST(child.UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(child.UPDATE_DATE || ' ' || child.UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(child.UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
child.UPDATE_DATETIME AS updated_at,
child.RECORD_DELETED
FROM NCR_TSS_DTL AS child
LEFT JOIN q_ncr_tss AS parent ON child.NCR_TSS_KEY = parent.objectid
WHERE parent.RECORD_DELETED = FALSE AND child.RECORD_DELETED = FALSE
