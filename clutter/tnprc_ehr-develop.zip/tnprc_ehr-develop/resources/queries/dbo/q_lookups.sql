/*
 * Copyright (c) 2017-2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
SELECT 'ACT_CD_' || ACT_CD_KEY AS objectid,
'acetone_codes' AS set_name,
ACT_CD_KEY AS "value",
ACT_CD_DESC AS description,
ACT_CD_ABB_DESC AS title,
CAST(ACT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ACT_CD

UNION SELECT 'ALB_CD_' || ALB_CD_KEY AS objectid,
'albumin_codes' AS set_name,
ALB_CD_KEY AS "value",
ALB_CD_DESC AS description,
ALB_CD_ABB_DESC AS title,
CAST(ALB_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ALB_CD

UNION SELECT 'ALLELE_CD_' || ALLELE_CD_KEY AS objectid,
'allele_codes' AS set_name,
ALLELE_CD_KEY AS "value",
ALLELE_CD_DESC AS description,
CASE WHEN ALLELE_CD_ABB_DESC IS NOT NULL THEN ALLELE_CD_ABB_DESC ELSE ALLELE_CD_DESC END AS title,
CAST(ALLELE_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
MAJ_PRC_CD_KEY AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ALLELE_CD

UNION SELECT 'ASSAY_CD_' || ASSAY_CD_KEY AS objectid,
'assay_codes' AS set_name,
ASSAY_CD_KEY AS "value",
ASSAY_CD_DESC AS description,
ASSAY_CD_DESC AS title,
CAST(ASSAY_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ASSAY_CD

UNION SELECT 'AGE_EST_CD_' || AGE_EST_CD_KEY AS objectid,
'age_est_codes' AS set_name,
AGE_EST_CD_KEY AS "value",
AGE_EST_CD_DESC AS description,
AGE_EST_CD_DESC AS title,
CAST(AGE_EST_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM AGE_EST_CD

UNION SELECT 'AUSC_CD_' || AUSC_CD_KEY AS objectid,
'ausc_codes' AS set_name,
AUSC_CD_KEY AS "value",
AUSC_CD_DESC AS description,
AUSC_CD_DESC AS title,
CAST(AUSC_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM AUSC_CD

UNION SELECT 'BILL_CAT_CD_' || BILL_CAT_CD_KEY AS objectid,
'bill_cat_codes' AS set_name,
BILL_CAT_CD_KEY AS "value",
BILL_CAT_CD_DESC AS description,
BILL_CAT_CD_ABB_DESC AS title,
CAST(BILL_CAT_CD_KEY AS INTEGER) AS sort_order,
CASE BILL_CAT_CD_ACTIVE_FL
WHEN 'Y' THEN NULL
WHEN 'N' THEN '1/1/1970'
END AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM BILL_CAT_CD

UNION SELECT 'BIRTH_CD_' || BIRTH_CD_KEY AS objectid,
'birth_codes' AS set_name,
BIRTH_CD_KEY AS "value",
BIRTH_CD_DESC AS description,
BIRTH_CD_ABB_DESC AS title,
CAST(BIRTH_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM BIRTH_CD

UNION SELECT 'BO_EXCEPT_CD_' || BO_EXCEPT_CD_KEY AS objectid,
'bo_except_codes' AS set_name,
BO_EXCEPT_CD_KEY AS "value",
BO_EXCEPT_CD_DESC AS description,
BO_EXCEPT_CD_ABB_DESC AS title,
CAST(BO_EXCEPT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM BO_EXCEPT_CD

UNION SELECT 'CANCEL_CD_' || CANCEL_CD_KEY AS objectid,
'cancel_codes' AS set_name,
CANCEL_CD_KEY AS "value",
CANCEL_CD_DESC AS description,
CANCEL_CD_DESC AS title,
CAST(CANCEL_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CANCEL_CD

UNION SELECT 'CASTS_CD_' || CASTS_CD_KEY AS objectid,
'casts_codes' AS set_name,
CASTS_CD_KEY AS "value",
CASTS_CD_DESC AS description,
CASTS_CD_ABB_DESC AS title,
CAST(CASTS_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CASTS_CD

UNION SELECT 'CELL_CD_' || CELL_CD_KEY AS objectid,
'cell_codes' AS set_name,
CELL_CD_KEY AS "value",
CELL_CD_DESC AS description,
CELL_CD_ABB_DESC AS title,
CAST(CELL_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CELL_CD

UNION SELECT
'CH_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM VW_CH_CD
JOIN CH_CD AS parent ON value = parent.MVON_KEY

UNION SELECT
'CHM_SERUM_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_chm_serum_cd
JOIN CHM_SERUM_CD AS parent ON value = parent.MVON_KEY

UNION SELECT 'CHR_CD_' || CHR_CD_KEY AS objectid,
'chr_codes' AS set_name,
CHR_CD_KEY AS "value",
CHR_CD_DESC AS description,
CHR_CD_ABB_DESC AS title,
CAST(CHR_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CHR_CD

UNION SELECT 'CLASS_CD_' || CLASS_CD_KEY AS objectid,
'class_codes' AS set_name,
CLASS_CD_KEY AS "value",
CLASS_CD_DESC AS description,
CLASS_CD_DESC_ABB AS title,
CAST(CLASS_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CLASS_CD

UNION SELECT 'CLR_CD_' || CLR_CD_KEY AS objectid,
'color_codes' AS set_name,
CLR_CD_KEY AS "value",
CLR_CD_DESC AS description,
CLR_CD_ABB_DESC AS title,
CAST(CLR_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CLR_CD

UNION SELECT 'CND_CD_' || CND_CD_KEY AS objectid,
'cnd_codes' AS set_name,
CND_CD_KEY AS "value",
CND_CD_DESC AS description,
CND_CD_DESC AS title,
CAST(CND_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CND_CD

UNION SELECT 'CRYST_CD_' || CRYST_CD_KEY AS objectid,
'cryst_codes' AS set_name,
CRYST_CD_KEY AS "value",
CRYST_CD_DESC AS description,
CRYST_CD_ABB_DESC AS title,
CAST(CRYST_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CRYST_CD

UNION SELECT 'DEGREE_CD_' || DEGREE_CD_KEY AS objectid,
'degree_codes' AS set_name,
DEGREE_CD_KEY AS "value",
DEGREE_CD_DESC AS description,
DEGREE_CD_DESC AS title,
CAST(DEGREE_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM DEGREE_CD

UNION SELECT 'DIFF_CD_' || DIFF_CD_KEY AS objectid,
'diff_codes' AS set_name,
DIFF_CD_KEY AS "value",
DIFF_CD_DESC AS description,
DIFF_CD_DESC AS title,
CAST(DIFF_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM DIFF_CD

UNION SELECT 'DISC_CD_' || DISC_CD_KEY AS objectid,
'disc_codes' AS set_name,
DISC_CD_KEY AS "value",
DISC_CD_DESC AS description,
DISC_CD_DESC AS title,
CAST(DISC_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM DISC_CD

UNION SELECT 'DM_CD_' || DM_CD_KEY AS objectid,
'dm_codes' AS set_name,
DM_CD_KEY AS "value",
DM_CD_DESC AS description,
DM_CD_ABB_DESC AS title,
CAST(DM_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM DM_CD

UNION SELECT
'DNT_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_dnt_cd
JOIN DNT_CD AS parent ON value = parent.MVON_KEY

UNION SELECT 'DRH_CD_' || DRH_CD_KEY AS objectid,
'drh_codes' AS set_name,
DRH_CD_KEY AS "value",
DRH_CD_DESC AS description,
DRH_CD_ABB_DESC AS title,
CAST(DRH_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM DRH_CD

UNION SELECT 'DTH_CD_' || DTH_CD_KEY AS objectid,
'dth_codes' AS set_name,
DTH_CD_KEY AS "value",
DTH_CD_ABB_DESC AS description,
DTH_CD_DESC_ABB_DESC AS title,
CAST(DTH_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM DTH_CD

UNION SELECT 'EC_CD_' || EC_CD_KEY AS objectid,
'ec_codes' AS set_name,
EC_CD_KEY AS "value",
EC_CD_DESC AS description,
EC_CD_ABB_DESC AS title,
CAST(EC_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM EC_CD

UNION SELECT 'EJC_COLL_PUR_CD_' || EJC_COLL_PUR_CD_KEY AS objectid,
'ejc_coll_pur_codes' AS set_name,
EJC_COLL_PUR_CD_KEY AS "value",
EJC_COLL_PUR_CD_DESC AS description,
EJC_COLL_PUR_CD_ABB_DESC AS title,
CAST(EJC_COLL_PUR_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM EJC_COLL_PUR_CD

UNION SELECT 'EJC_MTH_CD_' || EJC_MTH_CD_KEY AS objectid,
'ejc_mth_codes' AS set_name,
EJC_MTH_CD_KEY AS "value",
EJC_MTH_CD_DESC AS description,
EJC_MTH_CD_ABB_DESC AS title,
CAST(EJC_MTH_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM EJC_MTH_CD

UNION SELECT 'ENR_CAT_CD_' || ENR_CAT_CD_KEY AS objectid,
'enr_cat_codes' AS set_name,
ENR_CAT_CD_KEY AS "value",
ENR_CAT_CD_DESC AS description,
ENR_CAT_CD_ABB_DESC AS title,
CAST(ENR_CAT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ENR_CAT_CD

UNION SELECT 'ENR_DEV_CD_' || ENR_DEV_CD_KEY AS objectid,
'enr_dev_codes' AS set_name,
ENR_DEV_CD_KEY AS "value",
ENR_DEV_CD_DESC AS description,
ENR_DEV_CD_ABB_DESC AS title,
CAST(ENR_DEV_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ENR_DEV_CD

UNION SELECT 'ENR_RSN_CD_' || ENR_RSN_CD_KEY AS objectid,
'enr_rsn_codes' AS set_name,
ENR_RSN_CD_KEY AS "value",
ENR_RSN_CD_DESC AS description,
ENR_RSN_CD_ABB_DESC AS title,
CAST(ENR_RSN_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ENR_RSN_CD

UNION SELECT 'EPTH_CD_' || EPTH_CD_KEY AS objectid,
'epth_codes' AS set_name,
EPTH_CD_KEY AS "value",
EPTH_CD_DESC AS description,
EPTH_CD_ABB_DESC AS title,
CAST(EPTH_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM EPTH_CD

UNION SELECT 'EX_CD_' || EX_CD_KEY AS objectid,
'ex_codes' AS set_name,
EX_CD_KEY AS "value",
EX_CD_DESC AS description,
EX_CD_ABB_DESC AS title,
CAST(EX_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM EX_CD

UNION SELECT 'FLG_RSN_CD_' || FLG_RSN_CD_KEY AS objectid,
'flg_rsn_codes' AS set_name,
FLG_RSN_CD_KEY AS "value",
FLG_RSN_CD_DESC AS description,
FLG_RSN_CD_ABB_DESC AS title,
CAST(FLG_RSN_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM FLG_RSN_CD

UNION SELECT
'FND_SRC_TYPE_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_fnd_src_type_cd
JOIN FND_SRC_TYPE_CD AS parent ON value = parent.MVON_KEY

UNION SELECT
'FND_TYPE_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_fnd_type_cd
JOIN FND_TYPE_CD AS parent ON value = parent.MVON_KEY

UNION SELECT 'HT_CD_' || HT_CD_KEY AS objectid,
'ht_codes' AS set_name,
HT_CD_KEY AS "value",
HT_CD_DESC AS description,
HT_CD_ABB_DESC AS title,
CAST(HT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM HT_CD

UNION SELECT 'INOC_INDEX_CD_' || INOC_INDEX_CD_KEY AS objectid,
'inoc_index_codes' AS set_name,
INOC_INDEX_CD_KEY AS "value",
INOC_INDEX_CD_DESC AS description,
INOC_INDEX_CD_DESC AS title,
CAST(INOC_INDEX_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM INOC_INDEX_CD

UNION SELECT 'INOC_MTH_CD_' || INOC_MTH_CD_KEY AS objectid,
'inoc_mth_codes' AS set_name,
INOC_MTH_CD_KEY AS "value",
INOC_MTH_CD_DESC AS description,
INOC_MTH_CD_ABB_DESC AS title,
CAST(INOC_MTH_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM INOC_MTH_CD

UNION SELECT 'INOC_TYPE_CD_' || INOC_TYPE_CD_KEY AS objectid,
'inoc_type_codes' AS set_name,
INOC_TYPE_CD_KEY AS "value",
INOC_TYPE_CD_DESC AS description,
INOC_TYPE_CD_ABB_DESC AS title,
CAST(INOC_TYPE_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM INOC_TYPE_CD

UNION SELECT 'INSUR_CD_' || INSUR_CD_KEY AS objectid,
'insur_codes' AS set_name,
INSUR_CD_KEY AS "value",
INSUR_CD_DESC AS description,
INSUR_CD_DESC AS title,
CAST(INSUR_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM INSUR_CD

UNION SELECT 'LYMPH_CD_' || LYMPH_CD_KEY AS objectid,
'lymph_codes' AS set_name,
LYMPH_CD_KEY AS "value",
LYMPH_CD_DESC AS description,
LYMPH_CD_ABB_DESC AS title,
CAST(LYMPH_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM LYMPH_CD

UNION SELECT 'MAS_TEST_CD_' || MAS_TEST_CD_KEY AS objectid,
'mas_test_codes' AS set_name,
MAS_TEST_CD_KEY AS "value",
MAS_TEST_CD_DESC AS description,
MAS_TEST_CD_ABB_DESC AS title,
CAST(MAS_TEST_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM MAS_TEST_CD

UNION SELECT 'MTF_RSN_CD_' || MTF_RSN_CD_KEY AS objectid,
'mtf_rsn_codes' AS set_name,
MTF_RSN_CD_KEY AS "value",
MTF_RSN_CD_DESC AS description,
MTF_RSN_CD_ABB_DESC AS title,
CAST(MTF_RSN_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM MTF_RSN_CD

UNION SELECT 'MTH_CD_' || MTH_CD_KEY AS objectid,
'mth_codes' AS set_name,
MTH_CD_KEY AS "value",
MTH_CD_DESC AS description,
MTH_CD_ABB_DESC AS title,
CAST(MTH_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM MTH_CD

UNION SELECT 'NC_RSN_CD_' || NC_RSN_CD_KEY AS objectid,
'nc_rsn_codes' AS set_name,
NC_RSN_CD_KEY AS "value",
NC_RSN_CD_DESC AS description,
NC_RSN_CD_ABB_DESC AS title,
CAST(NC_RSN_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM NC_RSN_CD

UNION SELECT 'NCR_INT_CD_' || NCR_INT_CD_KEY AS objectid,
'ncr_int_codes' AS set_name,
NCR_INT_CD_KEY AS "value",
NCR_INT_CD_DESC AS description,
NCR_INT_CD_DESC AS title,
CAST(NCR_INT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM NCR_INT_CD

UNION SELECT
'OBS_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_obs_cd
JOIN OBS_CD AS parent ON value = parent.MVON_KEY

UNION SELECT 'OCLT_CD_' || OCLT_CD_KEY AS objectid,
'oclt_codes' AS set_name,
OCLT_CD_KEY AS "value",
OCLT_CD_DESC AS description,
OCLT_CD_ABB_DESC AS title,
CAST(OCLT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM OCLT_CD

UNION SELECT 'PERS_FNC_CD_' || PERS_FNC_CD_KEY AS objectid,
'pers_fnc_codes' AS set_name,
PERS_FNC_CD_KEY AS "value",
PERS_FNC_CD_DESC AS description,
PERS_FNC_CD_ABB_DESC AS title,
CAST(PERS_FNC_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PERS_FNC_CD

UNION SELECT 'PRG_CD_' || PRG_CD_KEY AS objectid,
'prg_codes' AS set_name,
PRG_CD_KEY AS "value",
PRG_CD_DESC AS description,
PRG_CD_DESC AS title,
CAST(PRG_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PRG_CD

UNION SELECT 'PROJ_AMEND_RSN_CD_' || PROJ_AMEND_RSN_CD_KEY AS objectid,
'proj_amend_rsn_codes' AS set_name,
PROJ_AMEND_RSN_CD_KEY AS "value",
PROJ_AMEND_RSN_CD_DESC AS description,
PROJ_AMEND_RSN_CD_ABB_DESC AS title,
CAST(PROJ_AMEND_RSN_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PROJ_AMEND_RSN_CD


UNION SELECT 'PST_CD_' || PST_CD_KEY AS objectid,
'pst_codes' AS set_name,
PST_CD_KEY AS "value",
PST_CD_DESC AS description,
PST_CD_ABB_DESC AS title,
CAST(PST_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PST_CD


UNION SELECT 'PUR_CD_' || PUR_CD_KEY AS objectid,
'pur_codes' AS set_name,
PUR_CD_KEY AS "value",
PUR_CD_DESC AS description,
PUR_CD_ABB_DESC AS title,
CAST(PUR_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PUR_CD


UNION SELECT 'RAD_CD_' || RAD_CD_KEY AS objectid,
'rad_codes' AS set_name,
RAD_CD_KEY AS "value",
RAD_CD_DESC AS description,
RAD_CD_DESC AS title,
CAST(RAD_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM RAD_CD


UNION SELECT 'REAL_TIME_CD_' || REAL_TIME_CD_KEY AS objectid,
'real_time_codes' AS set_name,
REAL_TIME_CD_KEY AS "value",
REAL_TIME_CD_DESC AS description,
REAL_TIME_CD_DESC AS title,
CAST(REAL_TIME_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM REAL_TIME_CD


UNION SELECT 'RESP_CD_' || RESP_CD_KEY AS objectid,
'resp_codes' AS set_name,
RESP_CD_KEY AS "value",
RESP_CD_DESC AS description,
RESP_CD_DESC AS title,
CAST(RESP_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM RESP_CD


UNION SELECT 'RSLT_FILE_CD_' || RSLT_FILE_CD_KEY AS objectid,
'rslt_file_codes' AS set_name,
RSLT_FILE_CD_KEY AS "value",
RSLT_FILE_CD_DESC AS description,
RSLT_FILE_CD_DESC AS title,
CAST(RSLT_FILE_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM RSLT_FILE_CD


UNION SELECT 'RSN_CD_' || RSN_CD_KEY AS objectid,
'rsn_codes' AS set_name,
RSN_CD_KEY AS "value",
RSN_CD_DESC AS description,
RSN_CD_DESC AS title,
CAST(RSN_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM RSN_CD


UNION SELECT
'RT_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_rt_cd
JOIN RT_CD AS parent ON value = parent.MVON_KEY

UNION SELECT
'SENS_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_sens_cd
JOIN SENS_CD AS parent ON value = parent.MVON_KEY

UNION SELECT 'SGR_CD_' || SGR_CD_KEY AS objectid,
'sgr_codes' AS set_name,
SGR_CD_KEY AS "value",
SGR_CD_DESC AS description,
SGR_CD_ABB_DESC AS title,
CAST(SGR_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM SGR_CD


UNION SELECT 'SIG_CD_' || SIG_CD_KEY AS objectid,
'sig_codes' AS set_name,
SIG_CD_KEY AS "value",
SIG_CD_DESC AS description,
SIG_CD_DESC AS title,
CAST(SIG_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM SIG_CD


UNION SELECT 'SMP_LOC_CD_MFG_CD_' || SMP_LOC_CD_MFG_CD_KEY AS objectid,
'smp_loc_cd_mfg_codes' AS set_name,
SMP_LOC_CD_MFG_CD_KEY AS "value",
SMP_LOC_CD_MFG_CD_DESC AS description,
SMP_LOC_CD_MFG_CD_ABB_DESC AS title,
CAST(SMP_LOC_CD_MFG_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM SMP_LOC_CD_MFG_CD


UNION SELECT 'SMP_LOC_CD_TYPE_CD_' || SMP_LOC_CD_TYPE_CD_KEY AS objectid,
'smp_loc_cd_type_codes' AS set_name,
SMP_LOC_CD_TYPE_CD_KEY AS "value",
SMP_LOC_CD_TYPE_CD_DESC AS description,
SMP_LOC_CD_TYPE_CD_ABB_DESC AS title,
CAST(SMP_LOC_CD_TYPE_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM SMP_LOC_CD_TYPE_CD


UNION SELECT 'SMP_SPM_CD_' || SMP_SPM_CD_KEY AS objectid,
'smp_spm_codes' AS set_name,
SMP_SPM_CD_KEY AS "value",
SMP_SPM_CD_DESC AS description,
SMP_SPM_CD_ABB_DESC AS title,
CAST(SMP_SPM_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM SMP_SPM_CD


UNION SELECT
'SNO_FNC_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_sno_fnc_cd
JOIN SNO_FNC_CD AS parent ON value = parent.MVON_KEY

UNION SELECT
'SOC_HSE_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_soc_hse_cd
JOIN SOC_HSE_CD AS parent ON value = parent.MVON_KEY

UNION SELECT
'SRG_ST_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_srg_st_cd
JOIN SRG_ST_CD AS parent ON value = parent.MVON_KEY

UNION SELECT 'STAIN_CD_' || STAIN_CD_KEY AS objectid,
'stain_codes' AS set_name,
STAIN_CD_KEY AS "value",
STAIN_CD_DESC AS description,
STAIN_CD_DESC AS title,
CAST(STAIN_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM STAIN_CD


UNION SELECT
'SUP_UNIT_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_sup_unit_cd
JOIN SUP_UNIT_CD AS parent ON value = parent.MVON_KEY

UNION SELECT
'TAG_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_tag_cd
JOIN TAG_CD AS parent ON value = parent.MVON_KEY

UNION SELECT 'TL_CD_' || TL_CD_KEY AS objectid,
'tl_codes' AS set_name,
TL_CD_KEY AS "value",
TL_CD_ABB_DESC AS description,
TL_CD_ABB_DESC AS title,
CAST(TL_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM TL_CD


UNION SELECT 'VACCINE_CD_' || VACCINE_CD_KEY AS objectid,
'vaccine_codes' AS set_name,
VACCINE_CD_KEY AS "value",
VACCINE_CD_DESC AS description,
VACCINE_CD_ABB_DESC AS title,
CAST(VACCINE_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM VACCINE_CD


UNION SELECT 'VEN_CD_' || VEN_CD_KEY AS objectid,
'ven_codes' AS set_name,
VEN_CD_KEY AS "value",
VEN_CD_DESC AS description,
VEN_CD_ABB_DESC AS title,
CAST(VEN_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM VEN_CD


UNION SELECT 'VIT_CD_' || VIT_CD_KEY AS objectid,
'vit_codes' AS set_name,
VIT_CD_KEY AS "value",
VIT_CD_DESC AS description,
VIT_CD_DESC AS title,
CAST(VIT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
MAJ_PRC_CD_KEY AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM VIT_CD


UNION SELECT 'VOID_CD_' || VOID_CD_KEY AS objectid,
'void_codes' AS set_name,
VOID_CD_KEY AS "value",
VOID_CD_DESC AS description,
VOID_CD_ABB_DESC AS title,
CAST(VOID_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM VOID_CD


UNION SELECT 'VRT_RSLT_CD_' || VRT_RSLT_CD_KEY AS objectid,
'vrt_rslt_codes' AS set_name,
VRT_RSLT_CD_KEY AS "value",
VRT_RSLT_CD_DESC AS description,
VRT_RSTL_CD_SHORT_DESC AS title,
CAST(VRT_RSLT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM VRT_RSLT_CD

UNION SELECT 'ACQ_CD_' || ACQ_CD_KEY AS objectid,
'acquisition_codes' AS set_name,
ACQ_CD_KEY AS "value",
ACQ_CD_DESC AS description,
ACQ_CD_ABB_DESC AS title,
CAST(ACQ_CD_KEY AS INTEGER) AS sort_order,
CASE ACQ_CD_ACTIVE_FL
WHEN 'Y' THEN NULL
WHEN 'N' THEN '1/1/1970'
END AS date_disabled,
CAST(REPLACE(ACQ_CD_FILE_NAME, '.', '_') AS VARCHAR(4000)) AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ACQ_CD


UNION SELECT 'CS_CAUSE_CD_' || CS_CAUSE_CD_KEY AS objectid,
'case_cause_codes' AS set_name,
CS_CAUSE_CD_KEY AS "value",
CS_CAUSE_CD_DESC AS description,
CS_CAUSE_CD_ABB_DESC as title,
CAST(CS_CAUSE_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CS_CAUSE_CD

UNION SELECT 'DISP_CD_' || DISP_CD_KEY AS objectid,
'disposition_codes' AS set_name,
DISP_CD_KEY AS "value",
DISP_CD_DESC AS description,
DISP_CD_ABB_DESC AS title,
CAST(DISP_CD_KEY AS INTEGER) AS sort_order,
CASE DISP_CD_ACTIVE_FL
WHEN 'Y' THEN NULL
WHEN 'N' THEN '1/1/1970'
END AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM DISP_CD

UNION SELECT 'FND_SRC_CD_' || FND_SRC_CD_KEY AS objectid,
'funding_source_codes' AS set_name,
FND_SRC_CD_KEY AS "value",
FND_SRC_CD_DESC AS description,
FND_SRC_CD_ABB_DESC AS title,
CAST(FND_SRC_CD_KEY AS INTEGER) AS sort_order,
CASE FND_SRC_CD_ACTIVE_FL
WHEN 'Y' THEN NULL
WHEN 'N' THEN '1/1/1970'
END AS date_disabled,
FND_SRC_TYPE_CD_KEY AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM FND_SRC_CD

UNION SELECT 'HSE_CAT_CD_' || HSE_CAT_CD_KEY AS objectid,
'housing_category_codes' AS set_name,
HSE_CAT_CD_KEY AS "value",
HSE_CAT_CD_DESC AS description,
HSE_CAT_CD_ABB_DESC AS title,
CAST(HSE_CAT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
SOC_HSE_CD_KEY AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM HSE_CAT_CD

UNION SELECT 'INOC_CD_' || INOC_CD_KEY AS objectid,
'inoculum_codes' AS set_name,
INOC_CD_KEY AS "value",
INOC_CD_DESC AS description,
INOC_CD_ABB_DESC AS title,
CAST(INOC_CD_KEY AS INTEGER) AS sort_order,
CASE INOC_CD_ACTIVE_FL
WHEN 'Y' THEN NULL
WHEN 'N' THEN '1/1/1970'
END AS date_disabled,
INOC_CD_INDEX_DESC AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM INOC_CD

UNION SELECT 'INSTRUMENT_CD_' || INSTRUMENT_CD_KEY AS objectid,
'instrument_codes' AS set_name,
INSTRUMENT_CD_KEY AS "value",
INSTRUMENT_CD_DESC AS description,
INSTRUMENT_CD_ABB_DESC as title,
CAST(INSTRUMENT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
MAJ_PRC_CD_KEY AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM INSTRUMENT_CD

UNION SELECT
'MAJ_PRC_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_maj_prc_cd
JOIN MAJ_PRC_CD AS parent ON value = parent.MVON_KEY

UNION SELECT
'MIN_PRC_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
description as title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_min_prc_cd
JOIN MIN_PRC_CD AS parent ON value = parent.MVON_KEY

UNION SELECT 'PAR_CD_' || PAR_CD_KEY AS objectid,
'parasite_codes' AS set_name,
PAR_CD_KEY AS "value",
PAR_CD_DESC AS description,
PAR_CD_DESC AS title,
CAST(PAR_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
ET_CD_KEY AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PAR_CD

UNION SELECT 'PHX_VIT_CD_' || PHX_VIT_CD_KEY AS objectid,
'phx_vitals_codes' AS set_name,
PHX_VIT_CD_KEY AS "value",
PHX_VIT_CD_DESC AS description,
PHX_VIT_CD_ABB_DESC as title,
CAST(PHX_VIT_CD_KEY AS INTEGER) AS sort_order,
CASE PHX_VIT_CD_ACTIVE_FL
WHEN 'Y' THEN NULL
WHEN 'N' THEN '1/1/1970'
END AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PHX_VIT_CD

UNION SELECT 'PREP_CD_' || PREP_CD_KEY AS objectid,
'prep_codes' AS set_name,
PREP_CD_KEY AS "value",
PREP_CD_DESC AS description,
PREP_CD_ABB_DESC as title,
CAST(PREP_CD_KEY AS INTEGER) AS sort_order,
CASE PREP_CD_ACTIVE_FL
--TODO NULL VALUES IN PREP_CD_ACTIVE_FL
WHEN 'N' THEN '1/1/1970'
ELSE NULL
END AS date_disabled,
CAST(REPLACE(PREP_CD_FILE_NAME, '.', '_') AS VARCHAR(4000)) AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PREP_CD

UNION SELECT 'PROJ_CNS_CD_' || PROJ_CNS_CD_KEY AS objectid,
'project_census_codes' AS set_name,
PROJ_CNS_CD_KEY AS "value",
NULL AS description,
DATA as title,
CAST(PROJ_CNS_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PROJ_CNS_CD

UNION SELECT 'RATE_CD_' || RATE_CD_KEY AS objectid,
'rate_codes' AS set_name,
RATE_CD_KEY AS "value",
RATE_CD_COMP_DESC AS description,
RATE_CD_DESC as title,
CAST(RATE_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM RATE_CD

UNION SELECT 'RBC_MRP_CD_' || RBC_MRP_CD_KEY AS objectid,
'rbc_morphology_codes' AS set_name,
RBC_MRP_CD_KEY AS "value",
RBC_MRP_CD_FL AS description,
RBC_MRP_CD_ABB_DESC as title,
CAST(RBC_MRP_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM RBC_MRP_CD

UNION SELECT 'RSLT_CD_' || RSLT_CD_KEY AS objectid,
'result_codes' AS set_name,
RSLT_CD_KEY AS "value",
RSLT_CD_DESC AS description,
RSLT_CD_DESC as title,
CAST(RSLT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
MAJ_PRC_CD_KEY AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM RSLT_CD

UNION SELECT 'RSP_CD_' || RSP_CD_KEY AS objectid,
'response_codes' AS set_name,
RSP_CD_KEY AS "value",
RSP_CD_DESC AS description,
RSP_CD_ABB_DESC as title,
CAST(RSP_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM RSP_CD


UNION SELECT
'SPM_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL AS date_disabled,
NULL AS category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_spm_cd
JOIN SPM_CD AS parent ON value = parent.MVON_KEY

UNION SELECT
'UNIT_CD_' || CAST(sort_order AS VARCHAR(4000)) AS objectid,
set_name,
"value",
description,
title,
sort_order,
NULL as date_disabled,
category,
parent.UPDATE_DATETIME AS updated_at,
parent.RECORD_DELETED
FROM vw_unit_cd
JOIN UNIT_CD AS parent ON value = parent.MVON_KEY

UNION SELECT 'VA_CD_' || VA_CD_KEY AS objectid,
'vivarial_assistant_codes' AS set_name,
VA_CD_KEY AS "value",
VA_CD_DESC AS description,
VA_CD_ABB_DESC as title,
CAST(VA_CD_KEY AS INTEGER) AS sort_order,
CASE VA_CD_ACTIVE_FL
WHEN 'Y' THEN NULL
WHEN 'N' THEN '1/1/1970'
END AS date_disabled,
VA_CD_LOC AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM VA_CD

UNION SELECT 'ABN_BHV_CD_' || ABN_BHV_CD_KEY AS objectid,
'abnormal_behavior_codes' AS set_name,
ABN_BHV_CD_KEY AS  "value",
ABN_BHV_CD_DESC AS description,
ABN_BHV_CD_ABB_DESC AS title,
CAST(ABN_BHV_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
FLG_RSN_CD_KEY AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ABN_BHV_CD

UNION SELECT 'ABN_CD_' || ABN_CD_KEY AS objectid,
'abnormal_codes' AS set_name,
ABN_CD_KEY AS  "value",
ABN_CD_DESC AS description,
ABN_CD_ABB_DESC as title,
CAST(ABN_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
FLG_RSN_CD_KEY AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ABN_CD

UNION SELECT 'EXC_CD_' || EXC_CD_KEY AS objectid,
'exception_codes' AS set_name,
EXC_CD_KEY AS  "value",
EXC_CD_DESC AS description,
EXC_CD_DESC as title,
CAST(EXC_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM EXC_CD

UNION SELECT 'FLG_EVENT_CD_' || FLG_EVENT_CD_KEY AS objectid,
'flag_event_codes' AS set_name,
FLG_EVENT_CD_KEY AS  "value",
FLG_EVENT_CD_DESC AS description,
FLG_EVENT_CD_ABB_DESC as title,
CAST(FLG_EVENT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM FLG_EVENT_CD

UNION SELECT 'HP_PATTERN_CD_' || HP_PATTERN_CD_KEY AS objectid,
'hair_plucking_pattern_codes' AS set_name,
HP_PATTERN_CD_KEY AS  "value",
HP_PATTERN_CD_DESC AS description,
HP_PATTERN_CD_ABB_DESC as title,
CAST(HP_PATTERN_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM HP_PATTERN_CD

UNION SELECT 'MV_CD_' || MV_CD_KEY AS objectid,
'move_codes' AS set_name,
MV_CD_KEY AS  "value",
MV_CD_DESC AS description,
MV_CD_DESC as title,
CAST(MV_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM MV_CD

UNION SELECT 'WND_CD_' || WND_CD_KEY AS objectid,
'wound_codes' AS set_name,
WND_CD_KEY AS  "value",
WND_CD_DESC AS description,
WND_CD_DESC as title,
CAST(WND_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM WND_CD

UNION SELECT 'BM_BOX_CD_' || BM_BOX_CD_KEY AS objectid,
'bm_box_codes' AS set_name,
BM_BOX_CD_KEY AS  "value",
BM_BOX_CD_DESC AS description,
BM_BOX_CD_ABB_DESC as title,
CAST(BM_BOX_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM BM_BOX_CD

UNION SELECT 'SPM_CD_CLASS_CD_' || SPM_CD_CLASS_CD_KEY AS objectid,
'spm_cd_class_codes' AS set_name,
SPM_CD_CLASS_CD_KEY AS  "value",
NULL AS description,
SPM_CD_CLASS_CD_DESC as title,
CAST(SPM_CD_CLASS_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM SPM_CD_CLASS_CD

UNION SELECT 'BT_CD_' || BT_CD_KEY AS objectid,
'bt_codes' AS set_name,
BT_CD_KEY AS  "value",
BT_CD_DESC AS description,
BT_CD_ABB_DESC as title,
CAST(BT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM BT_CD

UNION SELECT 'OCT_CD_' || OCT_CD_KEY AS objectid,
'oct_codes' AS set_name,
OCT_CD_KEY AS  "value",
OCT_CD_DESC AS description,
OCT_CD_ABB_DESC as title,
CAST(OCT_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM OCT_CD

UNION SELECT 'CENSUS_CD_' || CENSUS_CD_KEY AS objectid,
'census_codes' AS set_name,
CENSUS_CD_KEY AS  "value",
CENSUS_CD_DESC AS description,
CENSUS_CD_ABB_DESC as title,
CAST(CENSUS_CD_KEY AS INTEGER) AS sort_order,
NULL AS date_disabled,
NULL AS category,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CENSUS_CD

UNION SELECT 'PHX_TEST_TYPE_1' AS objectid,
'phx_test_types' AS set_name,
'WT Diff' AS value,
'WT Diff' AS description,
'WT Diff' AS title,
1 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_2' AS objectid,
'phx_test_types' AS set_name,
'RT Popliteal' AS value,
'RT Popliteal' AS description,
'RT Popliteal' AS title,
2 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_3' AS objectid,
'phx_test_types' AS set_name,
'LT Popliteal' AS value,
'LT Popliteal' AS description,
'LT Popliteal' AS title,
3 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_4' AS objectid,
'phx_test_types' AS set_name,
'RT Inguinal' AS value,
'RT Inguinal' AS description,
'RT Inguinal' AS title,
4 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_5' AS objectid,
'phx_test_types' AS set_name,
'LT Inguinal' AS value,
'LT Inguinal' AS description,
'LT Inguinal' AS title,
5 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_6' AS objectid,
'phx_test_types' AS set_name,
'RT Axillary' AS value,
'RT Axillary' AS description,
'RT Axillary' AS title,
6 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_7' AS objectid,
'phx_test_types' AS set_name,
'LT Axillary' AS value,
'LT Axillary' AS description,
'LT Axillary' AS title,
7 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_8' AS objectid,
'phx_test_types' AS set_name,
'Spleen' AS value,
'Spleen' AS description,
'Spleen' AS title,
8 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_9' AS objectid,
'phx_test_types' AS set_name,
'Submandibular' AS value,
'Submandibular' AS description,
'Submandibular' AS title,
9 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_10' AS objectid,
'phx_test_types' AS set_name,
'Stool' AS value,
'Stool' AS description,
'Stool' AS title,
10 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_11' AS objectid,
'phx_test_types' AS set_name,
'RSV Pulse' AS value,
'RSV Pulse' AS description,
'RSV Pulse' AS title,
11 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_12' AS objectid,
'phx_test_types' AS set_name,
'RSV Heart Rate' AS value,
'RSV Heart Rate' AS description,
'RSV Heart Rate' AS title,
12 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'PHX_TEST_TYPE_13' AS objectid,
'phx_test_types' AS set_name,
'RSV Resp Rate' AS value,
'RSV Resp Rate' AS description,
'RSV Resp Rate' AS title,
13 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2019-01-22' AS updated_at,
FALSE AS RECORD_DELETED

UNION SELECT 'DNT_LOCATION_CD_1' AS objectid,
'dnt_location_codes' AS set_name,
'ABS_LL' AS value,
'Absent Lower Left' AS description,
'Absent Lower Left' AS title,
1 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2018-12-18' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'DNT_LOCATION_CD_2' AS objectid,
'dnt_location_codes' AS set_name,
'ABS_LR' AS value,
'Absent Lower Right' AS description,
'Absent Lower Right' AS title,
2 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2018-12-18' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'DNT_LOCATION_CD_3' AS objectid,
'dnt_location_codes' AS set_name,
'ABS_UL' AS value,
'Absent Upper Left' AS description,
'Absent Upper Left' AS title,
3 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2018-12-18' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'DNT_LOCATION_CD_4' AS objectid,
'dnt_location_codes' AS set_name,
'ABS_UR' AS value,
'Absent Upper Right' AS description,
'Absent Upper Right' AS title,
4 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2018-12-18' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'DNT_LOCATION_CD_5' AS objectid,
'dnt_location_codes' AS set_name,
'EXT_LL' AS value,
'Extracted Lower Left' AS description,
'Extracted Lower Left' AS title,
5 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2018-12-18' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'DNT_LOCATION_CD_6' AS objectid,
'dnt_location_codes' AS set_name,
'EXT_LR' AS value,
'Extracted Lower Right' AS description,
'Extracted Lower Right' AS title,
6 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2018-12-18' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'DNT_LOCATION_CD_7' AS objectid,
'dnt_location_codes' AS set_name,
'EXT_UL' AS value,
'Extracted Upper Left' AS description,
'Extracted Upper Left' AS title,
7 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2018-12-18' AS updated_at,
FALSE AS RECORD_DELETED
UNION SELECT 'DNT_LOCATION_CD_8' AS objectid,
'dnt_location_codes' AS set_name,
'EXT_UR' AS value,
'Extracted Upper Right' AS description,
'Extracted Upper Right' AS title,
8 AS sort_order,
NULL AS date_disabled,
NULL AS category,
'2018-12-18' AS updated_at,
FALSE AS RECORD_DELETED