/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT *
FROM 
(
SELECT
'ABN_DTL-' || VRT_DTL_KEY AS objectid,
VRT_KEY AS parentid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN VRT_DTL_TIME IS NULL
  THEN CAST(VRT_DTL_DT AS TIMESTAMP)
  ELSE CAST((VRT_DTL_DT || ' ' || VRT_DTL_TIME) AS TIMESTAMP)
  END AS "date",
CAST(ASSAY_CD_KEY AS VARCHAR(4000)) AS "assay_code",
CASE WHEN MICRO_LAB_SENT_CD_KEY = 'N' THEN NULL -- See reason in issue 32541
  ELSE CAST(MICRO_LAB_SENT_CD_KEY AS INTEGER)
  END AS "micro_lab_sent_code",
CAST(MICRO_SMP_SPM_CD_KEY AS INTEGER) AS "micro_smp_spm_code",
CAST(MICRO_SPM_CD_KEY AS VARCHAR(4000)) AS "micro_spm_code",
CAST(RSLT_CD_KEY AS INTEGER) AS "result_code",
CAST(VRT_DTL_ASSAY_DT AS TIMESTAMP) AS "assay_dt",
CAST(VRT_DTL_BILL_DT AS TIMESTAMP) AS "bill_dt",
CAST(VRT_DTL_BILL_PROJ_KEY AS INTEGER) AS "project",
CAST(VRT_DTL_COM AS VARCHAR(4000)) AS "remark",
CAST(VRT_DTL_IT_DT AS TIMESTAMP) AS "it_dt",
CAST(VRT_DTL_IT_NUM AS INTEGER) AS "it_num",
CAST(VRT_DTL_OPT_DENSITY AS VARCHAR(4000)) AS "opt_density", -- double
CAST(VRT_DTL_POOLED_SMP_FL AS VARCHAR(4000)) AS "pooled_smp_fl", -- boolean, see Issue 33829
CAST(VRT_DTL_POOLED_SMP_ID_DT AS TIMESTAMP) AS "pooled_smp_id_dt",
CAST(VRT_DTL_POOLED_SMP_ID_NUM AS INTEGER) AS "pooled_smp_id_num",
CAST(VRT_DTL_RESULT AS VARCHAR(4000)) AS "result",
CASE WHEN VRT_DTL_RETEST_FL='Y' THEN TRUE
  WHEN VRT_DTL_RETEST_FL='N' THEN FALSE
  ELSE NULL END AS retest_fl,
CAST(VRT_DTL_SHIP_DT AS TIMESTAMP) AS "ship_dt",
CAST(VRT_DTL_SMP_STORAGE AS VARCHAR(4000)) AS "smp_storage",
CAST(VRT_DTL_TITRE AS VARCHAR(4000)) AS "titre",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
CAST(UPDATE_DATETIME AS TIMESTAMP) AS updated_at,
RECORD_DELETED
FROM VRT_DTL
) AS vrt_dtl
WHERE RECORD_DELETED = FALSE