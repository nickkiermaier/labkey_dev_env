/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
'PHX_RSV__AUSC_CD_KEY_A-' || CAST(child.MVON_KEY AS VARCHAR(4000)) || '-' || CAST(child.VALUE_INDEX AS VARCHAR(4000)) AS objectid,
rsv.UPDATE_DATETIME AS updated_at
FROM PHX_RSV__AUSC_CD_KEY_A AS child
JOIN PHX_RSV AS rsv ON child.MVON_KEY = rsv.MVON_KEY
WHERE RECORD_DELETED = TRUE

UNION SELECT
'PHX_RSV_OCULAR_DISC_CD_KEY-' || CAST(PHX_RSV_KEY AS VARCHAR(4000)) AS objectid,
UPDATE_DATETIME AS updated_at
FROM PHX_RSV
WHERE OCULAR_DISC_CD_KEY IS NOT NULL
  AND RECORD_DELETED = TRUE

UNION SELECT
'PHX_RSV_NASAL_DISC_CD_KEY-' || CAST(PHX_RSV_KEY AS VARCHAR(4000)) AS objectid,
UPDATE_DATETIME AS updated_at
FROM PHX_RSV
WHERE NASAL_DISC_CD_KEY IS NOT NULL
  AND RECORD_DELETED = TRUE

UNION SELECT
'PHX_RSV__RESP_CD_KEY_A-' || CAST(child.MVON_KEY AS VARCHAR(4000)) || '-' || CAST(child.VALUE_INDEX AS VARCHAR(4000)) AS objectid,
rsv.UPDATE_DATETIME AS updated_at
FROM PHX_RSV__RESP_CD_KEY_A AS child
JOIN PHX_RSV AS rsv ON child.MVON_KEY = rsv.MVON_KEY
WHERE rsv.RECORD_DELETED = TRUE

UNION SELECT
'PHX__VIT_CD_KEY_A-' || CAST(child.MVON_KEY AS VARCHAR(4000)) || '-' || CAST(child.VALUE_INDEX AS VARCHAR(4000)) AS objectid,
UPDATE_DATETIME AS updated_at
FROM PHX__VIT_CD_KEY_A AS child
JOIN PHX AS phx ON child.MVON_KEY = phx.MVON_KEY
WHERE RECORD_DELETED = TRUE
