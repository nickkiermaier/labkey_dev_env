/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT PRTCL_KEY AS protocol,
PRTCL_APPROVAL_DT AS first_approval,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CASE WHEN UPDATE_PERSON IS NULL THEN 'UNKNOWN'
  ELSE CAST(UPDATE_PERSON AS VARCHAR(4000)) END AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CASE WHEN UPDATE_PERSON IS NULL THEN 'UNKNOWN'
  ELSE CAST(UPDATE_PERSON AS VARCHAR(4000)) END AS modifiedBy,
UPDATE_DATETIME AS updated_at
FROM PRTCL
WHERE RECORD_DELETED = FALSE