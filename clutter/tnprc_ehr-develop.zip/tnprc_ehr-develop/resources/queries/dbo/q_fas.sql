/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
FAS_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN FAS_TIME IS NULL
THEN CAST(FAS_DT AS TIMESTAMP)
ELSE CAST((FAS_DT || ' ' || FAS_TIME) AS TIMESTAMP)
END AS "date",
CAST(FAS_ASP_HRS_POST_HCG AS DOUBLE) AS "asp_hrs_post_hcg",
CAST(FAS_BILL_PROJ_KEY AS INTEGER) AS "project",
CAST(FAS_COM AS VARCHAR(4000)) AS "remark",
CAST(FAS_DRG_CYCLE_DAY AS INTEGER) AS "drg_cycle_day",
CAST(FAS_DRG_DURATION AS DOUBLE) AS "drg_duration",
CAST(FAS_LEFT_CM AS DOUBLE) AS "left_cm",
CAST(FAS_LEFT_GRADE AS INTEGER) AS "left_grade",
CAST(FAS_LEFT_NUM_EGGS AS INTEGER) AS "left_num_eggs",
CAST(FAS_RIGHT_CM AS DOUBLE) AS "right_cm",
CAST(FAS_RT_GRADE AS INTEGER) AS "rt_grade",
CAST(FAS_RT_NUM_EGGS AS INTEGER) AS "rt_num_eggs",
CAST(FAS_TOTAL_NUM_EGGS AS INTEGER) AS "total_num_eggs",
CAST(LAB_SENT_CD_KEY AS INTEGER) AS "lab_sent_code",
CAST(PRC_KEY AS VARCHAR(4000)) AS "parentid",
CAST(VET_PERS_KEY AS INTEGER) AS "vet_pers_key",
CAST(WT_KEY AS INTEGER) AS "wt_key", 
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM FAS 
WHERE RECORD_DELETED = 'false' 
