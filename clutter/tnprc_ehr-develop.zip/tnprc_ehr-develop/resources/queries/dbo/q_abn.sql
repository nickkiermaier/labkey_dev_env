/*
 * Copyright (c) 2017-2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


SELECT
ABN_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CAST(ABN_DT AS TIMESTAMP) AS "date",
CASE WHEN ABN_ANESTHESIA_FL='Y' THEN 'true' WHEN ABN_ANESTHESIA_FL='N' THEN 'false' ELSE NULL END AS "anesthesia_fl",
CAST(ABN_BILL_PROJ_KEY AS INTEGER) AS "project",
CAST(ABN_COM AS VARCHAR(4000)) AS "remark", -- varchar
CAST(ABN_COMMENT AS VARCHAR(4000)) AS "comment",
CASE WHEN ABN_DTL_FL='Y' THEN 'true' WHEN ABN_DTL_FL='N' THEN 'false' ELSE NULL END AS "dtl_fl",
CAST(ABN_PE_FLAG AS VARCHAR(4000)) AS "pe_flag",
CAST(ABN_RESOLVE_DT AS VARCHAR(4000)) AS "resolve_dt",
CAST(ABN_TEST_DT_LOC_CD_KEY AS VARCHAR(4000)) AS "test_dt_loc_code",
CAST(ABN_TEST_DT_LOC_CG AS INTEGER) AS "test_dt_loc_cg",
CAST(FLG_RSN_CD_KEY AS VARCHAR(4000)) AS "flg_rsn_code",
CAST(HP_ABN_CD_KEY AS INTEGER) AS "hp_abn_code",
CAST(HP_FRQ AS INTEGER) AS "hp_frq",
CAST(HP_PATTERN_CD_KEY AS INTEGER) AS "hp_pattern_code",
CAST(PERS_KEY AS INTEGER) AS "pers_key",
CAST(PRC_KEY AS VARCHAR(4000)) AS "parentid",
CAST(SOC_HSE_CD_KEY AS VARCHAR(4000)) AS "soc_hse_code",
CAST(WND_CD_KEY AS INTEGER) AS "wnd_code",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ABN