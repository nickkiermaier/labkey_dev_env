/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT LOC_CD_KEY as room,
CASE WHEN locate('/', LOC_CD_KEY) > 0
  THEN substring(LOC_CD_KEY, 1, locate('/', LOC_CD_KEY) - 1)
  ELSE LOC_CD_KEY END AS area,
LOC_CD_DESC as description,
CAST(LOC_CAT_CD_KEY AS INTEGER) as housingType,
CASE WHEN LOC_CD_ACTIVE_FL = 'N' THEN '1/1/1970'
  ELSE NULL END as dateDisabled,
HSE_CAT_CD_KEY as hse_cat_code,
SOC_HSE_CD_KEY as soc_hse_code,
CREW_CD_KEY as crew_code,
LOC_CD_CREW as crew,
CASE WHEN LOC_CD_CG_FL = 'Y' THEN TRUE
  WHEN LOC_CD_CG_FL = 'N' THEN FALSE
  ELSE NULL END as cage_fl,
CASE WHEN LOC_CD_TELEMETRY_FL = 'Y' THEN TRUE
  WHEN LOC_CD_TELEMETRY_FL = 'N' THEN FALSE
  ELSE NULL END as telemetry_fl,
CASE WHEN LOC_CD_VIEW_FL = 'Y' THEN TRUE
  WHEN LOC_CD_VIEW_FL = 'N' THEN FALSE
  ELSE NULL END as view_fl,
child.LOC_CD_VIEW_CG as view_cg,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at
FROM LOC_CD
LEFT JOIN LOC_CD__LOC_CD_VIEW_CG_A child on LOC_CD.MVON_KEY = child.MVON_KEY
WHERE RECORD_DELETED = FALSE