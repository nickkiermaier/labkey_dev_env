/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

-- TODO this needs to be defined for the TNPRC age class definition, i.e. to include per-species or per-gender info
SELECT 'Infant' AS label, NULL AS species, NULL AS gender, 1 AS ageclass, 0.0 AS "min", 1.0 AS "max", CAST('2018-04-19' AS TIMESTAMP) AS updated_at
UNION SELECT 'Juvenile' AS label, NULL AS species, NULL AS gender, 2 AS ageclass, 1.0 AS "min", 3.0 AS "max", CAST('2018-04-19' AS TIMESTAMP) AS updated_at
UNION SELECT 'Adult' AS label, NULL AS species, NULL AS gender, 3 AS ageclass, 3.0 AS "min", 18.0 AS "max", CAST('2018-04-19' AS TIMESTAMP) AS updated_at
UNION SELECT 'Senior' AS label, NULL AS species, NULL AS gender, 4 AS ageclass, 18.0 AS "min", NULL AS "max", CAST('2018-04-19' AS TIMESTAMP) AS updated_at