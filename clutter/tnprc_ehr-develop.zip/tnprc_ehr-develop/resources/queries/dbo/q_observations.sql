/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
CAST(OBS_KEY AS VARCHAR(4000)) as objectid,
CAST(CASE WHEN OBS.AM_KEY IS NULL THEN prc.AM_KEY ELSE OBS.AM_KEY END AS VARCHAR(4000)) as id,
OBS_DT || (CASE WHEN OBS_TIME IS NOT NULL THEN (' ' || substring(OBS_TIME, 0, 9)) ELSE '' END) AS "date",
CAST(OBS.PRC_KEY AS VARCHAR(4000)) as parentid,
CAST(OBS_COM AS VARCHAR(4000)) AS "remark",
CAST(VET_PERS_KEY AS INTEGER) as vet_code,
CAST(OBS_BILL_PROJ_KEY AS INTEGER) as project,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM OBS
  -- Fix for issue 31375
  LEFT JOIN (SELECT PRC_KEY, AM_KEY FROM PRC WHERE PRC_KEY IN (SELECT PRC_KEY FROM OBS WHERE AM_KEY IS NULL)) AS prc ON prc.PRC_KEY = OBS.PRC_KEY