/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
MSL_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN MSL_TIME IS NULL
THEN CAST(MSL_DT AS TIMESTAMP)
ELSE CAST((MSL_DT || ' ' || MSL_TIME) AS TIMESTAMP)
END AS "date",
CAST(MAJ_PRC_CD_KEY AS VARCHAR(4000)) AS "maj_prc_code",
CAST(MIN_PRC_CD_KEY AS VARCHAR(4000)) AS "min_prc_code",
CAST(MSL_AGA_IGG_UNITS AS VARCHAR(4000)) AS "aga_igg_units",
CAST(MSL_BILL_PROJ_KEY AS INTEGER) AS "project",
CAST(MSL_COM AS VARCHAR(4000)) AS "remark",
CAST(MSL_GLUCOSE AS INTEGER) AS "glucose",
CAST(MSL_GLUTEN_SENS_POS_NEG AS VARCHAR(4000)) AS "gluten_sens_pos_neg",
CAST(MSL_LOT_NUM AS VARCHAR(4000)) AS "lot_num",
CAST(MSL_TITRE AS VARCHAR(4000)) AS "titre",
CAST(PRC_KEY AS VARCHAR(4000)) AS "parentid",
CAST(PUR_CD_KEY AS INTEGER) AS "pur_code",
CAST(VET_PERS_KEY AS INTEGER) AS "vet_pers_key",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM MSL 
WHERE RECORD_DELETED = 'false' 
