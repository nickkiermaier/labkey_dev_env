/*
 * Copyright (c) 2018-2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
child.NCR_TSS_KEY AS objectid,
child.NCR_KEY AS parentid,
CASE WHEN child.AM_KEY IS NOT NULL THEN CAST(child.AM_KEY AS VARCHAR(4000))
  WHEN parent.AM_KEY IS NOT NULL THEN CAST(parent.AM_KEY AS VARCHAR(4000))
  ELSE NULL END AS id,
CASE WHEN child.NCR_TSS_DT IS NOT NULL THEN CAST(NCR_TSS_DT AS TIMESTAMP)
  WHEN parent.NCR_DT IS NOT NULL THEN CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
  ELSE NULL END AS "date",
CAST(child.INSIDE_INVEST_PERS_KEY AS INTEGER) AS "inside_invest_pers_key",
CASE WHEN LAB_SENT_CD_IN_OUT_FL='Y' THEN 'true' WHEN LAB_SENT_CD_IN_OUT_FL='N' THEN 'false' ELSE NULL END AS "lab_sent_cd_in_out_fl",
CAST(child.LAB_SENT_CD_KEY AS INTEGER) AS "lab_sent_code",
CAST(child.LAB_SENT_CD_KEY_INSIDE AS INTEGER) AS "lab_sent_cd_key_inside",
CAST(child.NCR_TSS_CD_KEY AS INTEGER) AS "code",
CAST(child.NCR_TSS_IMPORT_DT AS TIMESTAMP) AS "import_dt",
CAST(child.OCT_CD_KEY AS INTEGER) AS "oct_code",
CAST(child.OUT_INV_CD_KEY AS INTEGER) AS "out_inv_code",
CAST(SPM_CD_KEY AS VARCHAR(4000)) AS "spm_code",
CAST(child.UPDATE_DATE || ' ' || child.UPDATE_TIME AS TIMESTAMP) AS created,
CAST(child.UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(child.UPDATE_DATE || ' ' || child.UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(child.UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
child.UPDATE_DATETIME AS updated_at,
child.RECORD_DELETED
FROM NCR_TSS AS child
LEFT JOIN NCR AS parent ON parent.MVON_KEY = child.NCR_KEY