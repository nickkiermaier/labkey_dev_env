/*
 * Copyright (c) 2017-2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
CAST(dtl.MVON_KEY AS VARCHAR(4000)) AS objectid,
CAST(dtl.MAS_KEY AS VARCHAR(4000)) AS parentid,
CAST(mas.AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN mas.MAS_TIME IS NULL
  THEN CAST(mas.MAS_DT AS TIMESTAMP)
  ELSE CAST((mas.MAS_DT || ' ' || MAS_TIME) AS TIMESTAMP)
  END AS "date",
CAST(CELL_CD_KEY AS INTEGER) AS "cell_code",
CAST(HORIZ_ANTIBODY_CD_KEY AS INTEGER) AS "horiz_antibody_code",
CAST(HORIZ_STAIN_CD_KEY AS INTEGER) AS "horiz_stain_code",
CAST(MAS_DTL_COM AS VARCHAR(4000)) AS "remark",
CAST(MAS_DTL_SECT1 AS DOUBLE) AS "sect1",
CAST(MAS_DTL_SECT2 AS DOUBLE) AS "sect2",
CAST(MAS_DTL_SECT3 AS DOUBLE) AS "sect3",
CAST(MAS_DTL_SECT4 AS DOUBLE) AS "sect4",
CAST(MAS_TEST_CD_KEY AS INTEGER) AS "mas_test_code",
CAST(VERT_ANTIBODY_CD_KEY AS INTEGER) AS "vert_antibody_code",
CAST(VERT_STAIN_CD_KEY AS INTEGER) AS "vert_stain_code",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
CAST(dtl.UPDATE_DATETIME AS TIMESTAMP) AS updated_at,
dtl.RECORD_DELETED
FROM MAS_DTL AS dtl
LEFT JOIN MAS AS mas ON mas.MVON_KEY = dtl.MAS_KEY
WHERE dtl.RECORD_DELETED = 'false'
