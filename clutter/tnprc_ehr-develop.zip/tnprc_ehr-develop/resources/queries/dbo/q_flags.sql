/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
FLG_KEY as objectid,
CAST(AM_KEY AS VARCHAR(4000)) as id,
CAST(FLG_DT AS TIMESTAMP) as date,
CASE WHEN RECORD_DELETED = TRUE THEN NULL ELSE CAST(FLG_INACTIVE_DT AS TIMESTAMP) END AS "enddate",
CAST(FLG_DORMANCY_DT AS TIMESTAMP) AS "dormancy_dt",
CASE WHEN FLG_ACTIVE_FL='Y' THEN TRUE
  WHEN FLG_ACTIVE_FL='N' THEN FALSE
  ELSE NULL END AS "active_fl",
CAST(DPT_CD_KEY AS INTEGER) AS "dpt_code",
CAST(FLG_RSN_CD_KEY AS INTEGER) AS "flag",
CAST(PERS_KEY AS INTEGER) AS "pers_key",
FLG_COM AS remark,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM FLG
WHERE RECORD_DELETED = FALSE