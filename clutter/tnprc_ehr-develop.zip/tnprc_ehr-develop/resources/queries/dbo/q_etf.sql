/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
ETF_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CAST(ENR_CAT_CD_KEY AS INTEGER) AS "enr_cat_code",
CAST(ENR_RSN_CD_KEY AS INTEGER) AS "enr_rsn_code",
CAST(ETF_ASSIGN_DT AS TIMESTAMP) AS "date",
CAST(ETF_COM AS VARCHAR(4000)) AS "remark",
CASE WHEN ETF_DIFFERENCE_FL='Y' THEN 'true' WHEN ETF_DIFFERENCE_FL='N' THEN 'false' ELSE NULL END AS "difference_fl",
CAST(ETF_RELEASE_DT AS TIMESTAMP) AS "release_dt",
CAST(ETF_REVIEW_DT AS VARCHAR(4000)) AS "review_dt",--timestamp
CAST(HSE_CAT_CD_KEY AS INTEGER) AS "hse_cat_code",
CAST(PERS_KEY AS INTEGER) AS "pers_key",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at
FROM ETF
WHERE RECORD_DELETED = FALSE
