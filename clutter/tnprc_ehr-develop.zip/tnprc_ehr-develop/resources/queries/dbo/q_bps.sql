/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
BPS_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CAST(BPS_DT AS TIMESTAMP) AS "date",
CAST(BPS_ADDENDUM AS VARCHAR(4000)) AS "addendum",
CAST(BPS_BILL_PROJ_KEY AS INTEGER) AS "project",
CAST(BPS_CLN_HISTORY AS VARCHAR(4000)) AS "cln_history",
CAST(BPS_COM AS VARCHAR(4000)) AS "remark",
CAST(BPS_DIAGNOSIS_COM AS VARCHAR(4000)) AS "diagnosis_com",
CAST(BPS_HISTO_COM AS VARCHAR(4000)) AS "histo_com",
CAST(BPS_NUM AS VARCHAR(4000)) AS "num",
CAST(PATH_PERS_KEY AS INTEGER) AS "path_pers_key",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED 
FROM BPS 
WHERE RECORD_DELETED = 'false'
