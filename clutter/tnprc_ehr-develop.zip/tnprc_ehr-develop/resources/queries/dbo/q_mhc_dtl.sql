/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
CAST(MHC_DTL_KEY AS VARCHAR(4000)) AS objectid,
CAST(MHC_KEY AS INTEGER) AS parentid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CAST(MHC_DTL_DT AS TIMESTAMP) AS "date",
CAST(ALLELE_CD_KEY AS INTEGER) AS "allele_code",
CAST(LAB_SENT_CD_KEY AS INTEGER) AS "lab_sent_code",
CAST(MHC_DTL_BILL_DT AS TIMESTAMP) AS "bill_dt",
CAST(MHC_DTL_BILL_PROJ_KEY AS INTEGER) AS "project",
CAST(MHC_DTL_LAB_RSLT_DT AS VARCHAR(4000)) AS "lab_rslt_dt",
CAST(MHC_DTL_RESULT AS VARCHAR(4000)) AS "result",
CASE WHEN MHC_DTL_RESULT_CNFM_FL='Y' THEN 'true' WHEN MHC_DTL_RESULT_CNFM_FL='N' THEN 'false' ELSE NULL END AS "result_cnfm_fl",
CAST(MHC_DTL_RUNS_CNTR AS INTEGER) AS "runs_cntr",
CAST(MHC_DTL_SHIP_DT AS TIMESTAMP) AS "ship_dt",
CAST(MHC_DTL_SMP_STORAGE AS VARCHAR(4000)) AS "smp_storage",
CAST(MHC_DTL_SNP_RESULT AS VARCHAR(4000)) AS "snp_result",
CAST(SMP_SPM_CD_KEY AS INTEGER) AS "smp_spm_code",
CAST(SNP_ALLELE_CD_KEY AS INTEGER) AS "snp_allele_code",
CAST(SNP_LAB_SENT_CD_KEY AS INTEGER) AS "snp_lab_sent_code",
CAST(SNP_SMP_SPM_CD_KEY AS INTEGER) AS "snp_smp_spm_code",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
CAST(UPDATE_DATETIME AS TIMESTAMP) AS updated_at
FROM MHC_DTL
WHERE MHC_DTL_DT IS NOT NULL AND RECORD_DELETED = FALSE