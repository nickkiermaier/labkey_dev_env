/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT AM_KEY AS objectid,
    AM_KEY AS id,
    CASE WHEN AM_ENTRY_DT IS NULL THEN '10/01/1964'
        ELSE AM_ENTRY_DT END AS "date",
    CASE WHEN AM_ENTRY_DT IS NULL
        THEN 'Using default date value of 10/01/1964 since AM_ENTRY_DT was NULL for this record.'
        ELSE NULL END AS remark,
    CAST(EC_CD_KEY AS INTEGER) as entry_cat_code,
    CAST(VEN_CD_KEY AS INTEGER) as vendor_code,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM AM
WHERE EC_CD_KEY IS NOT NULL AND EC_CD_KEY <> 1 -- 1 is Born at Tulane