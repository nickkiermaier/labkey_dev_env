/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT child.MVON_KEY as cs_cause_code,
  'D-' || child.DS_CD_KEY as snomed,
  child.VALUE_INDEX as value_index,
  UPDATE_DATETIME AS updated_at,
  RECORD_DELETED
FROM CS_CAUSE_CD__DS_CD_KEY_A AS child
  JOIN CS_CAUSE_CD AS parent ON child.MVON_KEY = parent.MVON_KEY

UNION SELECT child.MVON_KEY as cs_cause_code,
  'E-' || child.ET_CD_KEY as snomed,
  child.VALUE_INDEX as value_index,
  UPDATE_DATETIME AS updated_at,
  RECORD_DELETED
FROM CS_CAUSE_CD__ET_CD_KEY_A AS child
  JOIN CS_CAUSE_CD AS parent ON child.MVON_KEY = parent.MVON_KEY

UNION SELECT child.MVON_KEY as cs_cause_code,
  'F-' || child.FNC_CD_KEY as snomed,
  child.VALUE_INDEX as value_index,
  UPDATE_DATETIME AS updated_at,
  RECORD_DELETED
FROM CS_CAUSE_CD__FNC_CD_KEY_A AS child
  JOIN CS_CAUSE_CD AS parent ON child.MVON_KEY = parent.MVON_KEY

UNION SELECT child.MVON_KEY as cs_cause_code,
  'M-' || child.MRP_CD_KEY as snomed,
  child.VALUE_INDEX as value_index,
  UPDATE_DATETIME AS updated_at,
  RECORD_DELETED
FROM CS_CAUSE_CD__MRP_CD_KEY_A AS child
  JOIN CS_CAUSE_CD AS parent ON child.MVON_KEY = parent.MVON_KEY

UNION SELECT child.MVON_KEY as cs_cause_code,
  'P-' || child.PROC_CD_KEY as snomed,
  child.VALUE_INDEX as value_index,
  UPDATE_DATETIME AS updated_at,
  RECORD_DELETED
FROM CS_CAUSE_CD__PROC_CD_KEY_A AS child
  JOIN CS_CAUSE_CD AS parent ON child.MVON_KEY = parent.MVON_KEY

UNION SELECT child.MVON_KEY as cs_cause_code,
  'T-' || child.TOP_CD_KEY as snomed,
  child.VALUE_INDEX as value_index,
  UPDATE_DATETIME AS updated_at,
  RECORD_DELETED
FROM CS_CAUSE_CD__TOP_CD_KEY_A AS child
  JOIN CS_CAUSE_CD AS parent ON child.MVON_KEY = parent.MVON_KEY