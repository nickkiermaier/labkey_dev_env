/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
SELECT
CAST('AM__TAG_CD_KEY_A-' || AM__TAG_CD_KEY_A.MVON_KEY AS VARCHAR(4000)) || '-' || CAST(VALUE_INDEX AS VARCHAR(4000)) as objectid,
AM.MVON_KEY AS parentid,
CAST(AM_KEY AS VARCHAR(4000)) as id,
CAST(AM_ENTRY_DT AS DATE) as "date",
VALUE_INDEX as value_index,
TAG_CD_KEY as tag_code,
AM_TAG_ID_NUM as tag_num,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM AM__TAG_CD_KEY_A
LEFT JOIN AM ON AM__TAG_CD_KEY_A.MVON_KEY = AM.MVON_KEY 
WHERE RECORD_DELETED = 'false'
