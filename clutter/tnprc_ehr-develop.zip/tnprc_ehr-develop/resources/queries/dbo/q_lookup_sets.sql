/*
 * Copyright (c) 2017-2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 'acetone_codes' AS setname, 'Acetone Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'albumin_codes' AS setname, 'Albumin Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'allele_codes' AS setname, 'Allele Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'age_est_codes' AS setname, 'Age Estimate Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'assay_codes' AS setname, 'Assay Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'ausc_codes' AS setname, 'Auscultation Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'bill_cat_codes' AS setname, 'Billing Category Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'birth_codes' AS setname, 'Birth Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'bldg_codes' AS setname, 'Building Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'bo_except_codes' AS setname, 'Business Office Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'cancel_codes' AS setname, 'Cancel Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'casts_codes' AS setname, 'Casts Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'cell_codes' AS setname, 'Cell Test Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'chain_codes' AS setname, 'Chain Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'chm_serum_codes' AS setname, 'Chemistry Serum Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'chr_codes' AS setname, 'Character Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'class_codes' AS setname, 'Class Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'color_codes' AS setname, 'Color Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'cnd_codes' AS setname, 'Condition Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'cryst_codes' AS setname, 'Crystal Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'degree_codes' AS setname, 'Degree Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'diff_codes' AS setname, 'Differential Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'disc_codes' AS setname, 'Discharge Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'dm_codes' AS setname, 'Dye Mark Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'dnt_codes' AS setname, 'Dental Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'drh_codes' AS setname, 'Diarrhea Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'dth_codes' AS setname, 'Cause of Death Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'ec_codes' AS setname, 'Entry Category Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'ejc_coll_pur_codes' AS setname, 'Ejaculation Collection Purpose Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'ejc_mth_codes' AS setname, 'Ejaculation Method Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'enr_cat_codes' AS setname, 'Enrich Category Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'enr_dev_codes' AS setname, 'Enrich Device Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'enr_rsn_codes' AS setname, 'Enrich Reason Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'epth_codes' AS setname, 'Epithelial Cell Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'ex_codes' AS setname, 'Exam Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'flg_rsn_codes' AS setname, 'Flag Reason Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'fnd_src_type_codes' AS setname, 'Funding Source Type Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'fnd_type_codes' AS setname, 'Funding Type Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'ht_codes' AS setname, 'Hema Type Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'inoc_index_codes' AS setname, 'Inoculation Index Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'inoc_mth_codes' AS setname, 'Inoculation Method Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'inoc_type_codes' AS setname, 'Inoculum Type Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'insur_codes' AS setname, 'Insurance Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'lymph_codes' AS setname, 'Atypical-Lymphs Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'mas_test_codes' AS setname, 'MAS Test Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'mtf_rsn_codes' AS setname, 'Menses Reason Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'mth_codes' AS setname, 'Method Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'nc_rsn_codes' AS setname, 'No Charge Reason Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-05-06' AS TIMESTAMP) AS updated_at
UNION SELECT 'ncr_int_codes' AS setname, 'Necropsy Interval Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'obs_codes' AS setname, 'Observation Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'oclt_codes' AS setname, 'Occult Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'pers_fnc_codes' AS setname, 'Personnel Function Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'prc_codes' AS setname, 'Procedure Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'prg_codes' AS setname, 'Pregnancy Result Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'proj_amend_rsn_codes' AS setname, 'Project Amend Reason Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'pst_codes' AS setname, 'Project Status Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'pur_codes' AS setname, 'Purpose Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'rad_codes' AS setname, 'Radiograph Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'real_time_codes' AS setname, 'Real Time Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'resp_codes' AS setname, 'Respiratory Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'rslt_file_codes' AS setname, 'Result File Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'rsn_codes' AS setname, 'Reason Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'rt_codes' AS setname, 'Route Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'sens_codes' AS setname, 'Sensitivity Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'sgr_codes' AS setname, 'Sugar Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'sig_codes' AS setname, 'Significance Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'smp_loc_cd_mfg_codes' AS setname, 'Sample Location Manufacturer Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'smp_loc_cd_type_codes' AS setname, 'Sample Location Type Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'smp_spm_codes' AS setname, 'Sample Specimen Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'sno_fnc_codes' AS setname, 'Snomed Function Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'soc_hse_codes' AS setname, 'Social Housing Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'srg_st_codes' AS setname, 'Surgery Status Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'stain_codes' AS setname, 'Stain Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'sup_unit_codes' AS setname, 'Supply Unit Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'tag_codes' AS setname, 'Tag Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'tl_codes' AS setname, 'Tested Location Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'vaccine_codes' AS setname, 'Vaccine Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'ven_codes' AS setname, 'Ven Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'vit_codes' AS setname, 'Vital Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'void_codes' AS setname, 'Void Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'acquisition_codes' AS setname, 'Acquisition Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'case_cause_codes' AS setname, 'Case Cause Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'disposition_codes' AS setname, 'Disposition Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'funding_source_codes' AS setname, 'Funding Source Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'housing_category_codes' AS setname, 'Housing Category Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'inoculum_codes' AS setname, 'Inoculum Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'instrument_codes' AS setname, 'Instrument Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'vrt_rslt_codes' AS setname, 'Virus Testing Result Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'maj_prc_codes' AS setname, 'Major Procedure Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'min_prc_codes' AS setname, 'Minor Procedure Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'parasite_codes' AS setname, 'Parasite Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'phx_vitals_codes' AS setname, 'Physical Exam Vitals Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'prep_codes' AS setname, 'Preparation Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'project_census_codes' AS setname, 'Project Census Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'rate_codes' AS setname, 'Rate Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'rbc_morphology_codes' AS setname, 'RBC-Morphology Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'result_codes' AS setname, 'Result Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'response_codes' AS setname, 'Response Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'specimen_codes' AS setname, 'Specimen Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'unit_codes' AS setname, 'Unit Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'vivarial_assistant_codes' AS setname, 'Vivarial Assistant Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'abnormal_behavior_codes' AS setname, 'Abnormal Behavior Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'abnormal_codes' AS setname, 'Abnormal Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'exception_codes' AS setname, 'Exception Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'flag_event_codes' AS setname, 'Flag Event Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'hair_plucking_pattern_codes' AS setname, 'Hair Plucking Pattern Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'wound_codes' AS setname, 'Wound Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-02-09' AS TIMESTAMP) AS updated_at
UNION SELECT 'bm_box_codes' AS setname, 'Box Mice Separation Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'spm_cd_class_codes' AS setname, 'Specimen Code Classification Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'bt_codes' AS setname, 'Bacti Type Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-03-28' AS TIMESTAMP) AS updated_at
UNION SELECT 'oct_codes' AS setname, 'Oct Medium for Tissues Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-05-01' AS TIMESTAMP) AS updated_at
UNION SELECT 'move_codes' AS setname, 'Move Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-05-21' AS TIMESTAMP) AS updated_at
UNION SELECT 'census_codes' AS setname, 'Census Codes' AS label, 'value' AS keyField, 'title'AS titleColumn, CAST('2018-07-05' AS TIMESTAMP) AS updated_at
UNION SELECT 'phx_test_types' AS setname, 'Physical Exam Test Types' AS label, 'value' AS keyField, 'title' AS titleColumn, CAST('2018-10-10' AS TIMESTAMP) AS updated_at
UNION SELECT 'dnt_location_codes' AS setname, 'Dental Location Codes' AS label, 'value' AS keyField, 'title' AS titleColumn, CAST('2018-12-18' AS TIMESTAMP) AS updated_at
