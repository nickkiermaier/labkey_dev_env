/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
CASE WHEN (LOCATE(DRG_KEY, DRG_COM_NAME) = 1) THEN DRG_COM_NAME ELSE (DRG_KEY || ': ' || DRG_COM_NAME) END as display_name,
DRG_KEY as meaning,
RT_CD_KEY as route,
DRG_CONC as conc_units,
DRG_DOSE as dosage,
DRG_COMMENT as comment,
CASE WHEN DRG_RETIRED_FL='Y' THEN CAST(UPDATE_DATE AS TIMESTAMP)
  ELSE NULL END as date_disabled,
DRG_COM_NAME as common_name,
DRG_GEN_NAME as generic_name,
RSCH_CD_KEY as rsch_code,
UNIT_CD_KEY as unit_code,
FRQ_CD_KEY as frq_code,
CASE WHEN DRG_BY_WT_FL='Y' THEN TRUE
  WHEN DRG_BY_WT_FL='N' THEN FALSE
  ELSE NULL END AS by_wt_fl,
CASE WHEN DRG_ANESTHESIA_FL='Y' THEN TRUE
  WHEN DRG_ANESTHESIA_FL='N' THEN FALSE
  ELSE NULL END AS anesthesia_fl,
DRG_INTERVAL as interval,
DRG_PREP as prep,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED 
FROM DRG