/*
 * Copyright (c) 2018-2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
PRC_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CAST(PRC_BEGIN_DT AS TIMESTAMP)AS "date",
CASE WHEN PRC_END_DT IS NULL THEN NULL
ELSE CAST(PRC_END_DT AS TIMESTAMP)
END AS enddate,
CAST(CS_KEY AS VARCHAR(4000)) AS cs_key,
CAST(PRC_BILL_PROJ_KEY AS INTEGER) AS project,
CAST(PRC_INTERVAL AS DOUBLE) AS interval,
CAST(VET_PERS_KEY AS INTEGER) AS vet_pers_key,
PRC_AMT AS amount,
UNIT_CD_KEY AS amount_units,
DRG_KEY AS drg_key,
CAST(PRC_DRG_DOSE AS DOUBLE) AS dosage,
DRG_FRQ_CD_KEY AS drg_frq_code,
CASE WHEN PRC_DRG_BY_WT_FL='Y' THEN TRUE
  WHEN PRC_DRG_BY_WT_FL='N' THEN FALSE
  ELSE NULL END AS drg_by_wt_fl,
FRQ_CD_KEY AS frq_code,
RT_CD_KEY AS route,
CASE WHEN PRC_DRG_ANESTHESIA_FL='Y' THEN TRUE
  WHEN PRC_DRG_ANESTHESIA_FL='N' THEN FALSE
  ELSE NULL END AS drg_anesthesia_fl,
DRG_UNIT_CD_KEY AS drg_unit_code,
CAST(SDS_HDR_KEY AS INTEGER) AS sds_hdr_key,
CAST(LYM_HDR_KEY AS INTEGER) AS lym_hdr_key,
CASE WHEN PRC_CANCEL_FL='Y' THEN TRUE
  WHEN PRC_CANCEL_FL='N' THEN FALSE
  ELSE NULL END AS cancel_fl,
PRC_INSTRUCT AS instruct,
PRC_DRG_COM_NAME AS drg_com_name,
PRC_DRG_CONC AS concentration,
PRC_DRG_COMMENT as remark,
PRC_DRG_ADMIN_INSTRUCT AS drg_admin_instruct,
CAST(PHX_HDR_KEY AS VARCHAR(4000)) AS phx_hdr_key,
IMPORT_PERSON AS import_person,
CASE WHEN IMPORT_DATE IS NULL THEN NULL
ELSE CAST(IMPORT_DATE AS TIMESTAMP)
END AS import_date,
CAST(IMPORT_DATE_SEQ_NUM AS INTEGER) AS import_date_seq_num,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PRC
WHERE MAJ_PRC_CD_KEY = 'DRG'
AND RECORD_DELETED = 'false'
