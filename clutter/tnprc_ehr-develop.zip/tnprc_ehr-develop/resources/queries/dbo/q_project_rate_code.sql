/*
 * Copyright (c) 2018-2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
pa.project,
pa.most_recent_date,
pc.PST_CD_DESC AS project_status,
pa2.PROJ_ACCT_PERDIEM_ACCT_NUM AS account,
pa2.RATE_KEY AS rate_key,
r.RATE_CD_KEY AS rate_code,
rc.RATE_CD_DESC AS rate_description
FROM (
  SELECT
  project,
  MAX(date) AS most_recent_date
  FROM (
    SELECT
    PROJ_KEY AS project,
    CAST(PROJ_ACCT_EFFECT_DT AS TIMESTAMP) AS date
    FROM PROJ_ACCT
  ) x
  GROUP BY project
) pa
LEFT JOIN PROJ p
  ON p.PROJ_KEY = pa.project
LEFT JOIN PST_CD pc
  ON pc.PST_CD_KEY = p.PST_CD_KEY
LEFT JOIN PROJ_ACCT pa2
  ON pa.project = pa2.PROJ_KEY
  AND pa.most_recent_date = CAST(PROJ_ACCT_EFFECT_DT AS TIMESTAMP)
LEFT JOIN RATE r
  ON r.RATE_KEY = pa2.RATE_KEY
LEFT JOIN RATE_CD rc
  ON rc.RATE_CD_KEY = r.RATE_CD_KEY