/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT *
FROM 
(
SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_WT' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'WT' AS test_type,
    CAST(PHX_WT AS DOUBLE) AS test_result, --double
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_WT IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_WT_DIFF' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'WT Diff' AS test_type,
    CAST(PHX_WT_DIFF AS DOUBLE) AS test_result, --double
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_WT_DIFF IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_RT_POPLITEAL' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'RT Popliteal' AS test_type,
    CAST(PHX_RT_POPLITEAL AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_RT_POPLITEAL IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_LT_POPLITEAL' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'LT Popliteal' AS test_type,
    CAST(PHX_LT_POPLITEAL AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_LT_POPLITEAL IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_RT_INGUINAL' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'RT Inguinal' AS test_type,
    CAST(PHX_RT_INGUINAL AS DOUBLE) AS test_result, -- integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_RT_INGUINAL IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_LT_INGUINAL' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'LT Inguinal' AS test_type,
    CAST(PHX_LT_INGUINAL AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_LT_INGUINAL IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_RT_AXILLARY' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'RT Axillary' AS test_type,
    CAST(PHX_RT_AXILLARY AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_RT_AXILLARY IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_LT_AXILLARY' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'LT Axillary' AS test_type,
    CAST(PHX_LT_INGUINAL AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_LT_AXILLARY IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_SPLEEN' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'Spleen' AS test_type,
    CAST(PHX_SPLEEN AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_SPLEEN IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_SUBMANDIBULAR' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'Submandibular' AS test_type,
    CAST(PHX_SUBMANDIBULAR AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_SUBMANDIBULAR IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_TEMP' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'Temp' AS test_type,
    CAST(PHX_TEMP AS DOUBLE) AS test_result, --double
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_TEMP IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_STOOL' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'Stool' AS test_type,
    CAST(PHX_STOOL AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_STOOL IS NOT NULL

UNION SELECT
    CAST(MVON_KEY AS VARCHAR(4000)) || '_BODY_COND' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    RSCH_CD_KEY AS rsch_code,
    'Body Cond' AS test_type,
    CAST(PHX_BODY_COND AS DOUBLE) AS test_result,--double
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM PHX WHERE PHX_BODY_COND IS NOT NULL

UNION SELECT
    rsv.MVON_KEY || '_RSV_PULSE' AS objectid,
    phx.PHX_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    NULL AS rsch_code,
    'RSV Pulse' AS test_type,
    CAST(PHX_RSV_PULSE AS DOUBLE) AS test_result,--integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    rsv.UPDATE_DATETIME AS updated_at,
    rsv.RECORD_DELETED
FROM PHX_RSV AS rsv
JOIN PHX  AS phx ON rsv.PHX_KEY = phx.PHX_KEY
WHERE PHX_RSV_PULSE IS NOT NULL

UNION SELECT
    rsv.MVON_KEY || '_RSV_HEART_RT' AS objectid,
    phx.PHX_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    NULL AS rsch_code,
    'RSV Heart Rate' AS test_type,
    CAST(PHX_RSV_HEART_RT AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    rsv.UPDATE_DATETIME AS updated_at,
    rsv.RECORD_DELETED
FROM PHX_RSV AS rsv
JOIN PHX  AS phx ON rsv.PHX_KEY = phx.PHX_KEY
WHERE PHX_RSV_HEART_RT IS NOT NULL

UNION SELECT
    rsv.MVON_KEY || '_RSV_RESP_RT' AS objectid,
    phx.PHX_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN PHX_TIME IS NULL
        THEN CAST(PHX_DT AS TIMESTAMP)
     ELSE
        CAST((PHX_DT || ' ' || PHX_TIME) AS TIMESTAMP)
    END AS "date",
    NULL AS remark,
    NULL AS rsch_code,
    'RSV Resp Rate' AS test_type,
    CAST(PHX_RSV_RESP_RT AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    rsv.UPDATE_DATETIME AS updated_at,
    rsv.RECORD_DELETED
FROM PHX_RSV AS rsv
JOIN PHX  AS phx ON rsv.PHX_KEY = phx.PHX_KEY
WHERE PHX_RSV_RESP_RT IS NOT NULL
) AS phx
WHERE RECORD_DELETED = FALSE