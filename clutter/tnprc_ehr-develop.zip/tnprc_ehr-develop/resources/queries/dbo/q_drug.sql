/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
DRG_ADM_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN DRG_ADM_TIME IS NULL
  THEN CAST(DRG_ADM_DT AS TIMESTAMP)
  ELSE CAST((DRG_ADM_DT || ' ' || DRG_ADM_TIME) AS TIMESTAMP)
  END AS "date",
CAST(DRG_ADM_BILL_PROJ_KEY AS INTEGER) AS project,
DRG_KEY AS "code",
CAST(DRG_ADM_DRG_DOSE_ADMIN AS DOUBLE) AS "dosage",
CAST(DRG_ADM_DRG_DOSE AS DOUBLE) AS "dosage_modified",
DRG_UNIT_CD_KEY AS "dosage_units",
DRG_ADM_DRG_CONC AS "concentration",
RT_CD_KEY AS "route",
DRG_ADM_DRG_FRQ_CD_KEY AS "drg_frq_code",
CASE WHEN DRG_ADM_FL='Y' THEN 'TRUE'
  WHEN DRG_ADM_FL='N' THEN 'FALSE'
  ELSE NULL END AS "adm_fl",
CAST(DRG_ADM_FRQ_CD_CNTR AS INTEGER) AS "frq_cd_cntr",
CAST(EXC_CD_KEY AS INTEGER) AS "exc_code",
CAST(PRC_KEY AS VARCHAR(4000)) AS "parentid",
CAST(TECH_PERS_KEY AS INTEGER) AS "tech_pers_key",
CAST(VET_PERS_KEY AS INTEGER) AS "vet_pers_key",
CAST(CREATE_DATE || ' ' || CREATE_TIME AS TIMESTAMP) AS created,
CAST(CREATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM DRG_ADM
WHERE AM_KEY IS NOT NULL
AND RECORD_DELETED = FALSE