/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
SELECT
    SMP_LOC_CD_KEY AS sort_order,
    INVEST_PERS_KEY AS inv_pers_code,
    SMP_LOC_CD_ALARM_TEMP AS alarm_temp,
    SMP_LOC_CD_BLDG_CD_KEY AS bldg_code,
    SMP_LOC_CD_DA_FL AS da_fl,
    SMP_LOC_CD_KEY as "value",
    SMP_LOC_CD_MFG_CD_KEY as mfg_code,
    SMP_LOC_CD_OP_TEMP as op_temp,
    SMP_LOC_CD_TYPE_CD_ABB_DESC as type_code_desc,
    SMP_LOC_CD_TYPE_CD_KEY as type_code,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SMP_LOC_CD