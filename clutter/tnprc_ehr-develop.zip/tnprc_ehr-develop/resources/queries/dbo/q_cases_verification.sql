/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT *
FROM (
SELECT 
CS_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN CLN_EXEMPT_FL='Y' THEN 'true'
  WHEN CLN_EXEMPT_FL='N' THEN 'false'
  ELSE NULL END AS "cln_exempt_fl",
CAST(CS_CLOSE_DT AS TIMESTAMP) AS "enddate",
CS_HIS AS "problem",
CS_OPEN_DT AS "date",
CAST(CS_WORK_PROJ_KEY AS INTEGER) AS project,
CS_WT AS "wt",
CAST(INVEST_PERS_KEY AS INTEGER) AS "invest_pers_key",
RSCH_CD_KEY AS "category",
SOC_HSE_CD_KEY AS "soc_hse_code",
CAST(TECH_PERS_KEY AS INTEGER) AS "tech_pers_key",
CAST(VET_PERS_KEY AS INTEGER) AS "vet_pers_key",
WT_KEY AS "wt_key" ,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CS
) as cases 
WHERE RECORD_DELETED = 'false'