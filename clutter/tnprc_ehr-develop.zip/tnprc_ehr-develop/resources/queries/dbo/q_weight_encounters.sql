/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

-- CS (case) table
SELECT 'CS_' || CS_KEY AS objectid,
CS_KEY AS encounterId,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CAST(CS_OPEN_DT AS TIMESTAMP) AS "date",
CAST(CS_CLOSE_DT AS DATE) AS enddate,
CS_KEY AS caseno,
'Case' AS "type",
'Case Weight' AS remark,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM CS
WHERE CS_WT IS NOT NULL

-- LYM (lyme exam) table
UNION SELECT 'LYM_' || LYM_KEY AS objectid,
LYM_KEY AS encounterId,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CAST(LYM_DT || ' ' || LYM_TIME AS TIMESTAMP) AS "date",
NULL AS enddate,
NULL AS caseno,
'Lyme Exam' AS "type",
'Lyme Exam Weight' AS remark,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM LYM
WHERE LYM_WT IS NOT NULL

-- NCR (necropsy) table
UNION SELECT 'NCR_' || NCR_KEY AS objectid,
NCR_KEY AS encounterId,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CAST(NCR_DT || ' ' || NCR_TIME AS TIMESTAMP) AS "date",
NULL AS enddate,
NULL AS caseno,
'Necropsy' AS "type",
'Necropsy Weight' AS remark,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM NCR
WHERE NCR_WT_KG IS NOT NULL

-- PHX (physical exam) table
UNION SELECT 'PHX_' || PHX_KEY AS objectid,
PHX_KEY AS encounterId,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CAST(PHX_DT || ' ' || PHX_TIME AS TIMESTAMP) AS "date",
NULL AS enddate,
NULL AS caseno,
'Physical Exam' AS "type",
'Physical Exam Weight' AS remark,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PHX
WHERE PHX_WT IS NOT NULL

-- SDS (saids exam) table
UNION SELECT 'SDS_' || SDS_KEY AS objectid,
SDS_KEY AS encounterId,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CAST(SDS_DT || ' ' || SDS_TIME AS TIMESTAMP) AS "date",
NULL AS enddate,
NULL AS caseno,
'Saids Exam' AS "type",
'Saids Exam Weight' AS remark,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM SDS
WHERE SDS_WT IS NOT NULL