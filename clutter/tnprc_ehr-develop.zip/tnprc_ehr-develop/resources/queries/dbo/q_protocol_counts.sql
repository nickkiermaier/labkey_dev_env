/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
CAST(parent.MVON_KEY AS INTEGER) AS project,
VALUE_INDEX AS value_index,
SP_CD_KEY AS species,
CTRY_CD_KEY AS geographic_origin,
PROJ_APPROVED_NUM AS allowed,
PROJ_APPR_PIGBACK_ASS_FL AS approved_piggyback_fl,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at
FROM PROJ__PROJ_APPROVED_NUM_A AS child
  JOIN PROJ AS parent ON parent.MVON_KEY = child.MVON_KEY
WHERE SP_CD_KEY IS NOT NULL -- TODO enter issue for this 1 record
AND RECORD_DELETED = FALSE

UNION SELECT
CAST(parent.PROJ_KEY AS INTEGER) AS project,
child.VALUE_INDEX AS value_index,
child.SP_CD_KEY AS species,
child.CTRY_CD_KEY AS geographic_origin,
child.PROJ_PND_APPROVED_NUM AS allowed,
child.PROJ_PND_APPR_PIGBACK_ASS_FL AS approved_piggyback_fl,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at
FROM PROJ_PND__APPROVED_NUM_A AS child
JOIN PROJ_PND AS parent ON parent.MVON_KEY = child.MVON_KEY
WHERE RECORD_DELETED = FALSE