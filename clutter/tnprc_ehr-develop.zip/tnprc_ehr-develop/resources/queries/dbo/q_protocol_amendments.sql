/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
SELECT
  CAST(PROJ_IACUC_DTL_KEY AS INTEGER) AS "dtl_key",
  PROJ_KEY AS "project",
  PROJ_IACUC_DTL_AMEND_DT AS "date",
  PROJ_IACUC_DTL_APPROVAL_DT AS "approved",
  PROJ_IACUC_DTL_SUBMIT_DT AS "submitted",
  PROJ_IACUC_DTL_COM AS "comment",
  PROJ_IACUC_DTL_AMEND_NUM AS "amend_num",
  PROJ_IACUC_DTL_SHORT_TITLE AS "short_title",
  CAST(CAT_USE_CD_KEY AS INTEGER) AS "cat_use_code",
  CAST(INVEST_PERS_KEY AS INTEGER) AS "invest_pers_key",
  CAST(VET_PERS_KEY AS INTEGER) AS "vet_pers_key",
  CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
  CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
  CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
  CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
  UPDATE_DATETIME AS updated_at
FROM PROJ_IACUC_DTL
WHERE RECORD_DELETED = FALSE