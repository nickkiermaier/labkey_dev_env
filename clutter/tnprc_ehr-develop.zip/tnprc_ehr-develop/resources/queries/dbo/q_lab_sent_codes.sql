/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
SELECT
	LAB_SENT_CD_KEY AS sort_order,
	CTRY_CD_KEY	AS ctry_code,
    LAB_SENT_CD_ABB_DESC AS title,
	CASE LAB_SENT_CD_ACTIVE_FL
    WHEN 'Y' THEN NULL
    WHEN 'N' THEN '1/1/1970'
    END AS date_disabled,
	LAB_SENT_CD_CITY AS city,
	LAB_SENT_CD_CO_NAME AS co_name,
	LAB_SENT_CD_CONTACT_DT AS contact_dt,
	LAB_SENT_CD_CRD_ACCT_FL AS crd_acct_fl,
	LAB_SENT_CD_DESC AS description,
	LAB_SENT_CD_DOCR_FL AS docr_fl,
	LAB_SENT_CD_EMAIL AS email,
	LAB_SENT_CD_FAX_NUM AS fax_num,
	LAB_SENT_CD_FED_EX_NUM AS fed_ex_num,
	LAB_SENT_CD_IN_OUT_FL AS in_out_fl,
	LAB_SENT_CD_INTERNAL_BILL AS internal_bill,
	LAB_SENT_CD_INTL_PHONE AS intl_phone,
	LAB_SENT_CD_KEY AS "value",
	LAB_SENT_CD_NAME_FN AS name_fn,
	LAB_SENT_CD_NAME_LN AS name_ln,
	LAB_SENT_CD_NAME_PRE AS name_pre,
	LAB_SENT_CD_NAME_SUFFIX AS name_suffix,
	LAB_SENT_CD_PHONE_NUM AS phone_num,
	LAB_SENT_CD_STATE AS state,
	LAB_SENT_CD_STREET AS street,
	LAB_SENT_CD_STREET2 AS street2,
	LAB_SENT_CD_ZIP AS zip,
	CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
	CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
	CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
	CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
	UPDATE_DATETIME AS updated_at,
	RECORD_DELETED
FROM LAB_SENT_CD