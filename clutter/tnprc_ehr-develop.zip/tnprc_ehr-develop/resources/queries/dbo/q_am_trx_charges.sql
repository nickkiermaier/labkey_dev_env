/*
 * Copyright (c) 2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
NULL AS cost_type,
NULL AS unit_cost,
NULL AS debited_account,
NULL AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
WHERE no_charge_reason_code IS NOT NULL

UNION SELECT
objectid || '-VS_AM_FEE_CD_CHG' as objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
'VS Fee' AS cost_type,
dtl.AM_TRX_DTL_VS_AM_FEE_CD_CHG AS unit_cost,
dtl.AM_TRX_DTL_AM_PURCH_ACCT_NUM AS debited_account,
dtl.AM_TRX_DTL_AM_CREDIT_ACCT_NUM AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
INNER JOIN AM_TRX_DTL AS dtl
    ON q_am_trx.parentid = dtl.AM_TRX_DTL_KEY
WHERE no_charge_reason_code IS NULL
  AND dtl.AM_TRX_DTL_VS_AM_FEE_CD_CHG IS NOT NULL AND CAST(dtl.AM_TRX_DTL_VS_AM_FEE_CD_CHG AS DOUBLE) <> 0.0

UNION SELECT
objectid || '-AM_FEE_CD_CHG' as objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
'Fee' AS cost_type,
dtl.AM_TRX_DTL_AM_FEE_CD_CHG AS unit_cost,
dtl.AM_TRX_DTL_AM_PURCH_ACCT_NUM AS debited_account,
dtl.AM_TRX_DTL_AM_CREDIT_ACCT_NUM AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
INNER JOIN AM_TRX_DTL AS dtl
    ON q_am_trx.parentid = dtl.AM_TRX_DTL_KEY
WHERE no_charge_reason_code IS NULL
  AND dtl.AM_TRX_DTL_AM_FEE_CD_CHG IS NOT NULL AND CAST(dtl.AM_TRX_DTL_AM_FEE_CD_CHG AS DOUBLE) <> 0.0

UNION SELECT
objectid || '-AM_FEE_CD_TB_CHG' as objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
'Timed Bred' AS cost_type,
dtl.AM_FEE_CD_TB_CHG AS unit_cost,
dtl.AM_TRX_DTL_AM_PURCH_ACCT_NUM AS debited_account,
dtl.AM_TRX_DTL_AM_CREDIT_ACCT_NUM AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
INNER JOIN AM_TRX_DTL AS dtl
    ON q_am_trx.parentid = dtl.AM_TRX_DTL_KEY
WHERE no_charge_reason_code IS NULL
  AND dtl.AM_FEE_CD_TB_CHG IS NOT NULL AND CAST(dtl.AM_FEE_CD_TB_CHG AS DOUBLE) <> 0.0

UNION SELECT
objectid || '-AM_FEE_CD_VT_CHG' as objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
'Viral Tested' AS cost_type,
dtl.AM_FEE_CD_VT_CHG AS unit_cost,
dtl.AM_TRX_DTL_AM_PURCH_ACCT_NUM AS debited_account,
dtl.AM_TRX_DTL_AM_CREDIT_ACCT_NUM AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
INNER JOIN AM_TRX_DTL AS dtl
    ON q_am_trx.parentid = dtl.AM_TRX_DTL_KEY
WHERE no_charge_reason_code IS NULL
  AND dtl.AM_FEE_CD_VT_CHG IS NOT NULL AND CAST(dtl.AM_FEE_CD_VT_CHG AS DOUBLE) <> 0.0

UNION SELECT
objectid || '-AM_FEE_CD_GD_CHG' as objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
'Genetically Defined' AS cost_type,
dtl.AM_FEE_CD_GD_CHG AS unit_cost,
dtl.AM_TRX_DTL_AM_PURCH_ACCT_NUM AS debited_account,
dtl.AM_TRX_DTL_AM_CREDIT_ACCT_NUM AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
INNER JOIN AM_TRX_DTL AS dtl
    ON q_am_trx.parentid = dtl.AM_TRX_DTL_KEY
WHERE no_charge_reason_code IS NULL
  AND dtl.AM_FEE_CD_GD_CHG IS NOT NULL AND CAST(dtl.AM_FEE_CD_GD_CHG AS DOUBLE) <> 0.0

UNION SELECT
objectid || '-AM_FEE_CD_RTN_VT_CHG' as objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
'Routine Viral Testing' AS cost_type,
dtl.AM_FEE_CD_RTN_VT_CHG AS unit_cost,
dtl.AM_TRX_DTL_AM_PURCH_ACCT_NUM AS debited_account,
dtl.AM_TRX_DTL_AM_CREDIT_ACCT_NUM AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
INNER JOIN AM_TRX_DTL AS dtl
    ON q_am_trx.parentid = dtl.AM_TRX_DTL_KEY
WHERE no_charge_reason_code IS NULL
  AND dtl.AM_FEE_CD_RTN_VT_CHG IS NOT NULL AND CAST(dtl.AM_FEE_CD_RTN_VT_CHG AS DOUBLE) <> 0.0

UNION SELECT
objectid || '-AM_FEE_CD_QUAR_CHG' as objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
'Quarantine' AS cost_type,
dtl.AM_FEE_CD_QUAR_CHG AS unit_cost,
dtl.AM_TRX_DTL_AM_PURCH_ACCT_NUM AS debited_account,
dtl.AM_TRX_DTL_AM_CREDIT_ACCT_NUM AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
INNER JOIN AM_TRX_DTL AS dtl
    ON q_am_trx.parentid = dtl.AM_TRX_DTL_KEY
WHERE no_charge_reason_code IS NULL
  AND dtl.AM_FEE_CD_QUAR_CHG IS NOT NULL AND CAST(dtl.AM_FEE_CD_QUAR_CHG AS DOUBLE) <> 0.0

UNION SELECT
objectid || '-AM_FEE_CD_GD_WI_SNGL_CHG' as objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
'Wisconsin Single Allele' AS cost_type,
dtl.AM_FEE_CD_GD_WI_SNGL_CHG AS unit_cost,
dtl.AM_TRX_DTL_AM_PURCH_ACCT_NUM AS debited_account,
dtl.AM_TRX_DTL_AM_CREDIT_ACCT_NUM AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
INNER JOIN AM_TRX_DTL AS dtl
    ON q_am_trx.parentid = dtl.AM_TRX_DTL_KEY
WHERE no_charge_reason_code IS NULL
  AND dtl.AM_FEE_CD_GD_WI_SNGL_CHG IS NOT NULL AND CAST(dtl.AM_FEE_CD_GD_WI_SNGL_CHG AS DOUBLE) <> 0.0

UNION SELECT
objectid || '-AM_FEE_CD_GD_WI_TRAY_CHG' as objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
'Wisconsin Tray of Alleles' AS cost_type,
dtl.AM_FEE_CD_GD_WI_TRAY_CHG AS unit_cost,
dtl.AM_TRX_DTL_AM_PURCH_ACCT_NUM AS debited_account,
dtl.AM_TRX_DTL_AM_CREDIT_ACCT_NUM AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
INNER JOIN AM_TRX_DTL AS dtl
    ON q_am_trx.parentid = dtl.AM_TRX_DTL_KEY
WHERE no_charge_reason_code IS NULL
  AND dtl.AM_FEE_CD_GD_WI_TRAY_CHG IS NOT NULL AND CAST(dtl.AM_FEE_CD_GD_WI_TRAY_CHG AS DOUBLE) <> 0.0

UNION SELECT
objectid || '-AM_TRX_DTL_TPC_IDC' as objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
'TPC Indirect' AS cost_type,
dtl.AM_TRX_DTL_TPC_IDC AS unit_cost,
dtl.AM_TRX_DTL_AM_PURCH_ACCT_NUM AS debited_account,
'111608' AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
INNER JOIN AM_TRX_DTL AS dtl
    ON q_am_trx.parentid = dtl.AM_TRX_DTL_KEY
WHERE no_charge_reason_code IS NULL
  AND dtl.AM_TRX_DTL_TPC_IDC IS NOT NULL AND CAST(dtl.AM_TRX_DTL_TPC_IDC AS DOUBLE) <> 0.0

UNION SELECT
objectid || '-AM_TRX_DTL_THC_IDC' as objectid,
parentid,
trx_num,
date,
project,
project_from,
animal_count,
id,
effective_dt,
prepay_fl,
no_charge_reason_code,
include_idc_fl,
'THC Indirect' AS cost_type,
dtl.AM_TRX_DTL_THC_IDC AS unit_cost,
dtl.AM_TRX_DTL_AM_PURCH_ACCT_NUM AS debited_account,
'111606' AS credited_account,
comment,
bo_approval_fl,
bo_approval_dt,
bo_comment,
created,
createdBy,
modified,
modifiedBy,
updated_at
FROM q_am_trx
INNER JOIN AM_TRX_DTL AS dtl
    ON q_am_trx.parentid = dtl.AM_TRX_DTL_KEY
WHERE no_charge_reason_code IS NULL
  AND dtl.AM_TRX_DTL_THC_IDC IS NOT NULL AND CAST(dtl.AM_TRX_DTL_THC_IDC AS DOUBLE) <> 0.0