/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
LOC_KEY as objectid,
AM_KEY as id,
LOC_CAT_CD_KEY as housingType,
LOC_CD_KEY as room,
LOC_CG as cage,
LOC_COM as remark,
LOC_DT as "date",
LOC_RELEASE_DT as enddate,
CAST(LOC_RELEASE_DT_NULL AS INTEGER) as release_date_null,
MV_CD_KEY as reason,
SOC_HSE_CD_KEY as social_housing_code,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM LOC 
WHERE RECORD_DELETED = FALSE

UNION SELECT
'BOX-' || BLOC_KEY as objectid,
'BOX-' || BM_KEY as id,
LOC_CAT_CD_KEY as housingType,
LOC_CD_KEY as room,
BLOC_CG as cage,
BLOC_COM as remark,
BLOC_DT as "date",
BLOC_RELEASE_DT as enddate,
NULL as release_date_null,
NULL as reason,
NULL as social_housing_code,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM BLOC 
WHERE RECORD_DELETED = FALSE
