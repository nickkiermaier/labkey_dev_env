/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
  MTF_KEY as objectid,
  CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN MTF_TIME IS NULL THEN CAST(mtf_begin.MTF_BEGIN_DT AS TIMESTAMP)
    ELSE CAST((mtf_begin.MTF_BEGIN_DT || ' ' || MTF_TIME) AS TIMESTAMP)
    END AS "date",
  CAST(mtf_end.MTF_END_DT AS TIMESTAMP) AS enddate,
  CASE WHEN ISNUMERIC(MTF_BILL_PROJ_KEY) = 1
    THEN CAST(MTF_BILL_PROJ_KEY AS INTEGER)
    ELSE NULL END AS project,
  CAST(PRC_KEY AS VARCHAR(4000)) AS "parentid",
  CASE WHEN ISNUMERIC(VET_PERS_KEY) = 1
    THEN CAST(VET_PERS_KEY AS DOUBLE)
    ELSE NULL END AS vet_pers_key,
  CAST(BEGIN_MTF_RSN_CD_KEY AS INTEGER) AS begin_rsn_code,
  CAST(END_MTF_RSN_CD_KEY AS INTEGER) AS end_rsn_code,
  MTF_COM as remark,
  CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
  CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
  CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
  CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
  UPDATE_DATETIME AS updated_at,
  RECORD_DELETED
FROM MTF
  LEFT JOIN MTF__MTF_BEGIN_DT_A mtf_begin ON MTF.MTF_KEY = mtf_begin.MVON_KEY
  LEFT JOIN MTF__MTF_END_DT_A mtf_end ON MTF.MTF_KEY = mtf_end.MVON_KEY
WHERE RECORD_DELETED = FALSE