/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
SELECT
    MVON_KEY AS lab_sent_code,
    SNO_FNC_CD_KEY AS sno_fnc_code,
    VALUE_INDEX AS value_index,
    parent.created AS created,
    parent.createdBy AS createdBy,
    parent.modified AS modified,
    parent.modifiedBy AS modifiedBy,
    parent.updated_at AS updated_at,
    parent.RECORD_DELETED
FROM LAB_SENT_CD__CD_KEY_A AS child
    JOIN q_lab_sent_codes AS parent on parent.value = child.MVON_KEY