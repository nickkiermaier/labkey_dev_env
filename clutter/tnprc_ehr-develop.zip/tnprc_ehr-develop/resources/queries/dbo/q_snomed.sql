/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 'D-' || DS_CD_KEY AS code,
DS_CD_DESC AS meaning,
NULL AS description,
'Disease' AS primaryCategory,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM DS_CD

UNION SELECT 'E-' || ET_CD_KEY AS code,
ET_CD_DESC AS meaning,
ET_CD_ABB_DESC AS description,
'Etiology' AS primaryCategory,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ET_CD

UNION SELECT 'F-' || FNC_CD_KEY AS code,
FNC_CD_DESC AS meaning,
NULL AS description,
'Function' AS primaryCategory,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM FNC_CD

UNION SELECT 'M-' || MRP_CD_KEY AS code,
MRP_CD_DESC AS meaning,
MRP_CD_ABB_DESC AS description,
'Morphology' AS primaryCategory,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM MRP_CD

UNION SELECT 'P-' || PROC_CD_KEY AS code,
PROC_CD_DESC AS meaning,
NULL AS description,
'Procedure' AS primaryCategory,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PROC_CD

UNION SELECT 'T-' || TOP_CD_KEY AS code,
TOP_CD_DESC AS meaning,
TOP_CD_ABB_DESC AS description,
'Topography' AS primaryCategory,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM TOP_CD