/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 'T-' + child.MVON_KEY AS snomed,
child.SNO_FNC_CD_KEY AS sno_fnc_code,
child.VALUE_INDEX AS value_index,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM TOP_CD_O_FNC_CD_KEY_A AS child
   JOIN TOP_CD AS parent ON child.MVON_KEY = parent.MVON_KEY

UNION SELECT 'D-' + child.MVON_KEY AS snomed,
child.SNO_FNC_CD_KEY AS sno_fnc_code,
child.VALUE_INDEX AS value_index,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM DS_CD_O_FNC_CD_KEY_A AS child
  JOIN DS_CD AS parent ON child.MVON_KEY = parent.MVON_KEY

UNION SELECT 'E-' + child.MVON_KEY AS snomed,
child.SNO_FNC_CD_KEY AS sno_fnc_code,
child.VALUE_INDEX AS value_index,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM ET_CD_O_FNC_CD_KEY_A AS child
  JOIN ET_CD AS parent ON child.MVON_KEY = parent.MVON_KEY

UNION SELECT 'F-' + child.MVON_KEY AS snomed,
child.SNO_FNC_CD_KEY AS sno_fnc_code,
child.VALUE_INDEX AS value_index,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM FNC_CD_O_FNC_CD_KEY_A AS child
  JOIN FNC_CD AS parent ON child.MVON_KEY = parent.MVON_KEY

UNION SELECT 'M-' + child.MVON_KEY AS snomed,
child.SNO_FNC_CD_KEY AS sno_fnc_code,
child.VALUE_INDEX AS value_index,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM MRP_CD_O_FNC_CD_KEY_A AS child
  JOIN MRP_CD AS parent ON child.MVON_KEY = parent.MVON_KEY

UNION SELECT 'P-' + child.MVON_KEY AS snomed,
child.SNO_FNC_CD_KEY AS sno_fnc_code,
child.VALUE_INDEX AS value_index,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PROC_CD_O_FNC_CD_KEY_A AS child
  JOIN PROC_CD AS parent ON child.MVON_KEY = parent.MVON_KEY