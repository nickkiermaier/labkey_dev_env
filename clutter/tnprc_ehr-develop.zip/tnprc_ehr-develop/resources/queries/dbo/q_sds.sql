/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
    MVON_KEY  || '_WT' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'WT' AS test_type,
    CAST(SDS_WT AS DOUBLE) AS test_result,
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_WT IS NOT NULL

UNION SELECT
    MVON_KEY || '_WT_DIFF' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'WT Diff' AS test_type,
    CAST(SDS_WT_DIFF AS DOUBLE) AS test_result,
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_WT_DIFF IS NOT NULL

UNION SELECT
    MVON_KEY || '_RT_POPLITEAL' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'RT Popliteal' AS test_type,
    CAST(SDS_RT_POPLITEAL AS DOUBLE) AS test_result,--INTEGER
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_RT_POPLITEAL IS NOT NULL

UNION SELECT
    MVON_KEY || '_LT_POPLITEAL' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'LT Popliteal' AS test_type,
    CAST(SDS_LT_POPLITEAL AS DOUBLE) AS test_result, --integer
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_LT_POPLITEAL IS NOT NULL

UNION SELECT
    MVON_KEY || '_RT_INGUINAL' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'RT Inguinal' AS test_type,
    CAST(SDS_RT_INGUINAL AS DOUBLE) AS test_result,--integer
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_RT_INGUINAL IS NOT NULL

UNION SELECT
    MVON_KEY || '_LT_INGUINAL' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'LT Inguinal' AS test_type,
    CAST(SDS_LT_INGUINAL AS DOUBLE) AS test_result,--integer
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_LT_INGUINAL IS NOT NULL

UNION SELECT
    MVON_KEY || '_RT_AXILLARY' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'RT Axillary' AS test_type,
    CAST(SDS_RT_AXILLARY AS DOUBLE) AS test_result,--integer
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_RT_AXILLARY IS NOT NULL

UNION SELECT
    MVON_KEY || '_LT_AXILLARY' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'LT Axillary' AS test_type,
    CAST(SDS_LT_AXILLARY AS DOUBLE) AS test_result,--integer
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_LT_AXILLARY IS NOT NULL

UNION SELECT
    MVON_KEY || '_SPLEEN' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'Spleen' AS test_type,
    CAST(SDS_SPLEEN AS DOUBLE) AS test_result,--integer
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_SPLEEN IS NOT NULL

UNION SELECT
    MVON_KEY || '_SUBMANDIBULAR' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'Submandibular' AS test_type,
    CAST(SDS_SUBMANDIBULAR AS DOUBLE) AS test_result,--integer
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_SUBMANDIBULAR IS NOT NULL

UNION SELECT
    MVON_KEY || '_TEMP' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'Temp' AS test_type,
    CAST(SDS_TEMP AS DOUBLE) AS test_result,
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_TEMP IS NOT NULL

UNION SELECT
    MVON_KEY || '_STOOL' AS objectid,
    MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'Stool' AS test_type,
    CAST(SDS_STOOL AS DOUBLE) AS test_result,--integer
    NULL AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS WHERE SDS_STOOL IS NOT NULL

UNION SELECT
    vit.MVON_KEY || '_VIT_' || CAST(VALUE_INDEX AS VARCHAR(4000)) AS objectid,
    sds.MVON_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CASE WHEN SDS_TIME IS NULL
        THEN CAST(SDS_DT AS TIMESTAMP)
     ELSE
        CAST((SDS_DT || ' ' || SDS_TIME) AS TIMESTAMP)
    END AS "date",
    SDS_KEY AS sds_key,
    'VIT code' AS test_type,
    CAST(VIT_CD_KEY AS DOUBLE) AS test_result,
    CAST(SDS_VIT_CD_COMMENT AS VARCHAR(4000)) AS test_comment,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM SDS__VIT_CD_KEY_A AS vit JOIN SDS AS sds ON vit.MVON_KEY = sds.MVON_KEY
