/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
IT_PROGS_KEY AS value,
DPT_CD_KEY AS dpt_code,
CASE WHEN GEN_CHG_DTL_FILE_FL='Y' THEN TRUE
  WHEN GEN_CHG_DTL_FILE_FL='N' THEN FALSE
  ELSE NULL END AS gen_chg_dtl_file_fl,
GEN_CHG_DTL_RATE_ZD AS gen_chg_dtl_rate_zd,
IT_PROGS_DEPT_USE AS dept_use,
IT_PROGS_DESC AS description,
IT_PROGS_EXP_TYPE_NA_ET AS exp_type_na_et,
IT_PROGS_FILE_NAME AS file_name,
IT_PROGS_FILE_NAME_2T AS file_name_2t,
IT_PROGS_REV_TYPE_NA_ET AS rev_type_na_et,
PERS_KEY AS pers_key,
UPDATE_DATETIME AS updated_at
FROM IT_PROGS
WHERE RECORD_DELETED = FALSE