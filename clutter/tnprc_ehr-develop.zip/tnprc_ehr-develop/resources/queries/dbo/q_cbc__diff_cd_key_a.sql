/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
CAST(parent.AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN parent.CBC_TIME IS NULL 
  THEN CAST(parent.CBC_DT AS TIMESTAMP)
  ELSE CAST((parent.CBC_DT || ' ' || CBC_TIME) AS TIMESTAMP)
  END AS "date",
CAST('CBC__DIFF_CD_KEY_A-' || child.MVON_KEY AS VARCHAR(4000)) || '-' || CAST(child.VALUE_INDEX AS VARCHAR(4000)) AS objectid,
parent.MVON_KEY AS parentid,
CBC_DIFF_CD_VALUE AS "cbc_diff_cd_value",
CAST(DIFF_CD_KEY AS INTEGER) AS "diff_code",
VALUE_INDEX AS "value_index",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED 
FROM CBC__DIFF_CD_KEY_A AS child 
JOIN CBC AS parent ON parent.MVON_KEY = child.MVON_KEY 
WHERE RECORD_DELETED = 'false' 