/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
URN_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN URN_TIME IS NULL
        THEN CAST(URN_DT AS TIMESTAMP)
     ELSE
        CAST((URN_DT || ' ' || URN_TIME) AS TIMESTAMP)
END AS "date",
CAST(PRC_KEY AS VARCHAR(4000)) AS "parentid",
CAST(URN_BILL_PROJ_KEY AS INTEGER) AS project,
CAST(LAB_SENT_CD_KEY AS INTEGER) AS "lab_sent_code",
CAST(VET_PERS_KEY AS INTEGER) AS "vet_pers_key",
CASE WHEN URN_BILL_DT IS NOT NULL THEN CAST(URN_BILL_DT AS TIMESTAMP) ELSE NULL END AS bill_date,
CASE WHEN URN_CHG_FL='Y' THEN TRUE
  WHEN URN_CHG_FL='N' THEN FALSE
  ELSE NULL END AS chg_fl,
SPM_CD_KEY AS spm_code,
CAST(CLR_CD_KEY AS INTEGER) AS clr_code,
CAST(CHR_CD_KEY AS INTEGER) AS chr_code,
URN_WBC AS wbc,
URN_RBC AS rbc,
URN_COM as remark,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM URN 
-- CSF data are the records with a 'CSF' SPM_CD_KEY
WHERE SPM_CD_KEY = 'CSF'  
AND RECORD_DELETED = 'false' 
