/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
'ABN__ABN_CD_KEY_A-' || parent.objectId || '-' || CAST(child.VALUE_INDEX AS VARCHAR(4000)) AS objectid,
parent.objectId AS parentid,
parent.id,
parent.date,
CAST(ABN_BHV_CD_KEY AS INTEGER) AS "abn_bhv_code",
CAST(ABN_CD_KEY AS INTEGER) AS "abn_code",
CAST(SIB_FRQ AS INTEGER) AS "sib_frq",
CASE WHEN TOP_CD_KEY  IS NOT NULL THEN ('T-' || TOP_CD_KEY) ELSE NULL END AS "top_code",
CAST(VALUE_INDEX AS INTEGER) AS "value_index",
parent.created AS created,
parent.createdBy AS createdBy,
parent.modified AS modified,
parent.modifiedBy AS modifiedBy,
parent.updated_at AS updated_at,
parent.RECORD_DELETED
FROM ABN__ABN_CD_KEY_A AS child
JOIN q_abn AS parent ON parent.objectId = child.MVON_KEY
