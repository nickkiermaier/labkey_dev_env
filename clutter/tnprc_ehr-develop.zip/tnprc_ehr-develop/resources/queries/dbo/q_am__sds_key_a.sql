/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
'AM__LYM_KEY_A-' || CAST(child.MVON_KEY AS VARCHAR(4000)) + '-' + CAST(child.VALUE_INDEX AS VARCHAR(4000)) AS objectid,
CAST(parent.objectid AS VARCHAR(4000)) AS parentid,
CAST(parent.id AS VARCHAR(4000)) AS id,
CAST(parent.date AS TIMESTAMP) AS "date",
CAST(SDS_KEY AS INTEGER) AS "sds_key",
VALUE_INDEX AS "value_index",
created,
createdBy,
modified,
modifiedBy,
updated_at,
RECORD_DELETED
FROM AM__SDS_KEY_A AS child
  JOIN q_demographics AS parent ON parent.objectid = child.MVON_KEY 
WHERE RECORD_DELETED = 'false'
