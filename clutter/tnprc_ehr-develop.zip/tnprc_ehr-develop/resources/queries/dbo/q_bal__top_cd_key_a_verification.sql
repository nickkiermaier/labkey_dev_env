/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
'BAL__TOP_CD_KEY_A-' ||CAST(child.MVON_KEY AS VARCHAR(4000)) || '-' || CAST(child.VALUE_INDEX AS VARCHAR(4000)) AS objectid,
CAST(bal.objectid AS VARCHAR(4000)) AS parentid,
CAST(bal.id AS VARCHAR(4000)) AS id,
CAST(bal.date AS TIMESTAMP) AS "date",
'T-' || CAST(TOP_CD_KEY AS VARCHAR(4000)) AS "top_code",
CAST(VALUE_INDEX AS INTEGER) AS "value_index",
CAST(bal.created AS TIMESTAMP) AS created,
CAST(bal.createdBy AS VARCHAR(4000)) AS createdBy,
CAST(bal.modified AS TIMESTAMP) AS modified,
CAST(bal.modifiedBy AS VARCHAR(4000)) AS modifiedBy,
bal.updated_at AS updated_at
FROM BAL__TOP_CD_KEY_A AS child
JOIN 
(
SELECT
BAL_KEY as objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS Id,
CASE WHEN BAL_TIME IS NULL
THEN CAST(BAL_DT AS TIMESTAMP)
ELSE CAST((BAL_DT || ' ' || BAL_TIME) AS TIMESTAMP)
END AS "date",
CAST(BAL_BILL_PROJ_KEY AS INTEGER) AS project,
CAST(BAL_COMMENT AS VARCHAR(4000)) AS "comment",
CAST(BAL_GROSS_FINDING AS VARCHAR(4000)) AS "gross_finding",
CASE WHEN BAL_PREANESTHETIC = 'Y' THEN TRUE
   WHEN BAL_PREANESTHETIC = 'N' THEN FALSE
   ELSE NULL END AS "preanesthetic",
CAST(PRC_KEY AS VARCHAR(4000)) AS "parentid",
CAST(VET_PERS_KEY AS INTEGER) AS "vet_pers_key",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM BAL
) 
AS bal ON bal.objectid = child.MVON_KEY
WHERE bal.RECORD_DELETED = FALSE