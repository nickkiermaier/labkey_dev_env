/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
CAST(SUP_KEY AS VARCHAR(4000)) AS value,
CU_UNIT_CD_KEY AS cu_unit_code,
DU_UNIT_CD_KEY AS du_unit_code,
SUP_COM_NAME AS com_name,
SUP_DESC AS description,
CASE WHEN SUP_DISC_FL='Y' THEN TRUE
  WHEN SUP_DISC_FL='N' THEN FALSE
  ELSE NULL END AS disc_fl,
SUP_GEN_NAME AS gen_name,
SUP_LOCATION AS location,
SUP_MFR_NUM AS mfr_num,
SUP_NOTES AS notes,
SUP_ROL AS rol,
SUP_TYPE_CD_KEY AS type_code,
SUP_UIS AS uis,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at
FROM SUP
WHERE RECORD_DELETED = FALSE
