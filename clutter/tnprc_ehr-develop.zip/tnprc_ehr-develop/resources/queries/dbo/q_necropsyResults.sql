/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0q_urn.sql
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
        NCR_KEY || '_WT_KG' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'WT KG' AS test_type,
        NCR_WT_KG AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_WT_KG IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_DTH_CODE' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'DTH Code' AS test_type,
        NULL AS test_result,
        CAST(DTH_CD_KEY AS INTEGER) as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE DTH_CD_KEY IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_DISP_CODE' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'DISP Code' AS test_type,
        NULL AS test_result,
        NULL as dth_code,
        CAST(DISP_CD_KEY AS INTEGER) as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE DISP_CD_KEY IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_INT_CODE' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'INT Code' AS test_type,
        NULL AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        CAST(NCR_INT_CD_KEY AS INTEGER) as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_INT_CD_KEY IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_DTH_CONV' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'DTH Conv' AS test_type,
        NCR_DTH_CONV AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_DTH_CONV IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_HEAD' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Head' AS test_type,
        NCR_HEAD AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_HEAD IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_ORAL_CAVITY' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Oral Cavity' AS test_type,
        NCR_ORAL_CAVITY AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_ORAL_CAVITY IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_TEETH' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Teeth' AS test_type,
        NCR_TEETH AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_TEETH IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_EYES' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Eyes' AS test_type,
        NCR_EYES AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_EYES IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_BODY' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Body' AS test_type,
        NCR_BODY AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_BODY IS NOT NULL 
 

UNION SELECT
        NCR_KEY || 'EXTREMITIES' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Extremities' AS test_type,
        NCR_EXTREMITIES AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_EXTREMITIES IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_HAIR_COAT' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Hair Coat' AS test_type,
        NCR_HAIR_COAT AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_HAIR_COAT IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_BODY_ORIFICES' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Body Orifices' AS test_type,
        NCR_BODY_ORIFICES AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_BODY_ORIFICES IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_SKIN' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Skin' AS test_type,
        NCR_SKIN AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_SKIN IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_NUTRITION' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Nutrition' AS test_type,
        NCR_NUTRITION AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_NUTRITION IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_POS_OF_VISCERA_THOR' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Pos of Viscera THOR' AS test_type,
        NCR_POS_OF_VISCERA_THOR AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_POS_OF_VISCERA_THOR IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_THYMUS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Thymus' AS test_type,
        NCR_THYMUS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_THYMUS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_THYROIDS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Thyroids' AS test_type,
        NCR_THYROIDS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_THYROIDS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_LUNGS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Lungs' AS test_type,
        NCR_LUNGS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_LUNGS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_LYMPH_NODES' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Lymph Nodes' AS test_type,
        NCR_LYMPH_NODES AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_LYMPH_NODES IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_HEART' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Heart' AS test_type,
        NCR_HEART AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_HEART IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_POS_OF_VISCERA_AB' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Pos of Viscera AB' AS test_type,
        NCR_POS_OF_VISCERA_AB AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_POS_OF_VISCERA_AB IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_AORTA' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Aorta' AS test_type,
        NCR_AORTA AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_AORTA IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_SPLEEN' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Spleen' AS test_type,
        NCR_SPLEEN AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_SPLEEN IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_LIVER' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Liver' AS test_type,
        NCR_LIVER AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_LIVER IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_GALLBLADDER' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Gallbladder' AS test_type,
        NCR_GALLBLADDER AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_GALLBLADDER IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_PANCREAS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Pancreas' AS test_type,
        NCR_PANCREAS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_PANCREAS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_MUSCLES' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Muscles' AS test_type,
        NCR_MUSCLES AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_MUSCLES IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_BONES' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Bones' AS test_type,
        NCR_BONES AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_BONES IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_NCR_JOINTS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",
        'Joints' AS test_type,
        NCR_JOINTS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_JOINTS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_BONE_MARROW' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Bone Marrow' AS test_type,
        NCR_BONE_MARROW AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_BONE_MARROW IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_MOUTH' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Mouth' AS test_type,
        NCR_MOUTH AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_MOUTH IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_TONGUE' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Tongue' AS test_type,
        NCR_TONGUE AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_TONGUE IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_ESOPHAGUS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Esophagus' AS test_type,
        NCR_ESOPHAGUS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_ESOPHAGUS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_STOMACH' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Stomach' AS test_type,
        NCR_STOMACH AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_STOMACH IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_SMALL_INTESTINE' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Small Intestine' AS test_type,
        NCR_SMALL_INTESTINE AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_SMALL_INTESTINE IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_CECUM' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Cecum' AS test_type,
        NCR_CECUM AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_CECUM IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_COLON' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Colon' AS test_type,
        NCR_COLON AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_COLON IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_RECTUM' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Rectum' AS test_type,
        NCR_RECTUM AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_RECTUM IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_ANUS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Anus' AS test_type,
        NCR_ANUS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_ANUS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_CONTENTS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Contents' AS test_type,
        NCR_CONTENTS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_CONTENTS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_MESEN_LYM_NODE' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Mesen Lym Node' AS test_type,
        NCR_MESEN_LYM_NODE AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_MESEN_LYM_NODE IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_ADRENALS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Adrenals' AS test_type,
        NCR_ADRENALS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_ADRENALS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_KIDNEYS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Kidneys' AS test_type,
        NCR_KIDNEYS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_KIDNEYS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_URETERS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Ureters' AS test_type,
        NCR_URETERS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_URETERS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_BLADDER' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Bladder' AS test_type,
        NCR_BLADDER AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_BLADDER IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_TESTIS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Testis' AS test_type,
        NCR_TESTIS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_TESTIS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_EPIDIDYMIS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Epididymis' AS test_type,
        NCR_EPIDIDYMIS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_EPIDIDYMIS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_PROSTATE' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Prostate' AS test_type,
        NCR_PROSTATE AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_PROSTATE IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_PENIS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Penis' AS test_type,
        NCR_PENIS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_PENIS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_PERIPH_LYMPH_NODES' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Periph Lymph Nodes' AS test_type,
        NCR_PERIPH_LYMPH_NODES AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_PERIPH_LYMPH_NODES IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_PITUITARY' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Pituitary' AS test_type,
        NCR_PITUITARY AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_PITUITARY IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_BRAIN' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Brain' AS test_type,
        NCR_BRAIN AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_BRAIN IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_BACTI' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Bacti' AS test_type,
        NCR_BACTI AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_BACTI IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_PAR' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'PAR' AS test_type,
        NCR_PAR AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_PAR IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_OTHER_STUDIES' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Other Studies' AS test_type,
        NCR_OTHER_STUDIES AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_OTHER_STUDIES IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_RAD' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'RAD' AS test_type,
        NCR_RAD AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_RAD IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_OVARIES' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Ovaries' AS test_type,
        NCR_OVARIES AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_OVARIES IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_OVIDUCTS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Oviducts' AS test_type,
        NCR_OVIDUCTS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_OVIDUCTS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_UTERUS' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Uterus' AS test_type,
        NCR_UTERUS AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_UTERUS IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_CERVIX' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Cervix' AS test_type,
        NCR_CERVIX AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_CERVIX IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_VAGINA' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Vagina' AS test_type,
        NCR_VAGINA AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_VAGINA IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_THORACIC_CAVITY' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Thoracic Cavity' AS test_type,
        NCR_THORACIC_CAVITY AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_THORACIC_CAVITY IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_ABDOMINAL_CAVITY' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Abdominal Cavity' AS test_type,
        NCR_ABDOMINAL_CAVITY AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_ABDOMINAL_CAVITY IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_PERIPHERAL_NERVES' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Peripheral Nerves' AS test_type,
        NCR_PERIPHERAL_NERVES AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_PERIPHERAL_NERVES IS NOT NULL 
 

UNION SELECT
        NCR_KEY || '_PERIPHERAL_NERVES' AS objectid,
        NCR_KEY as parentid,
        CAST(AM_KEY AS VARCHAR(4000)) AS id,
        CASE WHEN NCR_TIME IS NULL
                THEN CAST(NCR_DT AS TIMESTAMP)
             ELSE
                CAST((NCR_DT || ' ' || NCR_TIME) AS TIMESTAMP)
             END AS "date",        
        'Peripheral Nerves' AS test_type,
        NCR_PERIPHERAL_NERVES AS test_result,
        NULL as dth_code,
        NULL as disp_code,
        NULL as int_code,
        NULL AS remark,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
        CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
        CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
        UPDATE_DATETIME AS updated_at,
        RECORD_DELETED
    FROM NCR
    WHERE NCR_PERIPHERAL_NERVES IS NOT NULL 
 
