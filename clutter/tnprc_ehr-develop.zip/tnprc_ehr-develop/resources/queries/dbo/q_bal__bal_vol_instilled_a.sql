/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
'BAL__BAL_VOL_INSTILLED_A-' || CAST(bvi.MVON_KEY AS VARCHAR(4000)) || '-' || CAST(bvi.VALUE_INDEX AS VARCHAR(4000)) AS objectid,
CAST(bal.objectid AS VARCHAR(4000)) AS parentid,
CAST(bal.id AS VARCHAR(4000)) AS id,
CAST(bal.date AS TIMESTAMP) AS "date",
BAL_VOL_ASPIRATED AS vol_aspirated,
BAL_VOL_INSTILLED AS vol_instilled,
VALUE_INDEX AS value_index,
CAST(bal.created AS TIMESTAMP) AS created,
CAST(bal.createdBy AS VARCHAR(4000)) AS createdBy,
CAST(bal.modified AS TIMESTAMP) AS modified,
CAST(bal.modifiedBy AS VARCHAR(4000)) AS modifiedBy,
bal.updated_at AS updated_at
FROM BAL__BAL_VOL_INSTILLED_A  AS bvi
JOIN q_bal AS bal ON bal.objectid = bvi.MVON_KEY
WHERE bal.RECORD_DELETED = FALSE