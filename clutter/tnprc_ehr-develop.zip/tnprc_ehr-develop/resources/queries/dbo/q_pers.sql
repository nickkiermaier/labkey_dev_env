/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
PERS_KEY AS value,
DPT_CD_KEY AS dpt_code,
INSUR_CD_KEY AS insur_code,
LAB_SENT_CD_KEY AS lab_sent_code,
CASE WHEN PERS_ACTIVE_FL='Y' THEN TRUE
  WHEN PERS_ACTIVE_FL='N' THEN FALSE
  ELSE NULL END AS active_fl,
PERS_BEGIN_EMPLOY_DT AS begin_employ_dt,
PERS_COM AS comment,
PERS_EMAIL AS email,
PERS_END_EMPLOY_DT AS end_employ_dt,
PERS_IN_CHARGE_OF_BLDG AS in_charge_of_bldg,
PERS_NAME_FN AS name_fn,
PERS_NAME_INIT AS name_init,
PERS_NAME_LN AS name_ln,
PERS_NAME_PRE AS name_pre,
PERS_NAME_SFX AS name_sfx,
PERS_OUTSIDE_INVEST_INST AS outside_invest_inst,
PERS_PH_EXT AS ph_ext,
PERS_PH_EXT_2 AS ph_ext_2,
PERS_TB_APPT_DT1 AS tb_appt_dt1,
PERS_TB_APPT_DT1_TEST AS tb_appt_dt1_test,
PERS_TB_APPT_DT2 AS tb_appt_dt2,
PERS_TB_APPT_DT2_TEST AS tb_appt_dt2_test,
PERS_TB_DT AS tb_dt,
CASE WHEN PERS_TB_POSITIVE_FL='Y' THEN TRUE
  WHEN PERS_TB_POSITIVE_FL='N' THEN FALSE
  ELSE NULL END AS tb_positive_fl,
PERS_TB_TEST_LOC AS tb_test_loc,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM PERS
