/*
* Copyright (c) 2017-2018 LabKey Corporation
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
SELECT
OUT_INV_CD_KEY AS sort_order,
LAB_SENT_CD_KEY AS lab_sent_cd,
CASE OUT_INV_CD_ACTIVE_FL
WHEN 'Y' THEN NULL
WHEN 'N' THEN '1/1/1970'
END AS date_disabled,
OUT_INV_CD_CITY AS city,
OUT_INV_CD_CO_NAME AS co_name,
OUT_INV_CD_EMAIL AS email,
OUT_INV_CD_FAX_NUM AS fax_num,
OUT_INV_CD_KEY AS "value",
OUT_INV_CD_NAME_FN AS name_fn,
OUT_INV_CD_NAME_LN AS name_ln,
OUT_INV_CD_NAME_PRE AS name_pre,
OUT_INV_CD_PHONE_NUM AS phone_num,
OUT_INV_CD_STATE AS state,
OUT_INV_CO_NAME_SHORT AS name_short,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM OUT_INV_CD