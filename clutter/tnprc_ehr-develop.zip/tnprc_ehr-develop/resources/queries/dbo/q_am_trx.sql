/*
 * Copyright (c) 2017-2019 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
CASE WHEN dtl_dtl.am_key IS NOT NULL THEN (trx.AM_TRX_KEY || '-' || dtl.AM_TRX_DTL_KEY || '-' || dtl_dtl.am_key)
    WHEN am_key.am_key IS NOT NULL THEN (trx.AM_TRX_KEY || '-' || dtl.AM_TRX_DTL_KEY || '-' || am_key.am_key)
    WHEN dtl.AM_TRX_DTL_KEY IS NOT NULL THEN (trx.AM_TRX_KEY || '-' || dtl.AM_TRX_DTL_KEY)
    ELSE trx.AM_TRX_KEY END AS objectid,
dtl.AM_TRX_DTL_KEY AS parentid,
CAST(trx.AM_TRX_NUM AS INTEGER) AS "trx_num",
CAST(trx.AM_TRX_DT AS TIMESTAMP) AS "date",
CAST(trx.PROJ_KEY_TO AS INTEGER) AS "project", -- should be the same as dtl.PROJ_KEY_TO
CAST(dtl.PROJ_KEY AS INTEGER) AS "project_from",
CASE WHEN dtl_dtl.am_key IS NOT NULL OR am_key.am_key IS NOT NULL THEN NULL
    ELSE CAST(AM_TRX_DTL_AM_CNT AS INTEGER) END AS "animal_count",
COALESCE(dtl_dtl.am_key, am_key.am_key) AS "id",
CAST(trx.AM_TRX_EFF_DT AS TIMESTAMP) AS "effective_dt",
CASE WHEN trx.AM_TRX_PREPAY_FL='Y' THEN TRUE ELSE FALSE END AS "prepay_fl",
CAST(dtl.NC_RSN_CD_KEY AS INTEGER) AS "no_charge_reason_code",
CASE WHEN AM_TRX_DTL_IDC_FL='N' THEN FALSE ELSE TRUE END AS "include_idc_fl",
CAST(trx.AM_TRX_COM AS VARCHAR(4000)) AS "comment",
CASE WHEN trx.AM_TRX_BO_APPROVAL_FL='Y' THEN TRUE ELSE FALSE END AS "bo_approval_fl",
CAST(trx.AM_TRX_BO_APPROVAL_DT AS TIMESTAMP) AS "bo_approval_dt",
CAST(trx.AM_TRX_IT_COM AS VARCHAR(4000)) AS "bo_comment",
CAST(trx.UPDATE_DATE || ' ' || trx.UPDATE_TIME AS TIMESTAMP) AS created,
CAST(trx.UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(trx.UPDATE_DATE || ' ' || trx.UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(trx.UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
CAST(trx.UPDATE_DATETIME AS TIMESTAMP) AS updated_at
FROM AM_TRX AS trx
LEFT JOIN AM_TRX_DTL AS dtl
  ON trx.AM_TRX_KEY = dtl.AM_TRX_KEY AND dtl.RECORD_DELETED = FALSE
LEFT JOIN AM_TRX_DTL_DTL AS dtl_dtl
  ON dtl.AM_TRX_DTL_KEY = dtl_dtl.AM_TRX_DTL_KEY AND dtl.RECORD_DELETED = FALSE
LEFT JOIN AM_TRX_DTL__AM_KEY_A AS am_key
  ON dtl.AM_TRX_DTL_KEY = am_key.MVON_KEY
WHERE trx.RECORD_DELETED = FALSE