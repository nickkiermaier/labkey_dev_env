/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
SRV_CD_KEY AS sort_order,
DPT_CD_KEY as dpt_code,
IT_PROGS_KEY as it_progs_key,
RATE_FIELD_LOC as rate_field_loc,
SRV_CD_AMT_FL as amt_fl,
SRV_CD_DESC as title,
SRV_CD_IT_PROGS_FILE_NAME as it_progs_file_name,
SRV_CD_KEY as "value",
SRV_CD_NAT_ACCT as nat_acct,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM SRV_CD