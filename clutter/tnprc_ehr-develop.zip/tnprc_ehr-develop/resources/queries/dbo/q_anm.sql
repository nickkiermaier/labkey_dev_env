/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
    ANM_KEY || '_HEART_RATE' AS objectid,
    ANM_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CAST(ANM_DT || ' ' || ANM_START_TIME AS TIMESTAMP) AS "date",
    'Heart Rate' AS test_type,
    NULL AS test_symbol,
    CAST(ANM_HEART_RATE AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM ANM WHERE ANM_HEART_RATE IS NOT NULL 
AND RECORD_DELETED = 'false' 

UNION SELECT
    ANM_KEY || '_RESP_RATE' AS objectid,
    ANM_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CAST(ANM_DT || ' ' || ANM_START_TIME AS TIMESTAMP) AS "date",
    'Resp Rate' AS test_type,
    NULL AS test_symbol,
    CAST(ANM_RESP_RATE AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM ANM WHERE ANM_RESP_RATE IS NOT NULL 
AND RECORD_DELETED = 'false' 

UNION SELECT
    ANM_KEY || '_ETCO2' AS objectid,
    ANM_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CAST(ANM_DT || ' ' || ANM_START_TIME AS TIMESTAMP) AS "date",
    'ETCO2' AS test_type,
    NULL AS test_symbol,
    CAST(ANM_ETCO2 AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM ANM WHERE ANM_ETCO2 IS NOT NULL 
AND RECORD_DELETED = 'false' 

UNION SELECT
    ANM_KEY || '_SPO2' AS objectid,
    ANM_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CAST(ANM_DT || ' ' || ANM_START_TIME AS TIMESTAMP) AS "date",
    'SPO2' AS test_type,
    NULL AS test_symbol,
    CAST(ANM_SPO2 AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM ANM WHERE ANM_SPO2 IS NOT NULL 
AND RECORD_DELETED = 'false' 

UNION SELECT
    ANM_KEY || '_CRT' AS objectid,
    ANM_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CAST(ANM_DT || ' ' || ANM_START_TIME AS TIMESTAMP) AS "date",
    'CRT' AS test_type,
    CASE WHEN ANM_CRT LIKE '<%' THEN '<'
        WHEN ANM_CRT LIKE '>%' THEN '>'
        ELSE NULL END AS test_symbol,
    CASE WHEN ANM_CRT = '<2' OR ANM_CRT = '>2' THEN 2 ELSE ANM_CRT END AS test_result, --varchar
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM ANM WHERE ANM_CRT IS NOT NULL 
AND RECORD_DELETED = 'false' 

UNION SELECT
    ANM_KEY || '_BP_SYSTOLIC' AS objectid,
    ANM_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CAST(ANM_DT || ' ' || ANM_START_TIME AS TIMESTAMP) AS "date",
    'Systolic Blood Pressure' AS test_type,
    NULL AS test_symbol,
    CAST(ANM_BP_SYSTOLIC AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM ANM WHERE ANM_BP_SYSTOLIC IS NOT NULL 
AND RECORD_DELETED = 'false' 

UNION SELECT
    ANM_KEY || '_BP_DIASTOLIC' AS objectid,
    ANM_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CAST(ANM_DT || ' ' || ANM_START_TIME AS TIMESTAMP) AS "date",
    'Diastolic Blood Pressure' AS test_type,
    NULL AS test_symbol,
    CAST(ANM_BP_DIASTOLIC AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM ANM WHERE ANM_BP_DIASTOLIC IS NOT NULL 
AND RECORD_DELETED = 'false' 

UNION SELECT
    ANM_KEY || '_TEMP' AS objectid,
    ANM_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CAST(ANM_DT || ' ' || ANM_START_TIME AS TIMESTAMP) AS "date",
    'Temperature' AS test_type,
    NULL AS test_symbol,
    CAST(ANM_TEMP AS DOUBLE) AS test_result, --double
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM ANM WHERE ANM_TEMP IS NOT NULL 
AND RECORD_DELETED = 'false' 

UNION SELECT
    ANM_KEY || '_MAP' AS objectid,
    ANM_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CAST(ANM_DT || ' ' || ANM_START_TIME AS TIMESTAMP) AS "date",
    'MAP' AS test_type,
    NULL AS test_symbol,
    CAST(ANM_MAP AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM ANM WHERE ANM_MAP IS NOT NULL 
AND RECORD_DELETED = 'false' 

UNION SELECT
    ANM_KEY || '_ISOFLURANE' AS objectid,
    ANM_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CAST(ANM_DT || ' ' || ANM_START_TIME AS TIMESTAMP) AS "date",
    'Isoflurane' AS test_type,
    NULL AS test_symbol,
    CAST(ANM_ISOFLURANE AS DOUBLE) AS test_result, --double
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM ANM WHERE ANM_ISOFLURANE IS NOT NULL 
AND RECORD_DELETED = 'false' 

UNION SELECT
    ANM_KEY || '_FLUID_RATE' AS objectid,
    ANM_KEY AS parentid,
    CAST(AM_KEY AS VARCHAR(4000)) AS id,
    CAST(ANM_DT || ' ' || ANM_START_TIME AS TIMESTAMP) AS "date",
    'Fluid Rate' AS test_type,
    NULL AS test_symbol,
    CAST(ANM_FLUID_RATE AS DOUBLE) AS test_result, --integer
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM ANM WHERE ANM_FLUID_RATE IS NOT NULL 
AND RECORD_DELETED = 'false' 
