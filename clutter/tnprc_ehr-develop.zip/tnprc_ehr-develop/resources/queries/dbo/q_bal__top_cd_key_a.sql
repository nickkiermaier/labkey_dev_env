/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
'BAL__TOP_CD_KEY_A-' ||CAST(child.MVON_KEY AS VARCHAR(4000)) || '-' || CAST(child.VALUE_INDEX AS VARCHAR(4000)) AS objectid,
CAST(bal.objectid AS VARCHAR(4000)) AS parentid,
CAST(bal.id AS VARCHAR(4000)) AS id,
CAST(bal.date AS TIMESTAMP) AS "date",
'T-' || CAST(TOP_CD_KEY AS VARCHAR(4000)) AS "top_code",
CAST(VALUE_INDEX AS INTEGER) AS "value_index",
CAST(bal.created AS TIMESTAMP) AS created,
CAST(bal.createdBy AS VARCHAR(4000)) AS createdBy,
CAST(bal.modified AS TIMESTAMP) AS modified,
CAST(bal.modifiedBy AS VARCHAR(4000)) AS modifiedBy,
bal.updated_at AS updated_at
FROM BAL__TOP_CD_KEY_A AS child
JOIN q_bal AS bal ON bal.objectid = child.MVON_KEY
WHERE bal.RECORD_DELETED = FALSE
