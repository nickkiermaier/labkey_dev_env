/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0q_urn.sql
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
MVON_KEY AS ncr_tss_code,
TISSUE_SPM_CD_KEY AS spm_code,
VALUE_INDEX AS value_index,
parent.updated_at,
parent.RECORD_DELETED
FROM NCR_TSS_CD__SPM_CD_KEY_A AS child
  JOIN q_ncr_tss_codes AS parent ON parent.value = child.MVON_KEY
