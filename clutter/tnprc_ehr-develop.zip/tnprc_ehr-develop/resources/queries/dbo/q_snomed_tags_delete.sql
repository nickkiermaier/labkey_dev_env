/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
CAST(SNO_KEY AS VARCHAR(4000)) || '-E-' || CAST(VALUE_INDEX AS VARCHAR(4000)) AS objectid,
SNO.UPDATE_DATETIME AS updated_at
FROM SNO__ET_CD_KEY_A a
JOIN SNO ON SNO.MVON_KEY = a.MVON_KEY
WHERE SNO.RECORD_DELETED = TRUE

UNION SELECT
CAST(SNO_KEY AS VARCHAR(4000)) || '-D-' || CAST(VALUE_INDEX AS VARCHAR(4000)) AS objectid,
SNO.UPDATE_DATETIME AS updated_at
FROM SNO__DS_CD_KEY_A a
JOIN SNO ON SNO.MVON_KEY = a.MVON_KEY
WHERE SNO.RECORD_DELETED = TRUE

UNION SELECT
CAST(SNO_KEY AS VARCHAR(4000)) || '-F-' || CAST(VALUE_INDEX AS VARCHAR(4000)) AS objectid,
SNO.UPDATE_DATETIME AS updated_at
FROM SNO__FNC_CD_KEY_A a
JOIN SNO ON SNO.MVON_KEY = a.MVON_KEY
WHERE SNO.RECORD_DELETED = TRUE

UNION SELECT
CAST(SNO_KEY AS VARCHAR(4000)) || '-M-' || CAST(VALUE_INDEX AS VARCHAR(4000)) AS objectid,
SNO.UPDATE_DATETIME AS updated_at
FROM SNO__MRP_CD_KEY_A a
JOIN SNO ON SNO.MVON_KEY = a.MVON_KEY
WHERE SNO.RECORD_DELETED = TRUE

UNION SELECT
CAST(SNO_KEY AS VARCHAR(4000)) || '-P-' || CAST(VALUE_INDEX AS VARCHAR(4000)) AS objectid,
SNO.UPDATE_DATETIME AS updated_at
FROM SNO__PROC_CD_KEY_A a
JOIN SNO ON SNO.MVON_KEY = a.MVON_KEY
WHERE SNO.RECORD_DELETED = TRUE

UNION SELECT
CAST(SNO_KEY AS VARCHAR(4000)) || '-T-' || CAST(VALUE_INDEX AS VARCHAR(4000)) AS objectid,
SNO.UPDATE_DATETIME AS updated_at
FROM SNO__TOP_CD_KEY_A a
JOIN SNO ON SNO.MVON_KEY = a.MVON_KEY
WHERE SNO.RECORD_DELETED = TRUE