/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT
'AM__DM_CD_KEY_A-' || CAST(child.MVON_KEY AS VARCHAR(4000)) || '-' || CAST(child.VALUE_INDEX AS VARCHAR(4000)) AS objectid,
CAST(parent.objectid AS VARCHAR(4000)) AS parentid,
CAST(parent.id AS VARCHAR(4000)) AS id,
CAST(parent.date AS TIMESTAMP) AS "date",
CAST(DM_CD_KEY AS INTEGER) AS "dm_code",
VALUE_INDEX AS "value_index",
created,
createdBy,
modified,
modifiedBy,
updated_at,
RECORD_DELETED
FROM AM__DM_CD_KEY_A AS child 
  JOIN 
(
SELECT AM_KEY AS objectid,
    AM_KEY AS id,
    AGE_EST_CD_KEY as age_est_code,
    AM_CS as case_summary,
    CASE WHEN AM_ENTRY_DT IS NULL THEN '10/01/1964'
        ELSE AM_ENTRY_DT END AS "date",
    CASE WHEN AM_ENTRY_DT IS NULL
        THEN (CASE WHEN AM_REM IS NOT NULL
            THEN (AM_REM || '; Using default date value of 10/01/1964 since AM_ENTRY_DT was NULL for this record.')
            ELSE 'Using default date value of 10/01/1964 since AM_ENTRY_DT was NULL for this record.' END)
        ELSE AM_REM END AS remark,
    AM_BIRTH_DT AS birth,
    CASE WHEN ST_CD_KEY = 2 THEN AM_DEPART_DT
        ELSE NULL END AS death,
    AM_EAR_TAG_NUM as ear_tag_num,
    AM_FOSTER_DAM_KEY as foster_dam,
    CASE WHEN ST_CD_KEY = 1 THEN 'ALIVE'
        WHEN ST_CD_KEY = 2 THEN 'DEAD'
        WHEN ST_CD_KEY = 3 THEN 'TRANS'
        WHEN ST_CD_KEY = 4 THEN 'MISS'
        WHEN ST_CD_KEY = 5 THEN 'WOODS'
        ELSE ST_CD_KEY END AS calculated_status,
    AM_DAM_KEY AS dam,
    AM_SIRE_KEY as sire,
    CH_CD_KEY as chain_code,
    CAST(DISP_CD_KEY AS INTEGER) as disp_code,
    CAST(EC_CD_KEY AS INTEGER) as entry_cat_code,
    PROJ_KEY as project,
    SEX_CD_KEY AS gender,
    CTRY_CD_KEY AS geographic_origin,
    ORIGIN_CD_KEY AS origin,
    SP_CD_KEY AS species,
    NULL as num_mice,
    CAST(VEN_CD_KEY AS INTEGER) as vendor_code,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM AM
    
UNION SELECT 'BOX-' || BM_KEY AS objectid,
    'BOX-' || BM_KEY AS id,
    NULL as age_est_code,
    NULL as case_summary,
    CASE WHEN BM_ENTRY_DT IS NULL THEN '10/01/1964'
        ELSE BM_ENTRY_DT END AS "date",
    CASE WHEN BM_ENTRY_DT IS NULL THEN 'Using default date value of 10/01/1964 since AM_ENTRY_DT was NULL for this record.'
        END AS remark,
    BM_BIRTH_DT AS birth,
    CASE WHEN ST_CD_KEY = 2 THEN BM_DEPART_DT
        ELSE NULL END AS death,
    NULL as ear_tag_num,
    NULL as foster_dam,
    CASE WHEN ST_CD_KEY = 1 THEN 'ALIVE'
        WHEN ST_CD_KEY = 2 THEN 'DEAD'
        WHEN ST_CD_KEY = 3 THEN 'TRANS'
        WHEN ST_CD_KEY = 4 THEN 'MISS'
        WHEN ST_CD_KEY = 5 THEN 'WOODS'
        ELSE ST_CD_KEY END AS calculated_status,
    NULL AS dam,
    NULL as sire,
    NULL as chain_code,
    NULL as disp_code,
    NULL as entry_cat_code,
    NULL as project,
    SEX_CD_KEY AS gender,
    CTRY_CD_KEY AS geographic_origin,
    NULL AS origin,
    SP_CD_KEY AS species,
    CAST(BM_NUMBER_ANIMALS AS INTEGER) as num_mice,
    CAST(VEN_CD_KEY AS INTEGER) as vendor_code,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
    CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
    CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
    UPDATE_DATETIME AS updated_at,
    RECORD_DELETED
FROM BM
)
AS parent ON parent.objectid = child.MVON_KEY 
WHERE RECORD_DELETED = 'false'
