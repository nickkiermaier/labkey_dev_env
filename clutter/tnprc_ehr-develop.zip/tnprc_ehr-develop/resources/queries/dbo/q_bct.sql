/*
 * Copyright (c) 2017-2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

SELECT 
BCT_KEY AS objectid,
CAST(AM_KEY AS VARCHAR(4000)) AS id,
CASE WHEN BCT_TIME IS NULL
THEN CAST(BCT_DT AS TIMESTAMP)
ELSE CAST((BCT_DT || ' ' || BCT_TIME) AS TIMESTAMP)
END AS "date",
BCT_BILL_DT AS "bill_dt",
CAST(BCT_BILL_PROJ_KEY AS INTEGER) AS project,
CASE WHEN BCT_CHG_FL='Y' THEN 'true' WHEN BCT_CHG_FL='N' THEN 'false' ELSE NULL END AS "chg_fl",
BCT_COM AS "remark",
CASE WHEN BCT_CYTOSPIN='Y' THEN 'true' WHEN BCT_CYTOSPIN='N' THEN 'false' ELSE NULL END AS "cytospin",
CASE WHEN BCT_SENS_FL='Y' THEN 'true' WHEN BCT_SENS_FL='N' THEN 'false' ELSE NULL END AS "sens_fl",
CAST(CANCEL_CD_KEY AS INTEGER) AS "cancel_code",
CAST(LAB_SENT_CD_KEY AS INTEGER) AS "lab_sent_code",
CAST(PRC_KEY AS VARCHAR(4000)) AS "parentid",
CAST(PUR_CD_KEY AS INTEGER) AS "pur_code",
CAST(SPM_CD_KEY AS VARCHAR(4000)) AS "spm_code",
CAST(VET_PERS_KEY AS INTEGER) AS "vet_pers_key",
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS created,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS createdBy,
CAST(UPDATE_DATE || ' ' || UPDATE_TIME AS TIMESTAMP) AS modified,
CAST(UPDATE_PERSON AS VARCHAR(4000)) AS modifiedBy,
UPDATE_DATETIME AS updated_at,
RECORD_DELETED
FROM BCT