/*
 * Copyright (c) 2018 LabKey Corporation
 *
 * Licensed under the Apache License, Version 2.0: http://www.apache.org/licenses/LICENSE-2.0
 */
SELECT
s.code,
s.meaning,
group_concat(ss.primaryCategory) as categories,
(s.meaning || ' (' || s.code || ')') as codeAndMeaning
FROM ehr_lookups.snomed s
LEFT JOIN ehr_lookups.snomed_subset_codes ss ON (s.code = ss.code)
WHERE ss.primaryCategory IS NOT NULL
GROUP BY s.code, s.meaning

UNION SELECT
s.code,
s.meaning,
group_concat(ss.secondaryCategory) as categories,
(s.meaning || ' (' || s.code || ')') as codeAndMeaning
FROM ehr_lookups.snomed s
LEFT JOIN ehr_lookups.snomed_subset_codes ss ON (s.code = ss.code)
WHERE ss.secondaryCategory IS NOT NULL
GROUP BY s.code, s.meaning