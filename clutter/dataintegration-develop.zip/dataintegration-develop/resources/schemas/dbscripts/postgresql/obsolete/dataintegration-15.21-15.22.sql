/*
 * Copyright (c) 2016-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
ALTER TABLE dataintegration.TransformRun DROP CONSTRAINT FK_TransformRun_ExpRunId;
ALTER TABLE dataintegration.TransformRun DROP COLUMN ExpRunId;