/*
 * Copyright (c) 2019 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
CREATE INDEX IX_TransformRun_Container_TransformId_StartTime_Status_JobId ON dataintegration.TransformRun
(
Container ASC,
TransformId ASC,
StartTime DESC,
Status ASC,
JobId ASC
);


CREATE INDEX IX_TransformRun_Container_TransformId_StartTime_EndTime_JobId ON dataintegration.TransformRun
(
Container ASC,
TransformId ASC,
StartTime DESC,
JobId ASC,
EndTime ASC
)
WHERE (EndTime IS NOT NULL);