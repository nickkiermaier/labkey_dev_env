/*
 * Copyright (c) 2017-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */

/* dataintegration-0.00-13.10.sql */

CREATE SCHEMA dataintegration;

-- CREATE PROCEDURE dataintegration.addDataIntegrationColumns @schemaName NVARCHAR(100), @tableName NVARCHAR(100)
-- AS
-- DECLARE @sql NVARCHAR(1000)
-- SELECT @sql = 'ALTER TABLE [' + @schemaName + '].[' + @tableName + '] ADD  ' +
--      '_txRowVersion ROWVERSION, ' +
--      '_txLastUpdated DATETIME, ' +
--      '_txTransactionId INT, ' +
--      '_txNote NVARCHAR(1000)';
-- EXEC sp_executesql @sql;
-- SELECT @sql = 'ALTER TABLE [' + @schemaName + '].[' + @tableName + '] ADD CONSTRAINT [_DF_' + @tableName + '_updated] ' +
--     'DEFAULT getutcdate() FOR [_txLastUpdated]';
-- EXEC sp_executesql @sql;
--
-- GO

CREATE TABLE dataintegration.TransformRun
(
    RowId SERIAL NOT NULL,
    Container ENTITYID NOT NULL,
    RecordCount INT,
    JobId INT NOT NULL,
    TransformId VARCHAR(50) NOT NULL,
    TransformVersion INT NOT NULL,
    Status VARCHAR(500),
    StartTime TIMESTAMP NULL,
    EndTime TIMESTAMP NULL,
    Created TIMESTAMP NULL,
    CreatedBy INT NULL,
    Modified TIMESTAMP NULL,
    ModifiedBy INT NULL,

    CONSTRAINT FK_TransformRun_JobId FOREIGN KEY (JobId) REFERENCES pipeline.StatusFiles (RowId),
    CONSTRAINT FK_TransformRun_Container FOREIGN KEY (Container) REFERENCES core.Containers(EntityId)
);

CREATE INDEX IDX_TransformRun_JobId ON dataintegration.TransformRun(JobId);
CREATE INDEX IDX_TransformRun_Container ON dataintegration.TransformRun(Container);

CREATE TABLE dataintegration.TransformConfiguration
(
    RowId SERIAL NOT NULL,
    Container ENTITYID NOT NULL,
    TransformId VARCHAR(50) NOT NULL,
    Enabled BOOLEAN,
    VerboseLogging BOOLEAN,
    LastChecked TIMESTAMP NULL,
    Created TIMESTAMP NULL,
    CreatedBy INT NULL,
    Modified TIMESTAMP NULL,
    ModifiedBy INT NULL,

    CONSTRAINT UQ_TransformConfiguration_TransformId UNIQUE (TransformId),
    CONSTRAINT FK_TransformConfiguration_Container FOREIGN KEY (Container) REFERENCES core.Containers(EntityId)
);

CREATE INDEX IDX_TransformConfiguration_Container ON dataintegration.TransformRun(Container);

ALTER TABLE dataintegration.TransformConfiguration
   ADD CONSTRAINT PK_TransformConfiguration PRIMARY KEY (RowId);

ALTER TABLE dataintegration.TransformRun ADD CONSTRAINT PK_TransformRun PRIMARY KEY (RowId);

DROP INDEX dataintegration.IDX_TransformConfiguration_Container;
ALTER TABLE dataintegration.TransformConfiguration DROP CONSTRAINT UQ_TransformConfiguration_TransformId;
ALTER TABLE dataintegration.TransformConfiguration ADD CONSTRAINT UQ_TransformConfiguration_TransformId UNIQUE (Container, TransformId);

/* dataintegration-13.10-13.20.sql */

ALTER TABLE dataintegration.TransformRun
  ADD COLUMN ExpRunId INT;

ALTER TABLE dataintegration.TransformRun
  ADD CONSTRAINT FK_TransformRun_ExpRunId FOREIGN KEY (ExpRunId) REFERENCES exp.ExperimentRun (RowId);

ALTER TABLE dataintegration.TransformRun RENAME RowId to TransformRunId;

ALTER TABLE dataintegration.TransformConfiguration ADD COLUMN TransformState TEXT;

/* dataintegration-13.20-13.30.sql */

SELECT core.fn_dropifexists('transformrun', 'dataintegration', 'CONSTRAINT', 'FK_TransformRun_JobId');
SELECT core.fn_dropifexists('transformrun', 'dataintegration', 'INDEX', 'IDX_TransformRun_JobId');
ALTER TABLE dataintegration.TransformRun DROP COLUMN JobId;


ALTER TABLE dataintegration.TransformRun ADD COLUMN JobId INT NULL;


ALTER TABLE dataintegration.TransformRun ADD CONSTRAINT FK_TransformRun_JobId FOREIGN KEY (JobId) REFERENCES pipeline.StatusFiles (RowId);
CREATE INDEX IDX_TransformRun_JobId ON dataintegration.TransformRun(JobId);


ALTER TABLE dataintegration.TransformRun ADD COLUMN TransformRunLog TEXT;

/* dataintegration-13.30-14.10.sql */

ALTER TABLE dataintegration.TransformRun ALTER COLUMN TransformId TYPE varchar(100);