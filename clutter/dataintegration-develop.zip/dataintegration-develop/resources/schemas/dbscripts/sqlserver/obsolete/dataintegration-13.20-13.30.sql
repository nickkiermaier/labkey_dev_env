/*
 * Copyright (c) 2015-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */

EXEC core.fn_dropifexists 'transformrun', 'dataintegration', 'CONSTRAINT', 'FK_TransformRun_JobId';
EXEC core.fn_dropifexists 'transformrun', 'dataintegration', 'INDEX', 'IDX_TransformRun_JobId';
ALTER TABLE dataintegration.TransformRun DROP COLUMN JobId;
GO

ALTER TABLE dataintegration.TransformRun ADD JobId INT NULL;
GO

ALTER TABLE dataintegration.TransformRun ADD CONSTRAINT FK_TransformRun_JobId FOREIGN KEY (JobId) REFERENCES pipeline.StatusFiles (RowId);
CREATE INDEX IDX_TransformRun_JobId ON dataintegration.TransformRun(JobId);
GO

ALTER TABLE dataintegration.TransformRun ADD TransformRunLog NTEXT;
GO