/*
 * Copyright (c) 2017-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
/* dataintegration-15.20-15.21.sql */

ALTER TABLE dataintegration.TransformConfiguration DROP CONSTRAINT UQ_TransformConfiguration_TransformId;
ALTER TABLE dataintegration.TransformConfiguration ALTER COLUMN TransformId nvarchar(100) NOT NULL;
ALTER TABLE dataintegration.TransformConfiguration ADD CONSTRAINT UQ_TransformConfiguration_TransformId UNIQUE (Container, TransformId);

/* dataintegration-15.21-15.22.sql */

ALTER TABLE dataintegration.TransformRun DROP CONSTRAINT FK_TransformRun_ExpRunId;
ALTER TABLE dataintegration.TransformRun DROP COLUMN ExpRunId;