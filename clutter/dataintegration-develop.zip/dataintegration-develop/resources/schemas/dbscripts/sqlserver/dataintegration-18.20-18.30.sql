/*
 * Copyright (c) 2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
CREATE NONCLUSTERED INDEX IX_TransformRun_Container_TransformId_StartTime_Status_JobId ON dataintegration.TransformRun
(
Container ASC,
TransformId ASC,
StartTime DESC,
Status ASC
)
INCLUDE (JobId);

CREATE NONCLUSTERED INDEX IX_TransformRun_Container_TransformId_StartTime_EndTime_JobId ON dataintegration.TransformRun
(
Container ASC,
TransformId ASC,
StartTime DESC
)
INCLUDE (EndTime, JobId)
WHERE (EndTime IS NOT NULL);