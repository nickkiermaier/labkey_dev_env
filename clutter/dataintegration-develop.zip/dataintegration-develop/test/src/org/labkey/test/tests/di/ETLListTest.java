/*
 * Copyright (c) 2018-2019 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.test.tests.di;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.labkey.test.BaseWebDriverTest;
import org.labkey.test.Locator;
import org.labkey.test.TestFileUtils;
import org.labkey.test.TestTimeoutException;
import org.labkey.test.categories.ETL;
import org.labkey.test.categories.Git;
import org.labkey.test.util.DataRegionTable;
import org.labkey.test.util.Maps;
import org.labkey.test.util.di.DataIntegrationHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

@Category({Git.class, ETL.class})
@BaseWebDriverTest.ClassTimeout(minutes = 5)
public class ETLListTest extends BaseWebDriverTest
{
    DataIntegrationHelper _etlHelper = new DataIntegrationHelper(getProjectName());
    private static final String ETL_LIST_MERGE = "{ETLtest}/ListAToListB";
    private static final String ETL_AUTO_INCR_LIST_TRUNCATE = "{ETLtest}/AutoIncrementListAToListB_truncate";
    // TODO: revert to ETL_ListAListB.lists.zip when 24725 is resolved. Delete xETL_ListAListB.lists.zip
    private static final File ETL_LIST_ARCHIVE = TestFileUtils.getSampleData("lists/xETL_ListAListB.lists.zip");
    private static final File ETL_AUTO_INCR_LIST_ARCHIVE = TestFileUtils.getSampleData("lists/ETL_AutoIncrListA_AutoIncrListB.lists.zip");
    private static final String SRC_LIST = "ListA";
    private static final String DEST_LIST = "ListB";
    private static final String AUTO_INCR_SRC_LIST = "AutoIncrementListA";
    private static final String AUTO_INCR_DEST_LIST = "AutoIncrementListB";


    @Override
    protected void doCleanup(boolean afterTest) throws TestTimeoutException
    {
        super.doCleanup(afterTest);
    }

    @BeforeClass
    public static void setupProject()
    {
        ETLListTest init = (ETLListTest) getCurrentTest();

        init.doSetup();
    }

    private void doSetup()
    {
        _containerHelper.createProject(getProjectName(), null);
        _containerHelper.enableModules(Arrays.asList("DataIntegration", "ETLtest"));
    }

    @Before
    public void preTest()
    {
        goToProjectHome();
        _listHelper.importListArchive(ETL_LIST_ARCHIVE);
        goToProjectHome();
        _listHelper.importListArchive(ETL_AUTO_INCR_LIST_ARCHIVE);
    }

    @Test
    public void testMergeEtl() throws Exception
    {
        List<String> expectedKeys = new ArrayList<>(Arrays.asList("K1", "K3"));
        _etlHelper.runTransform(ETL_LIST_MERGE);

        clickAndWait(Locator.linkWithText(DEST_LIST));
        DataRegionTable dest = new DataRegionTable("query", this);
        List<String> actualKeys = dest.getColumnDataAsText("Key");
        assertEquals("Initial list copy failed", expectedKeys, actualKeys);

        goBack();
        clickAndWait(Locator.linkWithText(SRC_LIST));
        // TODO: switch back to "Key" when 24725 is resolved
        Map<String, String> newSourceRow = Maps.of("xKey", "K4", "Field1", "new");
        _listHelper.insertNewRow(newSourceRow);
        _etlHelper.runTransform(ETL_LIST_MERGE);
        expectedKeys.add("K4");

        goToManageLists();
        clickAndWait(Locator.linkWithText(DEST_LIST));
        dest = new DataRegionTable("query", this);
        actualKeys = dest.getColumnDataAsText("Key");
        Map<String, String> destRow = new LinkedHashMap<>(newSourceRow);
        assertEquals("List merge failed", expectedKeys, actualKeys);

        // Test the fix for Issue 35714, merge overwrites target fields that aren't in source
        // Set value for a field only in target
        destRow.put("TargetOnlyField", "targetValue");
        dest.updateRow("K4", destRow);

        // Update a field in the the source
        goToManageLists();
        clickAndWait(Locator.linkWithText(SRC_LIST));
        DataRegionTable src = new DataRegionTable("query", this);
        Map<String, String> updatedSrcRow = new LinkedHashMap<>(newSourceRow);
        updatedSrcRow.put("Field1", "updatedSrcValue");
        src.updateRow("K4", updatedSrcRow);

        // Run the ETL
        _etlHelper.runTransform(ETL_LIST_MERGE);
        goToManageLists();
        clickAndWait(Locator.linkWithText(DEST_LIST));
        dest = new DataRegionTable("query", this);
        destRow.put("Field1", "updatedSrcValue");
        // Result should be row should have the updated field merged from source, but also still the value in the target-only field
        assertEquals("List merge preserving addditional target field failed", destRow, dest.getRowDataAsMap("xKey", "K4"));
    }

    @Test
    public void testAutoIncrTruncateEtl() throws Exception
    {
        List<String> expectedRows = new ArrayList<>(Arrays.asList("Row1", "Row2"));
        _etlHelper.runTransform(ETL_AUTO_INCR_LIST_TRUNCATE);

        clickAndWait(Locator.linkWithText(AUTO_INCR_DEST_LIST));
        DataRegionTable dest = new DataRegionTable("query", this);
        List<String> actualRows = dest.getColumnDataAsText("Field1");
        assertEquals("Initial list copy failed", expectedRows, actualRows);

        goBack();
        clickAndWait(Locator.linkWithText(AUTO_INCR_SRC_LIST));
        _listHelper.insertNewRow(Maps.of("Field1", "new"));
        _etlHelper.runTransform(ETL_AUTO_INCR_LIST_TRUNCATE);
        expectedRows.add("new");

        goToManageLists();
        clickAndWait(Locator.linkWithText(AUTO_INCR_DEST_LIST));
        dest = new DataRegionTable("query", this);
        actualRows = dest.getColumnDataAsText("Field1");
        assertEquals("Second list copy failed", expectedRows, actualRows);
    }

    @Override
    protected BrowserType bestBrowser()
    {
        return BrowserType.CHROME;
    }

    @Override
    protected String getProjectName()
    {
        return "ETLListTest Project";
    }

    @Override
    public List<String> getAssociatedModules()
    {
        return Arrays.asList("DataIntegration");
    }
}