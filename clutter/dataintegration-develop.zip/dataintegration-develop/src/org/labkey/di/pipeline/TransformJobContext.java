/*
 * Copyright (c) 2013-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.pipeline;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.labkey.api.data.Container;
import org.labkey.api.data.ParameterDescription;
import org.labkey.api.di.ScheduledPipelineJobContext;
import org.labkey.api.di.ScheduledPipelineJobDescriptor;
import org.labkey.api.pipeline.ObjectKeySerialization;
import org.labkey.api.pipeline.PipelineJob;
import org.labkey.api.security.User;
import org.labkey.api.util.Pair;
import org.labkey.api.writer.ContainerUser;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * User: jeckels
 * Date: 3/13/13
 */
public class TransformJobContext extends ScheduledPipelineJobContext implements ContainerUser, Serializable
{
    private String _transformId;
    private int _version;
    private PipelineJob _pipelineJob;
    @JsonSerialize(keyUsing = ObjectKeySerialization.Serializer.class)
    @JsonDeserialize(keyUsing = ObjectKeySerialization.Deserializer.class)
    private Map<ParameterDescription, Object> _params =  new LinkedHashMap<>();
    private Pair<Object, Object> _incrementalWindow = null;

    // No-args constructor to support de-serialization in Java 7
    @SuppressWarnings({"UnusedDeclaration"})
    public TransformJobContext()
    {
    }

    public TransformJobContext(ScheduledPipelineJobDescriptor descriptor, Container container, User user, Map<ParameterDescription, Object> params)
    {
        super(descriptor, container, user);
        _transformId = descriptor.getId();
        _version = descriptor.getVersion();
        if (null != params)
            _params.putAll(params);
    }

    public String getTransformId()
    {
        return _transformId;
    }

    public int getTransformVersion()
    {
        return _version;
    }

    public @Nullable PipelineJob getPipelineJob()
    {
        return _pipelineJob;
    }

    public void setPipelineJob(@NotNull PipelineJob job)
    {
        if (_locked)
            throw new IllegalStateException("Context is read-only");
        if (null != _pipelineJob && _pipelineJob != job)
            throw new IllegalStateException("Context is already associated with a pipeline job");
        _pipelineJob = job;
    }

    @Override
    public TransformJobContext clone()
    {
        return (TransformJobContext)super.clone();
    }

    public Map<ParameterDescription, Object> getParams()
    {
        return _params;
    }

    /** An explicit set of min/max incremental filter values, overriding any persisted values from previous runs.
     *  Setting these values in the UI is only available in dev mode, and is intended to be used for testing
     *  purposes only.
     */
    public Pair<Object, Object> getIncrementalWindow()
    {
        return _incrementalWindow;
    }

    public void setIncrementalWindow(Pair<Object, Object> incrementalWindow)
    {
        _incrementalWindow = incrementalWindow;
    }
}
