/*
 * Copyright (c) 2013-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.pipeline;

import org.labkey.api.data.SQLFragment;
import org.labkey.api.data.SqlExecutor;
import org.labkey.api.pipeline.PipeRoot;
import org.labkey.api.pipeline.PipelineDirectory;
import org.labkey.api.pipeline.PipelineProvider;
import org.labkey.api.pipeline.PipelineStatusFile;
import org.labkey.api.security.User;
import org.labkey.api.view.ViewContext;
import org.labkey.di.DataIntegrationQuerySchema;
import org.labkey.di.DataIntegrationModule;

/**
 * User: jeckels
 * Date: 2/20/13
 */
public class ETLPipelineProvider extends PipelineProvider
{
    public static final String NAME = "ETL";

    public ETLPipelineProvider(DataIntegrationModule module)
    {
        super(NAME, module);
    }

    @Override
    public void preDeleteStatusFile(User user, PipelineStatusFile sf)
    {
        // Delete the our own records that point to the pipeline job record
        SQLFragment sql = new SQLFragment("DELETE FROM dataintegration.transformrun WHERE JobId = ?", sf.getRowId());
        new SqlExecutor(DataIntegrationQuerySchema.getSchema()).execute(sql);
    }

    @Override
    public void updateFileProperties(ViewContext context, PipeRoot pr, PipelineDirectory directory, boolean includeAll)
    {

    }
}
