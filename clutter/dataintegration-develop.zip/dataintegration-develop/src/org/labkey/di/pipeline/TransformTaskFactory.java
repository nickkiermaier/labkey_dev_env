/*
 * Copyright (c) 2013-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.pipeline;

import org.labkey.api.pipeline.AbstractTaskFactory;
import org.labkey.api.pipeline.AbstractTaskFactorySettings;
import org.labkey.api.pipeline.PipelineJob;
import org.labkey.api.pipeline.TaskId;
import org.labkey.api.util.FileType;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * User: daxh
 * Date: 4/17/13
 */
public class TransformTaskFactory extends AbstractTaskFactory<AbstractTaskFactorySettings, TransformTaskFactory>
{
    public TransformTaskFactory()
    {
        super(TransformTaskFactory.class);
    }

    public TransformTaskFactory(Class namespaceClass)
    {
        super(namespaceClass);
    }

    public TransformTaskFactory(Class namespaceClass, String id)
    {
        super(namespaceClass, id);
    }

    public TransformTaskFactory(TaskId id)
    {
        super(id);
    }

    public PipelineJob.Task createTask(PipelineJob pjob)
    {
        TransformPipelineJob job = (TransformPipelineJob)pjob;
        TransformJobSupport support = job.getJobSupport(TransformJobSupport.class);
        TransformDescriptor etl = support.getTransformDescriptor();
        TransformJobContext ctx = support.getTransformJobContext();
        return etl.createTask(this, job, ctx, 0);
    }

    public List<FileType> getInputTypes()
    {
        return Collections.emptyList();
    }

    public String getStatusName()
    {
        return "ETL " + getId().getName();
    }

    public boolean isJobComplete(PipelineJob job)
    {
        return false;
    }

    public List<String> getProtocolActionNames()
    {
        return Arrays.asList(getId().getName());
    }
}
