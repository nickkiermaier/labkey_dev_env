/*
 * Copyright (c) 2013-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.pipeline;

import org.jetbrains.annotations.NotNull;

/**
 * User: dax
 * Date: 4/16/13
 */
public interface TransformJobSupport
{
    TransformDescriptor getTransformDescriptor();
    @NotNull
    TransformJobContext getTransformJobContext();
}
