/*
 * Copyright (c) 2013-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.steps;

import org.apache.xmlbeans.XmlException;
import org.labkey.di.pipeline.TransformManager;
import org.labkey.etl.xml.SourceObjectType;
import org.labkey.etl.xml.TransformType;

/**
 * User: gktaylor
 * Date: 2013-10-08
 *
 * Metadata for a remote query transform
 */
public class RemoteQueryTransformStepMeta extends SimpleQueryTransformStepMeta
{
    String remoteSource;

    protected void parseSource(TransformType transformXML) throws XmlException
    {
        SourceObjectType source = transformXML.getSource();

        if (null != source)
        {
            super.parseSource(transformXML);
            setRemoteSource(source.getRemoteSource());
        }
        else throw new XmlException(TransformManager.INVALID_SOURCE);
    }

    public String getRemoteSource()
    {
        return remoteSource;
    }

    public void setRemoteSource(String remoteSource)
    {
        this.remoteSource = remoteSource;
    }
}
