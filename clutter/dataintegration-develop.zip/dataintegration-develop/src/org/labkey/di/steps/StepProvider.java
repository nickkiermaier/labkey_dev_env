/*
 * Copyright (c) 2013-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.steps;

import org.labkey.api.pipeline.PipelineJob;
import org.labkey.di.pipeline.TransformJobContext;
import org.labkey.di.pipeline.TransformTask;
import org.labkey.di.pipeline.TransformTaskFactory;

import java.util.List;
import java.util.Map;

/**
 * User: tgaluhn
 * Date: 10/9/13
 */
public interface StepProvider
{
    /**
     * The preferred type name. Used in the transform type attribute
     * @return The name
     */
    String getName();

    /**
     *  Optional list of alternate names for the type
     *  For example, SimpleQueryTransformStep is the default for a blank (null) value,
     *  and in the initial rollout we were using fully qualified class names
     * @return  List of alternate names
     */
    List<String> getLegacyNames();

    /**
     *  The class for the Step
     * @return The .class
     */
    Class getStepClass();

    /**
     * Instantiate the correct StepMeta subclass
     * @return An instance of the StepMeta corresponding to the type
     */
    StepMeta createMetaInstance();

    /**
     * Instantiate the correct Step subclass.
     * @param f The factory
     * @param job The current job
     * @param meta Should be cast to the correct StepMeta subclass in the constructor call
     * @param context Job context passed into the step
     * @return An instance of the Step class corresponding to the type
     */
    TransformTask createStepInstance(TransformTaskFactory f, PipelineJob job, StepMeta meta, TransformJobContext context);

    Map<String, StepProvider> getNameProviderMap();
}
