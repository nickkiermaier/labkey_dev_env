/*
 * Copyright (c) 2013-2019 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.steps;

import org.apache.log4j.Logger;
import org.jetbrains.annotations.Nullable;
import org.junit.Assert;
import org.junit.Test;
import org.labkey.api.data.ColumnInfo;
import org.labkey.api.data.Container;
import org.labkey.api.data.ContainerManager;
import org.labkey.api.data.DbScope;
import org.labkey.api.data.JdbcType;
import org.labkey.api.dataiterator.CopyConfig;
import org.labkey.api.dataiterator.DataIterator;
import org.labkey.api.dataiterator.DataIteratorBuilder;
import org.labkey.api.dataiterator.DataIteratorContext;
import org.labkey.api.di.DataIntegrationService;
import org.labkey.api.pipeline.PipelineJob;
import org.labkey.api.query.QuerySchema;
import org.labkey.api.security.User;
import org.labkey.api.settings.AppProps;
import org.labkey.api.util.ConfigurationException;
import org.labkey.di.filters.FilterStrategy;
import org.labkey.di.filters.ModifiedSinceFilterStrategy;
import org.labkey.di.pipeline.TransformDescriptor;
import org.labkey.di.pipeline.TransformJobContext;
import org.labkey.di.pipeline.TransformPipelineJob;
import org.labkey.di.pipeline.TransformTaskFactory;
import org.labkey.remoteapi.CommandException;
import org.labkey.remoteapi.Connection;
import org.labkey.remoteapi.GuestCredentialsProvider;
import org.labkey.remoteapi.SelectRowsStreamHack;
import org.labkey.remoteapi.query.ContainerFilter;
import org.labkey.remoteapi.query.Filter;
import org.labkey.remoteapi.query.SelectRowsCommand;
import org.labkey.remoteapi.query.Sort;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * User: gktaylor
 * Date: 2013-10-08
 */
public class RemoteQueryTransformStep extends SimpleQueryTransformStep
{
    private static final Logger LOG = Logger.getLogger(RemoteQueryTransformStep.class);

    public RemoteQueryTransformStep(TransformTaskFactory f, PipelineJob job, SimpleQueryTransformStepMeta meta, TransformJobContext context)
    {
        super(f, job, meta, context);
        _validateSource = false;
    }

    @Override
    public boolean hasWork()
    {
        FilterStrategy filterStrategy = getFilterStrategy();
        RemoteQueryTransformStepMeta meta = (RemoteQueryTransformStepMeta) _meta;
        DataIntegrationService.RemoteConnection connection = DataIntegrationService.get().getRemoteConnection(meta.getRemoteSource(), _context.getContainer(), LOG);

        if (null != connection && filterStrategy instanceof ModifiedSinceFilterStrategy)
        {
            try
            {
                return remoteSourceHasWork((ModifiedSinceFilterStrategy) filterStrategy, meta, connection);
            }
            catch (IOException | CommandException e)
            {
                LOG.error("Error while checking for work in remote source for schema '" + meta.getSourceSchema() +
                        "', and query '" + meta.getSourceQuery() + "' in Folder '" + (null != _context.getContainer() ? _context.getContainer().getPath() : "") + "'.", e);
                return false;
            }
        }
        else
            return !isEtlGatedByStep();
    }

    private boolean remoteSourceHasWork(ModifiedSinceFilterStrategy fs, RemoteQueryTransformStepMeta meta, DataIntegrationService.RemoteConnection connection) throws IOException, CommandException
    {
        String timestampColumnName = getTimestampColumnName(meta);

        // Pass in named query parameters
        Map<String, String> parameters = new HashMap<>();

        if (this._context.getJobDescriptor() instanceof TransformDescriptor)
        {
            ((TransformDescriptor)this._context.getJobDescriptor()).getDeclaredVariables().forEach((pd, o) -> parameters.put(pd.getName(), o.toString()));
        }

        //get max timestamp from remote source
        Object maxTimestamp = getMaxTimeStamp(meta, timestampColumnName, connection, parameters, _context.getContainer());

        //get endtimestamp from dataintegration.transformconfiguration.status
        Object incrementalEndTimestamp = fs.getLastSuccessfulIncrementalEndTimestampJson(false);

        return (null == incrementalEndTimestamp || null == maxTimestamp || ((Comparable)incrementalEndTimestamp).compareTo(maxTimestamp) < 0); //use comparable, since these "timestamp" columns are not always necessarily datetime.
    }

    private String getTimestampColumnName(RemoteQueryTransformStepMeta meta)
    {
        String timestampColumnName;
        if (getFilterStrategy() instanceof ModifiedSinceFilterStrategy)
        {
            //getDefaultTimestampColumnName() returns timestampColumnName value from <incrementalFilter>
            String defaultTimestampColumnName = ((ModifiedSinceFilterStrategy) getFilterStrategy()).getDefaultTimestampColumnName();

            //getSourceTimestampColumnName() returns timestampColumnName value from <source>
            timestampColumnName = (null == meta.getSourceTimestampColumnName() ? defaultTimestampColumnName : meta.getSourceTimestampColumnName());
        }
        else
        {
            timestampColumnName = meta.getSourceTimestampColumnName();
        }
        return timestampColumnName;
    }

    @Override
    protected DbScope getSourceScope(QuerySchema sourceSchema, DbScope targetScope)
    {
        // there is no source scope for a remote query
        return null;
    }

    @Override
    protected DataIteratorBuilder selectFromSource(CopyConfig meta, Container c, User u, DataIteratorContext context, Logger log)
    {
        // find the category to look up in the property manager, provided by the .xml
        if (! (meta instanceof RemoteQueryTransformStepMeta) )
            throw new UnsupportedOperationException("This xml parser was expected an instance of RemoteQueryTransformStepMeta");
        String name = ((RemoteQueryTransformStepMeta)meta).getRemoteSource();
        if (name == null)
        {
            log.error("The remoteSource option provided in the xml must refer to a Remote Connection.");
            return null;
        }

        String timestampColumnName = getTimestampColumnName((RemoteQueryTransformStepMeta)meta);

        DataIntegrationService.RemoteConnection connection = DataIntegrationService.get().getRemoteConnection(name, c, log);
        if (connection == null)
        {
            return null;
        }
        // Pass in named query parameters
        Map<String, String> parameters = new HashMap<>();
        ((TransformPipelineJob) getJob()).getTransformDescriptor().getDeclaredVariables().forEach((pd, o) -> parameters.put(pd.getName(), o.toString()));

        try
        {
            Object incrementalStartTimestamp = null;
            Object incrementalEndTimestamp = null;
            List<Filter> filters = null;

            if (getFilterStrategy() instanceof  ModifiedSinceFilterStrategy)
            {
                boolean useOverrideWindow = null != _context.getIncrementalWindow();
                ModifiedSinceFilterStrategy mfs = (ModifiedSinceFilterStrategy) getFilterStrategy();

                //get incrementalStartTimestamp from dataintegration.transformConfiguration.status (which is previous ETL run's incrementalEndTimestamp)
                incrementalStartTimestamp = useOverrideWindow ? _context.getIncrementalWindow().first : mfs.getLastSuccessfulIncrementalEndTimestampJson(false);

                //get max timestamp from remote source
                incrementalEndTimestamp = getMaxTimeStamp(meta, timestampColumnName, connection, parameters, getJob().getContainer());

                //save to dataintegration.transformConfiguration.status
                getVariableMap().put(ModifiedSinceFilterStrategy.FilterTimestamp.START.getPropertyDescriptor(false, false), incrementalStartTimestamp);
                if (incrementalEndTimestamp == null || incrementalEndTimestamp instanceof Date || incrementalEndTimestamp instanceof Number)
                    getVariableMap().put(ModifiedSinceFilterStrategy.FilterTimestamp.END.getPropertyDescriptor(false, false), incrementalEndTimestamp);
                else
                {
                    String legalTypes = "\nLegal types are date, time, datetime, timestamp, rowversion, and integer.\nText fields will pass the datatype check but immediately fail on the cast attempt.";
                    throw new ConfigurationException("Timestamp column '"+ timestampColumnName+"' contains value not castable to a legal type: " + incrementalEndTimestamp.toString() + legalTypes);
                }
                //create filters based on timestamps
                if (null != timestampColumnName)
                {
                    filters = new LinkedList<>();

                    if (null != incrementalStartTimestamp)
                        filters.add(new Filter(timestampColumnName, incrementalStartTimestamp, Filter.Operator.GT));
                    if (null != incrementalEndTimestamp)
                        filters.add(new Filter(timestampColumnName, incrementalEndTimestamp, Filter.Operator.LTE));
                }
            }

            return selectFromSource(connection.connection, meta.getSourceSchema().toString(), meta.getSourceQuery(),
                    connection.remoteContainer, meta.getSourceColumns(), parameters, meta.getSourceTimeout(),
                    filters, meta.getSourceContainerFilter(), null, null, c);
        }
        catch (IOException | CommandException exception)
        {
            log.error(exception.getMessage());
            return null;
        }
    }

    private Object getMaxTimeStamp(CopyConfig meta, String timestampColumnName, DataIntegrationService.RemoteConnection connection,
                                   Map<String, String> parameters, Container targetContainer) throws IOException, CommandException
    {

        //get ALL columns (esp. since "special" columns such as modified, created, etc. fails to come through otherwise)
        List<String> srcCols = Arrays.asList("*");

        //get end timestamp from remote source
        DataIteratorBuilder dib = selectFromSource(connection.connection,
                meta.getSourceSchema().toString(),
                meta.getSourceQuery(),
                connection.remoteContainer,
                srcCols,
                parameters,
                meta.getSourceTimeout(),
                null,
                meta.getSourceContainerFilter(),
                timestampColumnName,
                1,
                targetContainer);

        DataIterator dataIterator = dib.getDataIterator(new DataIteratorContext());

        if (null != dataIterator)
        {
            List<Map<String, Object>> collectedData = dataIterator.stream().collect(Collectors.toList());

            if (null != collectedData && collectedData.size() > 0)
            {
                //above selectFromSource() call should return 1 row with max/latest timestamp if there are rows in source.
                Map<String, Object> maxTimestampRow = collectedData.get(0);

                Object tsCol = maxTimestampRow.get(timestampColumnName);

                if (null == tsCol)
                {
                    throw new CommandException("timestamp column '" + timestampColumnName + "' not found in source query " + meta.getSourceQuery());
                }

                if (tsCol instanceof Date)
                    return JdbcType.TIMESTAMP.convert(tsCol);
                else if (tsCol instanceof Number)
                    return JdbcType.INTEGER.convert(tsCol);
            }
        }

        return null;
    }

    // Version that connects as guest; for testing purposes only
    private static DataIteratorBuilder selectFromSource(String schemaName, String queryName, String url, String container, Container targetContainer)
            throws IOException, CommandException
    {
        return selectFromSource(new Connection(url, new GuestCredentialsProvider()), schemaName, queryName, container, null, Collections.emptyMap(), null, null, null, null, null, targetContainer);
    }

    private static DataIteratorBuilder selectFromSource(Connection cn, String schemaName, String queryName,
                                                        String container, @Nullable List<String> columns,
                                                        Map<String, String> parameters, @Nullable Integer timeout,
                                                        @Nullable List<Filter> filters, @Nullable String cf,
                                                        @Nullable String sortOnColumn, @Nullable Integer maxRow,
                                                        Container targetContainer)
            throws IOException, CommandException
    {
        // connect to the remote server and retrieve an input stream
        final SelectRowsCommand cmd = new SelectRowsCommand(schemaName, queryName);

        if (sortOnColumn != null)
            cmd.addSort(sortOnColumn, Sort.Direction.DESCENDING);

        if (maxRow != null)
            cmd.setMaxRows(maxRow);

        if (filters != null)
            cmd.setFilters(filters);

        if (timeout != null)
            cmd.setTimeout(timeout);

        if (columns != null)
        {
            cmd.setColumns(columns);
        }
        if (!parameters.isEmpty())
        {
            cmd.setQueryParameters(parameters);
        }
        if (cf != null)
        {
            cmd.setContainerFilter(ContainerFilter.valueOf(cf));
        }

        return SelectRowsStreamHack.go(cn, container, cmd, targetContainer);
    }

    public static class TestCase extends Assert
    {
        @Test
        public void selectRows() throws Exception
        {
            // Execute a 'remote' query against the currently running server.
            // We use the home container since we won't need to authenticate the user.
            String url = AppProps.getInstance().getBaseServerUrl() + AppProps.getInstance().getContextPath();
            Container home = ContainerManager.getHomeContainer();
            DataIteratorBuilder b = selectFromSource("core", "Containers", url, home.getPath(), home);

            DataIteratorContext context = new DataIteratorContext();
            try (DataIterator iter = b.getDataIterator(context))
            {
                if(context.getErrors().hasErrors())
                {
                    throw context.getErrors();
                }
                int idxEntityId = -1;
                int idxID = -1;
                int idxName = -1;
                int idxCreated = -1;
                int idxType = -1;

                for (int i = 1; i <= iter.getColumnCount(); i++)
                {
                    ColumnInfo col = iter.getColumnInfo(i);
                    switch (col.getName())
                    {
                        case "EntityId": idxEntityId = i; break;
                        case "ID":       idxID = i;       break;
                        case "Name":     idxName = i;     break;
                        case "Created":  idxCreated = i;  break;
                        case "Type":     idxType = i;     break;
                    }
                }

                assertTrue("Expected to find EntityId column: " + idxEntityId, idxEntityId > 0);
                assertTrue("Expected to find ID column: " + idxID, idxID > 0);
                assertTrue("Expected to find Name column: " + idxName, idxName > 0);
                assertTrue("Expected to find Created column: " + idxCreated, idxCreated > 0);

                assertTrue("Expected to select a single row for the Home container.", iter.next());

                // Check the select rows returns the Home container details
                assertEquals(home.getId(), iter.get(idxEntityId));
                assertTrue(iter.get(idxEntityId) instanceof String);

                assertEquals(home.getRowId(), iter.get(idxID));
                assertTrue(iter.get(idxID) instanceof Integer);

                assertEquals(home.getName(), iter.get(idxName));
                assertTrue(iter.get(idxName) instanceof String);

                assertTrue(iter.get(idxCreated) instanceof Date);
                // The remoteapi Date doesn't have milliseconds so the Dates won't be equal -- just compare day instead.
                assertEquals(home.getCreated().getDay(), ((Date)iter.get(idxCreated)).getDay());

                // We expect any other rows to be workbooks
                while (iter.next())
                    assertTrue("workbook".equals(iter.get(idxType)));
            }
        }
    }
}