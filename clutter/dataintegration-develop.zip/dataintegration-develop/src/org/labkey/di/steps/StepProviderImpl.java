/*
 * Copyright (c) 2014-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.steps;

import java.util.HashMap;
import java.util.Map;

/**
 * User: tgaluhn
 * Date: 8/7/2014
 */
public abstract class StepProviderImpl implements StepProvider
{
    @Override
    public Map<String, StepProvider> getNameProviderMap()
    {
        Map<String, StepProvider> map = new HashMap<>();
        map.put(getName(), this);
        for (String legacyName : getLegacyNames())
        {
            map.put(legacyName, this);
        }

        return map;
    }
}
