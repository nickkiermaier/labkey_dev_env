/*
 * Copyright (c) 2013-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.steps;

import org.labkey.api.pipeline.PipelineJob;
import org.labkey.di.pipeline.TransformJobContext;
import org.labkey.di.pipeline.TransformTask;
import org.labkey.di.pipeline.TransformTaskFactory;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * User: gktaylor
 * Date: 10/10/13
 */
public class RemoteQueryTransformStepProvider extends StepProviderImpl
{
    @Override
    public String getName()
    {
        return "Remote";
    }

    @Override
    public List<String> getLegacyNames()
    {
        return Collections.unmodifiableList(Arrays.asList("RemoteQueryTransformStep"));
    }

    @Override
    public Class getStepClass()
    {
        return RemoteQueryTransformStep.class;
    }

    @Override
    public StepMeta createMetaInstance()
    {
        return new RemoteQueryTransformStepMeta();
    }

    @Override
    public TransformTask createStepInstance(TransformTaskFactory f, PipelineJob job, StepMeta meta, TransformJobContext context)
    {
        return new RemoteQueryTransformStep(f, job, (RemoteQueryTransformStepMeta)meta, context);
    }
}
