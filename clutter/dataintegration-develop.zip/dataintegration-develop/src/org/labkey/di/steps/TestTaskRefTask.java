/*
 * Copyright (c) 2014-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.steps;

import org.jetbrains.annotations.NotNull;
import org.labkey.api.pipeline.PipelineJob;
import org.labkey.api.pipeline.PipelineJobException;
import org.labkey.api.pipeline.RecordedActionSet;
import org.labkey.api.di.TaskRefTaskImpl;

import java.util.Collections;
import java.util.List;

/**
 * User: tgaluhn
 * Date: 7/25/2014
 */
public class TestTaskRefTask extends TaskRefTaskImpl
{
    private enum Setting
    {
        setting1,
        sleep
    }

    @Override
    public RecordedActionSet run(@NotNull PipelineJob job)
    {
        settings.put(Setting.setting1.name(), "test");
        job.getLogger().info("Log from test task");
        if (settings.get(Setting.sleep.name()) != null)
        {
            int sleepSeconds = Integer.parseInt(settings.get(Setting.sleep.name()));
            job.getLogger().info("Sleeping ETL task for " + sleepSeconds + " seconds");
            try
            {
                Thread.sleep(sleepSeconds * 1000);
            }
            catch (InterruptedException e) {/* */}
        }
        return new RecordedActionSet(makeRecordedAction());
    }

    @Override
    public List<String> getRequiredSettings()
    {
        return Collections.singletonList(Setting.setting1.name());
    }
}
