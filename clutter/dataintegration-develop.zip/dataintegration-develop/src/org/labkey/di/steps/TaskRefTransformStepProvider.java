/*
 * Copyright (c) 2014-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.steps;

import org.labkey.api.pipeline.PipelineJob;
import org.labkey.di.pipeline.TransformJobContext;
import org.labkey.di.pipeline.TransformTask;
import org.labkey.di.pipeline.TransformTaskFactory;

import java.util.Collections;
import java.util.List;

/**
 * User: tgaluhn
 * Date: 7/21/2014
 */
public class TaskRefTransformStepProvider extends StepProviderImpl
{
    @Override
    public String getName()
    {
        return TaskRefTransformStep.class.getSimpleName();
    }

    @Override
    public List<String> getLegacyNames()
    {
        return Collections.emptyList();
    }

    @Override
    public Class getStepClass()
    {
        return TaskRefTransformStep.class;
    }

    @Override
    public StepMeta createMetaInstance()
    {
        return new TaskRefTransformStepMeta();
    }

    @Override
    public TransformTask createStepInstance(TransformTaskFactory f, PipelineJob job, StepMeta meta, TransformJobContext context)
    {
        return new TaskRefTransformStep(f, job, (TaskRefTransformStepMeta)meta, context);
    }
}
