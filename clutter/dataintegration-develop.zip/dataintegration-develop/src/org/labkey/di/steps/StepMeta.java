/*
 * Copyright (c) 2013-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.steps;

import org.apache.xmlbeans.XmlException;
import org.labkey.api.data.ParameterDescription;
import org.labkey.api.di.columnTransform.ColumnTransform;
import org.labkey.api.query.SchemaKey;
import org.labkey.etl.xml.TransformType;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * User: matthew
 * Date: 4/22/13
 * Time: 11:58 AM
 */
public interface StepMeta
{
    StepProvider getProvider();

    void setProvider(StepProvider provider);

    String getDescription();

    void setDescription(String description);

    String getId();

    void setId(String id);

    SchemaKey getSourceSchema();

    String getSourceQuery();

    SchemaKey getTargetSchema();

    String getTargetQuery();

    void parseConfig(TransformType transformXML) throws XmlException;

    boolean isUseSource();

    boolean isUseTarget();

    boolean isUseTargetTransaction();

    int getBatchSize();

    boolean isGating();

    boolean isSaveState();

    Map<String, List<ColumnTransform>> getColumnTransforms();

    Map<ParameterDescription, Object> getConstants();

    void putConstants(Map<ParameterDescription, Object> constants);

    void setEtlName(String etlName);

    Set<String> getAlternateKeys();
}
