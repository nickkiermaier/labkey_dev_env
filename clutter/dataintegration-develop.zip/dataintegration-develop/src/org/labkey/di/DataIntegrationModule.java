/*
 * Copyright (c) 2013-2019 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */

package org.labkey.di;

import org.jetbrains.annotations.NotNull;
import org.labkey.api.admin.FolderSerializationRegistry;
import org.labkey.api.data.Container;
import org.labkey.api.data.ContainerManager;
import org.labkey.api.data.ContainerManager.ContainerListener;
import org.labkey.api.data.DbSchema;
import org.labkey.api.data.DbScope;
import org.labkey.api.data.SqlSelector;
import org.labkey.api.di.DataIntegrationService;
import org.labkey.api.module.DefaultModule;
import org.labkey.api.module.ModuleContext;
import org.labkey.api.pipeline.PipelineService;
import org.labkey.api.security.User;
import org.labkey.api.usageMetrics.UsageMetricsService;
import org.labkey.api.util.ContainerUtil;
import org.labkey.api.util.ContextListener;
import org.labkey.api.util.StartupListener;
import org.labkey.api.util.UsageReportingLevel;
import org.labkey.api.view.BaseWebPartFactory;
import org.labkey.api.view.FolderManagement;
import org.labkey.api.view.JspView;
import org.labkey.api.view.Portal;
import org.labkey.api.view.SimpleWebPartFactory;
import org.labkey.api.view.ViewContext;
import org.labkey.api.view.WebPartFactory;
import org.labkey.api.view.WebPartView;
import org.labkey.di.data.TransformDataType;
import org.labkey.di.data.TransformProperty;
import org.labkey.di.pipeline.ETLPipelineProvider;
import org.labkey.di.pipeline.TransformDescriptor;
import org.labkey.di.pipeline.TransformManager;
import org.labkey.di.pipeline.TransformPipelineJob;
import org.labkey.di.steps.RemoteQueryTransformStep;
import org.labkey.di.view.DataIntegrationController;
import org.labkey.di.view.ProcessJobsView;

import javax.servlet.ServletContext;
import java.beans.PropertyChangeEvent;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * User: matthewb
 * Date: 12 Jan 2013
 */
public class DataIntegrationModule extends DefaultModule implements ContainerListener
{
    static final String NAME = "DataIntegration";

    @Override
    public String getName()
    {
        return NAME;
    }

    @Override
    public double getVersion()
    {
        return 19.30;
    }

    @Override
    protected void init()
    {
        DataIntegrationService.setInstance(TransformManager.get());
        addController("dataintegration", DataIntegrationController.class);
        TransformProperty.register();
    }

    @Override
    public boolean hasScripts()
    {
        return true;
    }


    @NotNull
    @Override
    public Set<String> getSchemaNames()
    {
        return Collections.singleton(DataIntegrationQuerySchema.SCHEMA_NAME);
    }


    @Override
    protected void doStartup(ModuleContext moduleContext)
    {
        PipelineService.get().registerPipelineProvider(new ETLPipelineProvider(this));

        ContainerManager.addContainerListener(this);
        ContextListener.addStartupListener(new StartupListener()
        {
            @Override
            public String getName()
            {
                return NAME;
            }

            @Override
            public void moduleStartupComplete(ServletContext servletContext)
            {
                TransformManager.get().startAllConfigurations();
            }
        });

        DataIntegrationQuerySchema.register(this);
        TransformDataType.register();
        DataIntegrationService.get().registerStepProviders();
        DataIntegrationController.registerAdminConsoleLinks();

        FolderSerializationRegistry folderRegistry = FolderSerializationRegistry.get();
        if (null != folderRegistry)
        {
            folderRegistry.addFactories(new DataIntegrationFolderWriter.Factory(), new DataIntegrationFolderImporter.Factory());
        }

        UsageMetricsService svc = UsageMetricsService.get();

        if (null != svc)
        {
            svc.registerUsageMetrics(UsageReportingLevel.MEDIUM, NAME, () -> {
                Map<String, Object> metric = new HashMap<>();
                metric.put("etlRunCount", new SqlSelector(DataIntegrationQuerySchema.getSchema(), "SELECT COUNT(*) FROM dataintegration.TransformRun").getObject(Long.class));
                return metric;
            });
        }

        FolderManagement.addTab(FolderManagement.TYPE.FolderManagement, "ETLs", "etls",
            container -> container.hasActiveModuleByName(NAME) && !container.isRoot(),
            DataIntegrationController.CustomTransformsAction.class);
    }


    @NotNull
    @Override
    public Set<Class> getUnitTests()
    {
        return new HashSet<>(Arrays.asList(
            TransformManager.TestCase.class,
            VariableMapImpl.TestCase.class,
            TransformDescriptor.TestCase.class
        ));
    }

    @NotNull
    @Override
    public Set<Class> getIntegrationTests()
    {
        return new HashSet<>(Arrays.asList(RemoteQueryTransformStep.TestCase.class,
                TransformPipelineJob.TestCase.class));
    }

    /** web parts **/

    @Override
    @NotNull
    protected Collection<WebPartFactory> createWebPartFactories()
    {
        return Arrays.asList(
            new SimpleWebPartFactory("Data Transforms", WebPartFactory.LOCATION_BODY, TransFormsWebPart.class, null),
            new BaseWebPartFactory("Data Transform Jobs")
            {
                @Override
                public WebPartView getWebPartView(@NotNull ViewContext portalCtx, @NotNull Portal.WebPart webPart)
                {
                    WebPartView view = new ProcessJobsView(portalCtx.getUser(), portalCtx.getContainer());
                    view.setTitle("Processed Data Transforms");
                    view.setFrame(WebPartView.FrameType.PORTAL);
                    return view;
                }
            }
        );
    }

    @SuppressWarnings("UnusedDeclaration")
    public static class TransFormsWebPart extends JspView<Object>
    {
        public TransFormsWebPart(ViewContext portalCtx)
        {
            this(portalCtx.getContainer());
        }

        TransFormsWebPart(Container c)
        {
            super("/org/labkey/di/view/transformConfiguration.jsp", null);
            setTitle("Data Transforms");
            setFrame(WebPartView.FrameType.PORTAL);
            setModelBean(this);
        }
    }

    //
    // ContainerListener
    //

    @Override
    public void containerCreated(Container c, User user)
    {
    }

    @Override
    public void containerDeleted(Container c, User user)
    {
        DbSchema di = DataIntegrationQuerySchema.getSchema();
        try (DbScope.Transaction transaction = di.getScope().ensureTransaction())
        {
            TransformManager.get().containerDeleted(c);

            ContainerUtil.purgeTable(di.getTable("TransformRun"), c, null);
            ContainerUtil.purgeTable(di.getTable("TransformConfiguration"), c, null);
            ContainerUtil.purgeTable(di.getTable("EtlDef"), c, null);
            transaction.commit();
        }
    }

    @Override
    public void containerMoved(Container c, Container oldParent, User user)
    {
    }

    @NotNull
    @Override
    public Collection<String> canMove(Container c, Container newParent, User user)
    {
        return Collections.emptyList();
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt)
    {
    }
}
