/*
 * Copyright (c) 2016-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.columnTransforms;

import org.labkey.api.di.columnTransform.ColumnTransform;

/**
 * User: tgaluhn
 * Date: 9/27/2016
 *
 * Simple class to mark a source column as to be omitted from the passthrough to target output
 */
public class OmitSourceColumn extends ColumnTransform
{
    @Override
    protected void registerOutput()
    {
        // Do Nothing
    }

    @Override
    protected Object doTransform(Object inputValue)
    {
        // This should never be called, as registerOutput() is a no-op
        throw new UnsupportedOperationException();
    }
}
