/*
 * Copyright (c) 2013-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di;

import org.labkey.api.data.ParameterDescription;

import java.util.Set;

/**
 * User: matthew
 * Date: 4/22/13
 * Time: 11:43 AM
 */
public interface VariableMap
{
    enum Scope { global, local, parent }

    Object get(String key);

    Object put(String key, Object value);
    Object put(String key, Object value, Enum scope);
    Object put(ParameterDescription p, Object value);
    Object put(ParameterDescription p, Object value, Enum scope);

    ParameterDescription getDescriptor(String key);
    Set<String> keySet();
}
