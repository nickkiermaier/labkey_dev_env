/*
 * Copyright (c) 2013-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di;

import org.labkey.api.data.Sort;
import org.labkey.api.query.QuerySettings;
import org.labkey.api.query.QueryView;
import org.labkey.api.query.UserSchema;
import org.springframework.validation.BindException;

/**
 * User: Dax
 * Date: 9/13/13
 * Time: 12:27 PM
  */
public class TransformHistoryView extends QueryView
{
    public TransformHistoryView(UserSchema schema, QuerySettings settings, BindException errors)
    {
        super(schema, settings, errors);
        settings.setBaseSort(new Sort("-DateRun"));
    }
}
