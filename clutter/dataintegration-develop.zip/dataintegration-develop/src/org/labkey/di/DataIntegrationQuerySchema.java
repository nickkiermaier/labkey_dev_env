/*
 * Copyright (c) 2013-2019 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.labkey.api.collections.CaseInsensitiveTreeSet;
import org.labkey.api.data.Container;
import org.labkey.api.data.ContainerFilter;
import org.labkey.api.data.DbSchema;
import org.labkey.api.data.DbSchemaType;
import org.labkey.api.data.SchemaTableInfo;
import org.labkey.api.data.TableInfo;
import org.labkey.api.module.Module;
import org.labkey.api.query.DefaultSchema;
import org.labkey.api.query.DetailsURL;
import org.labkey.api.query.FieldKey;
import org.labkey.api.query.FilteredTable;
import org.labkey.api.query.QuerySchema;
import org.labkey.api.query.QuerySettings;
import org.labkey.api.query.QueryView;
import org.labkey.api.query.SimpleUserSchema;
import org.labkey.api.security.User;
import org.labkey.api.security.UserPrincipal;
import org.labkey.api.security.permissions.AdminPermission;
import org.labkey.api.security.permissions.Permission;
import org.labkey.api.security.permissions.ReadPermission;
import org.labkey.api.view.ActionURL;
import org.labkey.api.view.ViewContext;
import org.labkey.di.view.DataIntegrationController;
import org.labkey.di.view.EtlDefQueryView;
import org.springframework.validation.BindException;

import java.util.Collections;
import java.util.Set;

/**
 * User: jeckels
 * Date: 3/13/13
 */
public class DataIntegrationQuerySchema extends SimpleUserSchema
{
    public static final String SCHEMA_NAME = "dataintegration";
    public static final String SCHEMA_DESCRIPTION = "Contains data for ETL Transformations";
    // list of each transform type with last run information
    public static final String TRANSFORMSUMMARY_TABLE_NAME = "TransformSummary";
    // history of a specific transform type ordered by newest run first
    public static final String TRANSFORMHISTORY_TABLE_NAME = "TransformHistory";
    // all transform runs
    public static final String TRANSFORMRUN_TABLE_NAME = "TransformRun";
    public static final String ETL_DEF_TABLE_NAME = "etlDef";

    public enum Columns
    {
        TransformRunId("diTransformRunId"),
        TransformModified("diModified"),
        TransformModifiedBy("diModifiedBy"),
        TransformRowVersion("diRowVersion"),
        TransformCreated("diCreated"),
        TransformCreatedBy("diCreatedBy");

        final String _name;

        Columns(String name)
        {
            _name = name;
        }

        public String getColumnName()
        {
            return _name;
        }
    }

    public DataIntegrationQuerySchema(User user, Container container)
    {
        super(SCHEMA_NAME, SCHEMA_DESCRIPTION, user, container, getSchema());
    }

    @Override
    public Set<String> getVisibleTableNames()
    {
        Set<String> tableNames = new CaseInsensitiveTreeSet();
        tableNames.addAll(super.getVisibleTableNames());
        addVirtualTables(tableNames);

        return Collections.unmodifiableSet(tableNames);
    }

    @Override
    public Set<String> getTableNames()
    {
        Set<String> tableNames = new CaseInsensitiveTreeSet(getDbSchema().getTableNames());
        addVirtualTables(tableNames);

        return Collections.unmodifiableSet(tableNames);
    }

    private void addVirtualTables(Set<String> tableNames)
    {
        tableNames.add(TRANSFORMHISTORY_TABLE_NAME);
        tableNames.add(TRANSFORMSUMMARY_TABLE_NAME);
    }

    @Override
    public TableInfo createTable(String name, @Nullable ContainerFilter containerFilter)
    {
        if (TRANSFORMHISTORY_TABLE_NAME.equalsIgnoreCase(name))
            return new TransformHistoryTable(this, containerFilter);

        if (TRANSFORMSUMMARY_TABLE_NAME.equalsIgnoreCase(name))
            return new TransformSummaryTable(this, containerFilter);

        if (ETL_DEF_TABLE_NAME.equalsIgnoreCase(name))
            return new EtlDefTableInfo(this, containerFilter).init();

        return getSchemaTable(name);
    }

    @Override
    public QueryView createView(ViewContext context, @NotNull QuerySettings settings, BindException errors)
    {
        if (TRANSFORMHISTORY_TABLE_NAME.equalsIgnoreCase(settings.getQueryName()))
            return new TransformHistoryView(this, settings, errors);
        else if (ETL_DEF_TABLE_NAME.equalsIgnoreCase(settings.getQueryName()))
            return new EtlDefQueryView(this, settings, errors);
        return super.createView(context, settings, errors);
    }


    private TableInfo getSchemaTable(String name)
    {
        SchemaTableInfo tinfo = getDbSchema().getTable(name);
        if (null == tinfo)
            return null;

        FilteredTable<DataIntegrationQuerySchema> ftable = new FilteredTable<>(tinfo, this);
        ftable.wrapAllColumns(true);
        return ftable;
    }

    public static void register(final DataIntegrationModule module)
    {
        DefaultSchema.registerProvider(SCHEMA_NAME, new DefaultSchema.SchemaProvider(module)
        {
            @Override
            public boolean isAvailable(DefaultSchema schema, Module module)
            {
                return true;
            }

            @Override
            public QuerySchema createSchema(DefaultSchema schema, Module module)
            {
                return new DataIntegrationQuerySchema(schema.getUser(), schema.getContainer());
            }
        });
    }

    public static DbSchema getSchema()
    {
        return DbSchema.get(SCHEMA_NAME, DbSchemaType.Module);
    }


    public static TableInfo getTransformRunTableInfo()
    {
        return getSchema().getTable("transformrun");
    }


    public static TableInfo getTransformConfigurationTableInfo()
    {
        return getSchema().getTable("transformconfiguration");
    }

    public static TableInfo getEtlDefTableInfo()
    {
        return getSchema().getTable(ETL_DEF_TABLE_NAME);
    }

    public static String getTransformRunTableName()
    {
        return SCHEMA_NAME + "." + TRANSFORMRUN_TABLE_NAME;
    }

    private class EtlDefTableInfo extends SimpleTable<DataIntegrationQuerySchema>
    {
        public EtlDefTableInfo(DataIntegrationQuerySchema schema, ContainerFilter cf)
        {
            super(schema, DataIntegrationQuerySchema.getEtlDefTableInfo(), cf);
        }

        @Override
        protected void addTableURLs()
        {
            ActionURL insertUrl = new ActionURL(DataIntegrationController.DefineEtlAction.class, getContainer());
            setInsertURL(new DetailsURL(insertUrl));
            ActionURL updateUrl = new ActionURL(DataIntegrationController.DefineEtlAction.class, getContainer());
            setUpdateURL(new DetailsURL(updateUrl, Collections.singletonMap("etlDefId", FieldKey.fromString("etlDefId"))));
            ActionURL deleteUrl = new ActionURL(DataIntegrationController.DeleteDefinitionsAction.class, getContainer());
            setDeleteURL(new DetailsURL(deleteUrl));
        }

        @Override
        public boolean hasPermission(@NotNull UserPrincipal user, @NotNull Class<? extends Permission> perm)
        {
            if (perm == ReadPermission.class)
                return super.hasPermission(user, perm);
            else
                return getContainer().hasPermission(user, AdminPermission.class);
        }
    }
}
