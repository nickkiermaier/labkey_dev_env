/*
 * Copyright (c) 2018-2019 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di;

import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.labkey.api.admin.AbstractFolderImportFactory;
import org.labkey.api.admin.FolderArchiveDataTypes;
import org.labkey.api.admin.FolderImporter;
import org.labkey.api.admin.ImportContext;
import org.labkey.api.admin.ImportException;
import org.labkey.api.data.Container;
import org.labkey.api.data.SimpleFilter;
import org.labkey.api.data.Table;
import org.labkey.api.data.TableSelector;
import org.labkey.api.di.ScheduledPipelineJobDescriptor;
import org.labkey.api.pipeline.PipelineJob;
import org.labkey.api.pipeline.PipelineJobWarning;
import org.labkey.api.query.FieldKey;
import org.labkey.api.util.XmlBeansUtil;
import org.labkey.api.util.XmlValidationException;
import org.labkey.api.writer.VirtualFile;
import org.labkey.di.pipeline.TransformDescriptor;
import org.labkey.di.pipeline.TransformManager;
import org.labkey.etl.xml.EtlDocument;
import org.labkey.etl.xml.EtlType;

import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class DataIntegrationFolderImporter implements FolderImporter
{

    @Override
    public String getDataType()
    {
        return FolderArchiveDataTypes.ETLS;
    }

    @Override
    public String getDescription()
    {
        return getDataType().toLowerCase();
    }


    /**
     *
     * @param container
     * @param etlDef
     * @return boolean whether a user defined ETL already exists with the same name as etlDef
     * @throws ImportException
     */
    private boolean validAndExists(Container container, EtlDef etlDef) throws ImportException
    {
        boolean existingEtlDef = false;
        try
        {
            TransformDescriptor descriptor = etlDef.getDescriptorThrow();
            if (descriptor.isSiteScope())
            {
                throw new ImportException("Site-scoped ETLs cannot be imported.");
            }

            // Check for module based ETL with this name
            if (TransformManager.get().getDescriptors(container).stream().filter(desc -> !desc.isUserDefined())
                    .anyMatch(cachedDescriptor -> cachedDescriptor.getName().equals(descriptor.getName())
                            && !cachedDescriptor.getId().equals(descriptor.getId())))
            {
                throw new ImportException("Module ETL definition named " + etlDef.getName() + " already exists.");
            }

            // User defined ETL exists, return boolean for update
            if (TransformManager.get().getDescriptors(container).stream()
                    .filter(ScheduledPipelineJobDescriptor::isUserDefined)
                    .filter(cachedDescriptor -> cachedDescriptor.getName().equals(descriptor.getName()))
                    .anyMatch(desc -> !desc.getId().equals(descriptor.getId())))
            {
                existingEtlDef = true;
            }
        }
        catch(XmlValidationException | XmlException | IOException e)
        {
            throw new ImportException("Failed to create valid transform descriptor from ETL definition: " + etlDef.getName(), e);
        }

        return existingEtlDef;
    }


    @Override
    public void process(@Nullable PipelineJob job, ImportContext ctx, VirtualFile root) throws Exception
    {
        VirtualFile etlsDir = ctx.getDir("etls");

        if (null != job)
            job.setStatus("IMPORT " + getDescription());
        ctx.getLogger().info("Loading " + getDescription());

        EtlType etlType;
        EtlDef etlDef;

        if (etlsDir != null)
        {
            // Iterate through etl definitions in etls directory
            int count = 0;
            List<String> etlFiles = etlsDir.list().stream().filter(name -> name.toUpperCase().endsWith(".XML")).collect(Collectors.toList());
            for (String fileName : etlFiles)
            {
                try
                {
                    XmlObject doc = etlsDir.getXmlBean(fileName);
                    if (doc instanceof EtlDocument)
                    {
                        XmlBeansUtil.validateXmlDocument(doc, fileName);
                        etlType = ((EtlDocument) doc).getEtl();

                        // Create EtlDef for validation and insert
                        etlDef = new EtlDef();
                        etlDef.setName(etlType.getName());
                        etlDef.setDescription(etlType.getDescription());
                        etlDef.setDefinition(doc.xmlText());
                        etlDef.setContainer(ctx.getContainer().getId());

                        // Validate and check if update or insert, invalid throws exception
                        if (validAndExists(ctx.getContainer(), etlDef))
                        {
                            SimpleFilter filter = SimpleFilter.createContainerFilter(ctx.getContainer());
                            filter.addCondition(FieldKey.fromString("Name"), etlDef.getName());

                            List<EtlDef> oldEtlDefs = new TableSelector(DataIntegrationQuerySchema.getEtlDefTableInfo(), filter, null).getArrayList(EtlDef.class);
                            if (oldEtlDefs.size() > 0)
                            {
                                etlDef.setEntityId(oldEtlDefs.get(0).getEntityId());
                                etlDef.setEtlDefId(oldEtlDefs.get(0).getEtlDefId());
                                Table.update(ctx.getUser(), DataIntegrationQuerySchema.getEtlDefTableInfo(), etlDef, etlDef.getEtlDefId());

                                ctx.getLogger().info("ETL definition named " + etlDef.getName() + " was overwritten by the upload.");
                            }
                        }
                        else
                        {
                            Table.insert(ctx.getUser(), DataIntegrationQuerySchema.getEtlDefTableInfo(), etlDef);
                        }
                        count++;

                        // Clear cache
                        TransformManager.get().etlDefChanged(etlDef, ctx.getContainer(), ctx.getUser(), EtlDef.Change.Insert);
                    }
                    else
                    {
                        ctx.getLogger().warn("ETL definition named " + fileName + " is not correct ETL XML format.");
                    }
                }
                catch (XmlValidationException | ImportException e)
                {
                    ctx.getLogger().warn("ETL definition not imported due to validation failure: " + fileName, e);
                }
            }

            if (count == 1)
            {
                ctx.getLogger().info(count + " ETL definition loaded");
            }
            else
            {
                ctx.getLogger().info(count + " ETL definitions loaded");
            }
        }

    }

    @Override
    public @NotNull Collection<PipelineJobWarning> postProcess(ImportContext ctx, VirtualFile root) throws Exception
    {
        return Collections.emptyList();
    }

    public static class Factory extends AbstractFolderImportFactory
    {
        public FolderImporter create()
        {
            return new DataIntegrationFolderImporter();
        }
    }
}
