/*
 * Copyright (c) 2013-2019 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.filters;

import org.jetbrains.annotations.Nullable;
import org.labkey.api.data.SimpleFilter;
import org.labkey.api.data.TableInfo;
import org.labkey.di.VariableMap;
import org.labkey.di.pipeline.TransformJobContext;
import org.labkey.di.steps.StepMeta;

import java.io.Serializable;

/**
 * User: matthew
 * Date: 4/22/13
 * Time: 11:55 AM
 *
 *
 * The Filter strategy combines two pieces of functionality.
 *
 * 1) checker: determines whether there is incremental work to perform
 * 2) filter: select a subset of rows to process
 *
 */
public interface FilterStrategy
{
    enum Type
    {
        SelectAll,
        ModifiedSince,
        Run
    }

    interface Factory extends Serializable
    {
        FilterStrategy getFilterStrategy(TransformJobContext context, StepMeta stepMeta);
        boolean checkStepsSeparately();
        Type getType();
    }

    boolean hasWork();

    /**
     * Has side effect of setting parameters
     */
    SimpleFilter getFilter(VariableMap variables);
    SimpleFilter getFilter(VariableMap variables, boolean deleting);
    @Nullable DeletedRowsSource getDeletedRowsSource();
    @Nullable TableInfo getDeletedRowsTinfo(@Nullable String cfName);
    @Nullable String getDeletedRowsKeyCol();
    @Nullable String getTargetDeletionKeyCol();
    void setTargetDeletionKeyCol(@Nullable String col);
    String getLogMessage(@Nullable String filterValue);
}