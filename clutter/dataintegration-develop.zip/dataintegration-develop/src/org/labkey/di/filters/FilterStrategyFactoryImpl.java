/*
 * Copyright (c) 2015-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.filters;

import org.jetbrains.annotations.Nullable;
import org.labkey.etl.xml.DeletedRowsSourceObjectType;
import org.labkey.etl.xml.FilterType;

/**
 * User: tgaluhn
 * Date: 4/21/2015
 */
public abstract class FilterStrategyFactoryImpl implements FilterStrategy.Factory
{
    protected final DeletedRowsSource _deletedRowsSource;

    public FilterStrategyFactoryImpl(DeletedRowsSource deletedRowsSource)
    {
        _deletedRowsSource = deletedRowsSource;
    }

    public FilterStrategyFactoryImpl(@Nullable FilterType ft)
    {
        if (null == ft || null == ft.getDeletedRowsSource())
            _deletedRowsSource = null;
        else _deletedRowsSource = initDeletedRowsSource(ft.getDeletedRowsSource());
    }

    protected FilterStrategyFactoryImpl()
    {
        _deletedRowsSource = null;
    }

    private DeletedRowsSource initDeletedRowsSource(DeletedRowsSourceObjectType s)
    {
        return new DeletedRowsSource(s.getSchemaName(), s.getQueryName(), s.getTimestampColumnName(), s.getRunColumnName(), s.getDeletedSourceKeyColumnName(), s.getTargetKeyColumnName());
    }
}
