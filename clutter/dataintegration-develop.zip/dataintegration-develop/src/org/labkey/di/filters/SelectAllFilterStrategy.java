/*
 * Copyright (c) 2013-2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di.filters;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.jetbrains.annotations.Nullable;
import org.labkey.api.data.SimpleFilter;
import org.labkey.di.VariableMap;
import org.labkey.di.pipeline.TransformJobContext;
import org.labkey.di.steps.StepMeta;
import org.labkey.etl.xml.FilterType;

/**
 * User: matthewb
 * Date: 6/20/13
 * Time: 2:16 PM
 */
public class SelectAllFilterStrategy extends FilterStrategyImpl
{

    public SelectAllFilterStrategy(StepMeta stepMeta, TransformJobContext context, DeletedRowsSource deletedRowsSource)
    {
        super(stepMeta, context, deletedRowsSource);
    }

    @Override
    public boolean hasWork()
    {
        init();
        return true;
    }

    @Override
    public SimpleFilter getFilter(VariableMap variables)
    {
        return null;
    }

    public static class Factory extends FilterStrategyFactoryImpl
    {
        public Factory(@Nullable FilterType ft)
        {
            super(ft);
        }

        @JsonCreator
        public Factory(@JsonProperty("_deletedRowsSource")DeletedRowsSource deletedRowsSource)
        {
            super(deletedRowsSource);
        }

        public Factory()
        {
            super();
        }

        @Override
        public FilterStrategy getFilterStrategy(TransformJobContext context, StepMeta stepMeta)
        {
            return new SelectAllFilterStrategy(stepMeta, context, _deletedRowsSource);
        }

        @Override
        public boolean checkStepsSeparately()
        {
            return false;
        }

        @Override
        public Type getType()
        {
            return Type.SelectAll;
        }
    }
}
