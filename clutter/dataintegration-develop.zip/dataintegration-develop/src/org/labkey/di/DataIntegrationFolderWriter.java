/*
 * Copyright (c) 2018-2019 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.di;

import org.labkey.api.admin.BaseFolderWriter;
import org.labkey.api.admin.FolderArchiveDataTypes;
import org.labkey.api.admin.FolderWriter;
import org.labkey.api.admin.FolderWriterFactory;
import org.labkey.api.admin.ImportContext;
import org.labkey.api.data.Container;
import org.labkey.api.data.SimpleFilter;
import org.labkey.api.data.TableSelector;
import org.labkey.api.writer.VirtualFile;
import org.labkey.folder.xml.FolderDocument;

import java.io.PrintWriter;
import java.util.Collection;

public class DataIntegrationFolderWriter extends BaseFolderWriter
{
    private static final String DIRECTORY_NAME = "etls";

    public String getDataType()
    {
        return FolderArchiveDataTypes.ETLS;
    }

    @Override
    public void write(Container object, ImportContext<FolderDocument.Folder> ctx, VirtualFile root) throws Exception
    {
        // Set up the pointer in the folder.xml file
        ctx.getXml().addNewEtls().setDir(DIRECTORY_NAME);

        // Create subdirectory in download
        VirtualFile etlsDir = root.getDir(DIRECTORY_NAME);

        Collection<EtlDef> savedEtls = new TableSelector(DataIntegrationQuerySchema.getEtlDefTableInfo(), SimpleFilter.createContainerFilter(ctx.getContainer()), null).getCollection(EtlDef.class);

        String filename;
        for (EtlDef etlDef : savedEtls)
        {
            filename = etlsDir.makeLegalName(etlDef.getName() + ".xml");
            try (PrintWriter writer = etlsDir.getPrintWriter(filename))
            {
                writer.write(etlDef.getPrettyPrintDefinition());
            }
        }
    }

    public static class Factory implements FolderWriterFactory
    {
        public FolderWriter create()
        {
            return new DataIntegrationFolderWriter();
        }
    }
}
