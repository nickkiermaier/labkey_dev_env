/*
 * Copyright (c) 2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.api.di;

import org.labkey.api.data.Container;
import org.labkey.api.data.ParameterDescription;
import org.labkey.api.pipeline.PipelineJob;
import org.labkey.api.pipeline.PipelineJobException;
import org.labkey.api.security.User;
import org.labkey.api.writer.ContainerUser;
import org.quartz.ScheduleBuilder;

import java.util.Map;

/**
 * User: matthewb
 * Date: 2013-03-18
 * Time: 3:21 PM
 */

public interface ScheduledPipelineJobDescriptor<C extends ContainerUser>
{
    String getId();     // globally unique id (perhaps a path)
    String getName();
    String getDescription();
    String getModuleName();
    int getVersion();
    Map<ParameterDescription,Object> getDeclaredVariables();
    boolean isStandalone();
    boolean isSiteScope();
    boolean isAllowMultipleQueuing();
    Map<String, String> getPipelineParameters();

    ScheduleBuilder getScheduleBuilder();
    String getScheduleDescription();

    // these are used to create a job that can be scheduled in Quartz
    Class<? extends org.quartz.Job> getQuartzJobClass();
    C getJobContext(Container c, User user, Map<ParameterDescription,Object> params);
    // these methods actually implement the Job
    boolean checkForWork(C context, boolean background, boolean verbose);
    PipelineJob getPipelineJob(C context) throws PipelineJobException;
    boolean isPending(ContainerUser context);

    ScheduledPipelineJobDescriptor getDescriptorFromCache(Container c);

    default boolean isUserDefined()
    {
        return false;
    }
}
