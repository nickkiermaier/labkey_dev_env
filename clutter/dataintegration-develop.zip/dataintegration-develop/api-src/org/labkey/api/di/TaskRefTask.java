/*
 * Copyright (c) 2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.api.di;

import org.apache.xmlbeans.XmlException;
import org.jetbrains.annotations.NotNull;
import org.labkey.api.data.Container;
import org.labkey.api.pipeline.PipelineJob;
import org.labkey.api.pipeline.PipelineJobException;
import org.labkey.api.pipeline.RecordedActionSet;
import org.labkey.api.query.ValidationError;
import org.labkey.api.writer.ContainerUser;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * User: tgaluhn
 * Date: 7/22/2014
 *
 * A more generic interface for ETL transform task types that aren't going to be fully defined in the etl.xsd
 * The fully qualified classname of an implementor of this interface can be specified in an ETL transform taskref
 * element, with configuration in settings/setting child elements. The taskref element is compatible with the
 * definition in pipeline.xsd
 *
 * Ultimately we'd like to be able to share tasks between ETL and Pipeline; as a step in that direction
 * the signature of the run() method here is similar to that of PipelineJob.Task<TaskFactory>.run(). If this is the route to take
 * for unification, we'll need to reconcile between the logger being passed in here vs the the job member variable in the task.
 * Also to aid in unification, implementors of this interface should ideally be decoupled from api.di and dataintegration. This is why
 * we downcast the TransformJobContext to the ContainerUser interface when passing it to the task.
 *
 */
public interface TaskRefTask
{
    String TASKREF_MISSING_REQUIRED_SETTING = "TaskRef missing required setting(s):";

    /**
     * The method that does the real work in the implementing class.
     * @return RecordedActionSet Any parameters of any RecordedActions in the set get persisted in the job parameter set in
     *          dataintegration.TransformConfiguration.TransformState
     * @throws PipelineJobException
     * @param job
     */
    RecordedActionSet run(@NotNull PipelineJob job) throws PipelineJobException;

    /**
     * For upfront validation; if any of these are missing, we won't even try to run the task
     */
    List<String> getRequiredSettings();

    /**
     * Settings read from the etl xml (or elsewhere). Eventually would be good to use TaskFactorySettings instead.
     */
    void setSettings(Map<String, String> settings) throws XmlException;

    /**
     * Downcast from the ScheduledPipelineJobContext or TransformJobContext that the etl job will be otherwise passing
     * around. There's probably a more pipeline-y way of passing this context info to a task, so this method may eventually
     * go away.
     *
     */
    void setContainerUser(ContainerUser containerUser);

    /**
     * A validation step called at job time, before queuing the job
     * @param c The container in which the job would be queued
     * @return Any errors which should prevent queuing the job
     */
    default List<ValidationError> preFlightCheck(Container c)
    {
        return Collections.emptyList();
    }
}
