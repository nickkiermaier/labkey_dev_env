/*
 * Copyright (c) 2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.api.di;

import org.apache.commons.lang3.StringUtils;
import org.apache.xmlbeans.XmlException;
import org.labkey.api.collections.CaseInsensitiveHashMap;
import org.labkey.api.exp.PropertyType;
import org.labkey.api.pipeline.RecordedAction;
import org.labkey.api.writer.ContainerUser;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * User: tgaluhn
 * Date: 7/22/2014
 */
public abstract class TaskRefTaskImpl implements TaskRefTask
{
    protected final Map<String, String> settings = new CaseInsensitiveHashMap<>();
    protected ContainerUser containerUser;

    @Override
    public void setSettings(Map<String, String> xmlSettings) throws XmlException
    {
        StringBuilder sb = new StringBuilder();
        for (String requiredSetting : getRequiredSettings())
        {
            if (StringUtils.isBlank(xmlSettings.get(requiredSetting)))
            {
                if (sb.length() == 0)
                    sb.append(TASKREF_MISSING_REQUIRED_SETTING).append("\n");
                sb.append(requiredSetting).append("\n");
            }
        }
        if (sb.length() > 0)
            throw new XmlException(sb.toString());

        this.settings.putAll(xmlSettings);
    }

    @Override
    public void setContainerUser(ContainerUser containerUser)
    {
        this.containerUser = containerUser;
    }

    @Override
    public List<String> getRequiredSettings()
    {
        return Collections.emptyList();
    }

    /**
     * Helper to turn a map of settings and outputs into a RecordedAction to be added to the RecordedActionSet return
     * of run()
     *
     */
    protected RecordedAction makeRecordedAction()
    {
        RecordedAction ra = new RecordedAction(this.getClass().getSimpleName());
        for (Map.Entry<String, String> setting : settings.entrySet())
        {
            RecordedAction.ParameterType paramType = new RecordedAction.ParameterType(setting.getKey(), PropertyType.STRING);
            ra.addParameter(paramType, setting.getValue());
        }
        return ra;
    }
}
