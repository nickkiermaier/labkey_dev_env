/*
 * Copyright (c) 2018 LabKey Corporation. All rights reserved. No portion of this work may be reproduced in
 * any form or by any electronic or mechanical means without written permission from LabKey Corporation.
 */
package org.labkey.api.di;

import org.apache.log4j.Logger;
import org.jetbrains.annotations.Nullable;
import org.labkey.api.data.Container;
import org.labkey.api.pipeline.PipelineJobException;
import org.labkey.api.security.User;
import org.labkey.api.services.ServiceRegistry;
import org.labkey.api.view.NotFoundException;
import org.labkey.remoteapi.Connection;

/**
 * Services provided for running ETLs within the server.
 * User: matthewb
 * Date: 2013-04-03
 */
public interface DataIntegrationService
{
    String MODULE_NAME = "DataIntegration";

    static DataIntegrationService get()
    {
        return ServiceRegistry.get().getService(DataIntegrationService.class);
    }

    static void setInstance(DataIntegrationService impl)
    {
        ServiceRegistry.get().registerService(DataIntegrationService.class, impl);
    }

    void registerStepProviders();
    @Nullable Integer runTransformNow(Container c, User u, String transformId) throws PipelineJobException, NotFoundException;

    RemoteConnection getRemoteConnection(String name, Container c, @Nullable Logger log);

    class RemoteConnection
    {
        public Connection connection;
        public String remoteContainer;
    }
}
